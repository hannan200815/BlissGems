package org.a.a.a;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.PARAMETER, ElementType.METHOD})
public @interface a {
   String a = "The method argument (if parameter was annotated) or this container (if instance method was annotated)";
   String b = "this";
   String c = "This container (if the parameter was annotated) or the return value (if instance method was annotated)";
   String d = "The return value of this method";
   String e = "this";

   String a() default "The method argument (if parameter was annotated) or this container (if instance method was annotated)";

   boolean b() default false;

   String c() default "This container (if the parameter was annotated) or the return value (if instance method was annotated)";

   boolean d() default false;
}
