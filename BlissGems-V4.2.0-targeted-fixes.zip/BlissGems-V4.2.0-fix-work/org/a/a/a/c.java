package org.a.a.a;

/** @deprecated */
@Deprecated
public final class c {
   private c() {
      throw new AssertionError("JdkConstants should not be instantiated");
   }

   public @interface a {
   }

   public @interface b {
   }

   public @interface c {
   }

   public @interface d {
   }

   public @interface e {
   }

   public @interface f {
   }

   public @interface g {
   }

   public @interface h {
   }

   public @interface i {
   }

   public @interface j {
   }

   public @interface k {
   }

   public @interface l {
   }

   public @interface m {
   }

   public @interface n {
   }

   public @interface o {
   }

   public @interface p {
   }

   public @interface q {
   }
}
