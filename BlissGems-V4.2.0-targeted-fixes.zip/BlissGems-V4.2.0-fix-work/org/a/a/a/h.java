package org.a.a.a;

class h {
   @d(
      a = "RegExp"
   )
   private static final String b = "(?:\\d+\\$)?";
   @d(
      a = "RegExp"
   )
   private static final String c = "(?:[-#+ 0,(<]*)?";
   @d(
      a = "RegExp"
   )
   private static final String d = "(?:\\d+)?";
   @d(
      a = "RegExp"
   )
   private static final String e = "(?:\\.\\d+)?";
   @d(
      a = "RegExp"
   )
   private static final String f = "(?:[tT])?(?:[a-zA-Z%])";
   @d(
      a = "RegExp"
   )
   private static final String g = "[^%]|%%";
   @d(
      a = "RegExp"
   )
   static final String a = "(?:[^%]|%%|(?:%(?:\\d+\\$)?(?:[-#+ 0,(<]*)?(?:\\d+)?(?:\\.\\d+)?(?:[tT])?(?:[a-zA-Z%])))*";
}
