package dev.xoperr.blissgems.api;

public class CooldownEntry {
   private final String abilityKey;
   private final String displayName;

   public CooldownEntry(String var1, String var2) {
      this.abilityKey = var1;
      this.displayName = var2;
   }

   public String getAbilityKey() {
      return this.abilityKey;
   }

   public String getDisplayName() {
      return this.displayName;
   }
}
