package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.EnergyState;
import dev.xoperr.blissgems.utils.GemType;
import java.util.ArrayList;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class BlissGuiManager implements Listener {
   private final BlissGems plugin;
   private static final String GUI_TITLE = "§5§lBlissGems Menu";

   public BlissGuiManager(BlissGems var1) {
      this.plugin = var1;
   }

   public void openMainMenu(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 27, "§5§lBlissGems Menu");
      var2.setItem(11, this.createGemInfoItem(var1));
      var2.setItem(13, this.createEnergyInfoItem(var1));
      var2.setItem(15, this.createSettingsItem(var1));
      ItemStack var3 = this.createBorderItem();

      for(int var4 = 0; var4 < 27; ++var4) {
         if (var2.getItem(var4) == null) {
            var2.setItem(var4, var3);
         }
      }

      var1.openInventory(var2);
   }

   private ItemStack createGemInfoItem(Player var1) {
      GemType var2 = this.plugin.getGemManager().getGemType(var1);
      int var3 = this.plugin.getGemManager().getGemTier(var1);
      ArrayList var5 = new ArrayList();
      ItemStack var4;
      if (var2 != null) {
         var4 = new ItemStack(Material.ECHO_SHARD);
         ItemMeta var6 = var4.getItemMeta();
         var6.setDisplayName("§d§lYour Gem");
         var5.add("§7Type: §f" + var2.getDisplayName());
         var5.add("§7Tier: §f" + var3);
         var5.add("");
         var5.add("§7Description:");
         String[] var7 = var2.getDescription().split("\n");

         for(String var11 : var7) {
            var5.add("§8" + var11);
         }

         var6.setLore(var5);
         var4.setItemMeta(var6);
      } else {
         var4 = new ItemStack(Material.BARRIER);
         ItemMeta var12 = var4.getItemMeta();
         var12.setDisplayName("§c§lNo Gem");
         var5.add("§7You don't have a gem equipped!");
         var5.add("§7Get one from an admin or find one.");
         var12.setLore(var5);
         var4.setItemMeta(var12);
      }

      return var4;
   }

   private ItemStack createEnergyInfoItem(Player var1) {
      int var2 = this.plugin.getEnergyManager().getEnergy(var1);
      EnergyState var3 = this.plugin.getEnergyManager().getEnergyState(var1);
      ItemStack var4 = new ItemStack(Material.NETHER_STAR);
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName("§b§lEnergy Status");
      ArrayList var6 = new ArrayList();
      var6.add("§7Energy: §f" + var2 + "§8/§f10");
      var6.add("§7State: §f" + var3.getDisplayName());
      var6.add("");
      StringBuilder var7 = new StringBuilder("§8[");

      for(int var8 = 0; var8 < 10; ++var8) {
         if (var8 < var2) {
            var7.append("§a■");
         } else {
            var7.append("§7■");
         }
      }

      var7.append("§8]");
      var6.add(var7.toString());
      var6.add("");
      if (var2 == 0) {
         var6.add("§c✘ Abilities disabled");
         var6.add("§c✘ Passives disabled");
      } else if (var2 == 1) {
         var6.add("§a✔ Abilities enabled");
         var6.add("§c✘ Passives disabled");
      } else {
         var6.add("§a✔ Abilities enabled");
         var6.add("§a✔ Passives enabled");
      }

      var5.setLore(var6);
      var4.setItemMeta(var5);
      return var4;
   }

   private ItemStack createSettingsItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.COMPARATOR);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§e§lSettings");
      ArrayList var4 = new ArrayList();
      var4.add("§7Current Settings:");
      var4.add("");
      boolean var5 = this.plugin.getClickActivationManager().isClickActivationEnabled(var1);
      var4.add("§7Click Activation: " + (var5 ? "§aEnabled" : "§cDisabled"));
      var4.add("§8Use /bliss toggle_click to change");
      var4.add("");
      int var6 = this.plugin.getTrustedPlayersManager().getTrustedPlayers(var1).size();
      var4.add("§7Trusted Players: §f" + var6);
      var4.add("§8Use /bliss trust <player>");
      var4.add("");
      if (var1.hasPermission("blissgems.admin")) {
         boolean var7 = this.plugin.getConfigManager().isBanOnZeroEnergyEnabled();
         var4.add("§c§lAdmin Setting:");
         var4.add("§7Ban on 0 Energy: " + (var7 ? "§aEnabled" : "§cDisabled"));
         var4.add("§8Use /bliss bannable <true/false>");
      }

      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createBorderItem() {
      ItemStack var1 = new ItemStack(Material.GRAY_STAINED_GLASS_PANE);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName(" ");
      var1.setItemMeta(var2);
      return var1;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent var1) {
      if (var1.getView().getTitle().equals("§5§lBlissGems Menu")) {
         var1.setCancelled(true);
      }

   }
}
