package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemPassiveHandler;
import dev.xoperr.blissgems.api.GemRegistry;
import dev.xoperr.blissgems.utils.GemType;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

public class PassiveManager {
   private final BlissGems a;

   public PassiveManager(BlissGems var1) {
      this.a = var1;
      this.a();
   }

   private void a() {
      int var1 = this.a.getConfigManager().getPassiveUpdateInterval();
      (new BukkitRunnable() {
         public void run() {
            for(Player var2 : PassiveManager.this.a.getServer().getOnlinePlayers()) {
               if (!var2.isDead() && PassiveManager.this.a.getGemManager().hasGemInOffhand(var2) && PassiveManager.this.a.getEnergyManager().arePassivesActive(var2)) {
                  PassiveManager.this.a(var2);
               }
            }

         }
      }).runTaskTimer(this.a, (long)var1, (long)var1);
   }

   private void a(Player var1) {
      if (this.a.getRegionManager() == null || !this.a.getRegionManager().a(var1)) {
         int var2 = this.a.getGemManager().getTierFromOffhand(var1);
         String var3 = this.a.getGemManager().getGemIdFromOffhand(var1);
         GemType var4 = this.a.getGemManager().getGemTypeFromOffhand(var1);
         if (var4 != null) {
            switch (var4) {
               case ASTRA -> this.b(var1);
               case FIRE -> this.c(var1);
               case FLUX -> this.d(var1);
               case LIFE -> this.e(var1);
               case PUFF -> this.f(var1);
               case SPEED -> this.g(var1);
               case STRENGTH -> this.h(var1);
               case WEALTH -> this.i(var1);
            }

            this.a(var1, var4, var2);
         } else {
            if (var3 != null) {
               GemRegistryImpl var5 = this.a.getGemRegistry();
               if (var5 != null) {
                  GemPassiveHandler var6 = var5.getPassiveHandler(var3);
                  if (var6 != null) {
                     var6.applyPassives(var1, var2);
                  }

                  this.a(var1, var3, var2);
               }
            }

         }
      }
   }

   private void a(Player var1, String var2, int var3) {
      String var4 = "passives.extra-effects." + var2 + ".t" + var3;
      List var5 = this.a.getConfig().getMapList(var4);
      if (var5 != null && !var5.isEmpty()) {
         int var6 = this.a.getConfigManager().getPassiveUpdateInterval() + 10;

         for(Map var8 : var5) {
            Object var9 = var8.get("type");
            if (var9 != null) {
               PotionEffectType var10 = PotionEffectType.getByName(var9.toString().toUpperCase());
               if (var10 == null) {
                  Logger var10000 = this.a.getLogger();
                  String var10001 = String.valueOf(var9);
                  var10000.warning("Unknown potion effect '" + var10001 + "' in " + var4);
               } else {
                  Object var11 = var8.get("level");
                  int var12 = var11 instanceof Number ? ((Number)var11).intValue() : 1;
                  int var13 = Math.max(0, var12 - 1);
                  var1.addPotionEffect(new PotionEffect(var10, var6, var13, true, false), true);
               }
            }
         }

      }
   }

   private void a(Player var1, GemType var2, int var3) {
      String var10000 = var2.name().toLowerCase();
      String var4 = "passives.extra-effects." + var10000 + ".t" + var3;
      List var5 = this.a.getConfig().getMapList(var4);
      if (var5 != null && !var5.isEmpty()) {
         int var6 = this.a.getConfigManager().getPassiveUpdateInterval() + 10;

         for(Map var8 : var5) {
            Object var9 = var8.get("type");
            if (var9 != null) {
               PotionEffectType var10 = PotionEffectType.getByName(var9.toString().toUpperCase());
               if (var10 == null) {
                  Logger var14 = this.a.getLogger();
                  String var10001 = String.valueOf(var9);
                  var14.warning("Unknown potion effect '" + var10001 + "' in " + var4);
               } else {
                  Object var11 = var8.get("level");
                  int var12 = var11 instanceof Number ? ((Number)var11).intValue() : 1;
                  int var13 = Math.max(0, var12 - 1);
                  var1.addPotionEffect(new PotionEffect(var10, var6, var13, true, false), true);
               }
            }
         }

      }
   }

   private void b(Player var1) {
   }

   private void c(Player var1) {
      int var2 = this.a.getGemManager().getTierFromOffhand(var1);
      if (this.a.getConfigManager().isFireResistanceEnabled(var2)) {
         int var3 = this.a.getConfigManager().getPassiveUpdateInterval();
         var1.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, var3 + 10, 0, true, false), true);
      }

   }

   private void d(Player var1) {
      var1.removePotionEffect(PotionEffectType.WEAKNESS);
      var1.removePotionEffect(PotionEffectType.SLOWNESS);
      var1.removePotionEffect(PotionEffectType.HUNGER);
      if (var1.isSprinting()) {
         this.a.getFlowStateManager().registerAction(var1, FlowStateManager.ActionType.SPRINT);
      }

   }

   private void e(Player var1) {
      if (!var1.isDead()) {
         var1.removePotionEffect(PotionEffectType.WITHER);
         int var2 = this.a.getGemManager().getTierFromOffhand(var1);
         double var3 = this.a.getConfigManager().getLifeHealAmount(var2);
         double var5 = var1.getHealth();
         double var7 = var1.getMaxHealth();
         if (var5 < var7) {
            var1.setHealth(Math.min(var7, var5 + var3));
         }

      }
   }

   private void f(Player var1) {
   }

   private void g(Player var1) {
      int var2 = this.a.getGemManager().getTierFromOffhand(var1);
      int var3 = this.a.getConfigManager().getSpeedLevel(var2);
      int var4 = this.a.getConfigManager().getPassiveUpdateInterval();
      int var5 = var4 + 10;
      var1.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, var5, var3, true, false), true);
      var1.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, var5, 0, true, false), true);
   }

   private void h(Player var1) {
      int var2 = this.a.getGemManager().getTierFromOffhand(var1);
      int var3 = this.a.getConfigManager().getStrengthLevel(var2);
      int var4 = this.a.getConfigManager().getPassiveUpdateInterval();
      int var5 = var4 + 10;
      PotionEffect var6 = var1.getPotionEffect(PotionEffectType.STRENGTH);
      if (var6 == null || var6.getAmplifier() <= var3 && (var6.getAmplifier() != var3 || var6.getDuration() <= var5 + 5)) {
         var1.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, var5, var3, true, false), true);
      }
   }

   private void i(Player var1) {
      int var2 = this.a.getGemManager().getTierFromOffhand(var1);
      int var3 = this.a.getConfigManager().getLuckLevel(var2);
      int var4 = this.a.getConfigManager().getPassiveUpdateInterval();
      int var5 = var4 + 10;
      var1.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, var5, var3, true, false), true);
      var1.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, var5, 0, true, false), true);
   }

   public void registerBuiltInHandlers(GemRegistry var1) {
      var1.registerPassives("astra", (var1x, var2) -> this.b(var1x));
      var1.registerPassives("fire", (var1x, var2) -> this.c(var1x));
      var1.registerPassives("flux", (var1x, var2) -> this.d(var1x));
      var1.registerPassives("life", (var1x, var2) -> this.e(var1x));
      var1.registerPassives("puff", (var1x, var2) -> this.f(var1x));
      var1.registerPassives("speed", (var1x, var2) -> this.g(var1x));
      var1.registerPassives("strength", (var1x, var2) -> this.h(var1x));
      var1.registerPassives("wealth", (var1x, var2) -> this.i(var1x));
   }
}
