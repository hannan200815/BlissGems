package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.Achievement;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class AchievementManager {
   private final BlissGems a;
   private final File b;
   private final Map<UUID, Map<Achievement, Integer>> c = new HashMap();
   private final Map<UUID, Set<Achievement>> d = new HashMap();

   public AchievementManager(BlissGems var1) {
      this.a = var1;
      this.b = new File(var1.getDataFolder(), "achievements");
      if (!this.b.exists()) {
         this.b.mkdirs();
      }

   }

   public boolean isUnlocked(Player var1, Achievement var2) {
      return this.getUnlocked(var1).contains(var2);
   }

   public Set<Achievement> getUnlocked(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (!this.d.containsKey(var2)) {
         this.a(var1);
      }

      return (Set)this.d.getOrDefault(var2, new HashSet());
   }

   public int getProgress(Player var1, Achievement var2) {
      UUID var3 = var1.getUniqueId();
      if (!this.c.containsKey(var3)) {
         this.a(var1);
      }

      return (Integer)((Map)this.c.getOrDefault(var3, new HashMap())).getOrDefault(var2, 0);
   }

   public void addProgress(Player var1, Achievement var2, int var3) {
      if (!this.isUnlocked(var1, var2)) {
         UUID var4 = var1.getUniqueId();
         Map var5 = (Map)this.c.computeIfAbsent(var4, (var0) -> new HashMap());
         int var6 = (Integer)var5.getOrDefault(var2, 0);
         int var7 = var6 + var3;
         var5.put(var2, var7);
         if (var7 >= var2.getTargetProgress()) {
            this.unlock(var1, var2);
         }

      }
   }

   public void setProgress(Player var1, Achievement var2, int var3) {
      if (!this.isUnlocked(var1, var2)) {
         UUID var4 = var1.getUniqueId();
         Map var5 = (Map)this.c.computeIfAbsent(var4, (var0) -> new HashMap());
         var5.put(var2, var3);
         if (var3 >= var2.getTargetProgress()) {
            this.unlock(var1, var2);
         }

      }
   }

   public void unlock(Player var1, Achievement var2) {
      if (!this.isUnlocked(var1, var2)) {
         UUID var3 = var1.getUniqueId();
         Set var4 = (Set)this.d.computeIfAbsent(var3, (var0) -> new HashSet());
         var4.add(var2);
         Map var5 = (Map)this.c.computeIfAbsent(var3, (var0) -> new HashMap());
         var5.put(var2, var2.getTargetProgress());
         var1.sendMessage("§6§l⭐ ACHIEVEMENT UNLOCKED! §e" + var2.getDisplayName());
         var1.sendMessage("§7§o" + var2.getDescription());
         var1.playSound(var1.getLocation(), Sound.UI_TOAST_CHALLENGE_COMPLETE, 1.0F, 1.0F);
         var1.spawnParticle(Particle.TOTEM_OF_UNDYING, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
         this.savePlayerData(var3);
      }
   }

   private void a(Player var1) {
      UUID var2 = var1.getUniqueId();
      File var3 = new File(this.b, String.valueOf(var2) + ".yml");
      HashSet var4 = new HashSet();
      HashMap var5 = new HashMap();
      if (var3.exists()) {
         YamlConfiguration var6 = YamlConfiguration.loadConfiguration(var3);

         for(Achievement var10 : Achievement.values()) {
            String var11 = var10.name().toLowerCase();
            var5.put(var10, ((FileConfiguration)var6).getInt("progress." + var11, 0));
            if (((FileConfiguration)var6).getBoolean("unlocked." + var11, false)) {
               var4.add(var10);
            }
         }
      }

      this.d.put(var2, var4);
      this.c.put(var2, var5);
   }

   public void savePlayerData(UUID var1) {
      File var2 = new File(this.b, String.valueOf(var1) + ".yml");
      YamlConfiguration var3 = new YamlConfiguration();
      Map var4 = (Map)this.c.getOrDefault(var1, new HashMap());
      Set var5 = (Set)this.d.getOrDefault(var1, new HashSet());

      for(Achievement var9 : Achievement.values()) {
         String var10 = var9.name().toLowerCase();
         ((FileConfiguration)var3).set("progress." + var10, var4.getOrDefault(var9, 0));
         ((FileConfiguration)var3).set("unlocked." + var10, var5.contains(var9));
      }

      try {
         ((FileConfiguration)var3).save(var2);
      } catch (IOException var11) {
         Logger var10000 = this.a.getLogger();
         String var10001 = String.valueOf(var1);
         var10000.warning("Failed to save achievements for " + var10001 + ": " + var11.getMessage());
      }

   }

   public void saveAll() {
      for(UUID var2 : this.d.keySet()) {
         this.savePlayerData(var2);
      }

   }

   public void clearCache(UUID var1) {
      this.c.remove(var1);
      this.d.remove(var1);
   }
}
