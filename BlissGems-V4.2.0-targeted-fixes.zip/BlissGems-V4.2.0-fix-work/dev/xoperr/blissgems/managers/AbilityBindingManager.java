package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.AbilityBinding;
import dev.xoperr.blissgems.utils.AbilitySlot;
import java.io.File;
import java.io.IOException;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class AbilityBindingManager {
   private final BlissGems a;
   private final Map<UUID, EnumMap<AbilityBinding, AbilitySlot>> b = new ConcurrentHashMap();
   private static final EnumMap<AbilityBinding, AbilitySlot> c = new EnumMap(AbilityBinding.class);

   public AbilityBindingManager(BlissGems var1) {
      this.a = var1;
   }

   public AbilitySlot getSlot(Player var1, AbilityBinding var2) {
      return (AbilitySlot)this.a(var1.getUniqueId()).get(var2);
   }

   public EnumMap<AbilityBinding, AbilitySlot> getAll(Player var1) {
      return new EnumMap(this.a(var1.getUniqueId()));
   }

   public void setBinding(Player var1, AbilityBinding var2, AbilitySlot var3) {
      EnumMap var4 = this.a(var1.getUniqueId());
      var4.entrySet().removeIf((var2x) -> var2x.getValue() == var3 && var2x.getKey() != var2);
      var4.put(var2, var3);
      this.a(var1.getUniqueId(), var4);
   }

   public void unbind(Player var1, AbilityBinding var2) {
      EnumMap var3 = this.a(var1.getUniqueId());
      var3.remove(var2);
      this.a(var1.getUniqueId(), var3);
   }

   public void resetToDefaults(Player var1) {
      EnumMap var2 = new EnumMap(c);
      this.b.put(var1.getUniqueId(), var2);
      this.a(var1.getUniqueId(), var2);
   }

   public void clearCache(UUID var1) {
      this.b.remove(var1);
   }

   private EnumMap<AbilityBinding, AbilitySlot> a(UUID var1) {
      EnumMap var2 = (EnumMap)this.b.get(var1);
      if (var2 != null) {
         return var2;
      } else {
         var2 = this.b(var1);
         this.b.put(var1, var2);
         return var2;
      }
   }

   private EnumMap<AbilityBinding, AbilitySlot> b(UUID var1) {
      File var2 = this.c(var1);
      if (!var2.exists()) {
         return new EnumMap(c);
      } else {
         YamlConfiguration var3 = YamlConfiguration.loadConfiguration(var2);
         if (!((FileConfiguration)var3).contains("ability-bindings")) {
            return new EnumMap(c);
         } else {
            EnumMap var4 = new EnumMap(AbilityBinding.class);
            Map var5 = ((FileConfiguration)var3).getConfigurationSection("ability-bindings").getValues(false);

            for(Map.Entry var7 : var5.entrySet()) {
               AbilityBinding var8 = AbilityBinding.fromId((String)var7.getKey());
               AbilitySlot var9 = AbilitySlot.fromId(String.valueOf(var7.getValue()));
               if (var8 != null && var9 != null) {
                  var4.put(var8, var9);
               }
            }

            return var4;
         }
      }
   }

   private void a(UUID var1, EnumMap<AbilityBinding, AbilitySlot> var2) {
      File var3 = this.c(var1);
      YamlConfiguration var4 = var3.exists() ? YamlConfiguration.loadConfiguration(var3) : new YamlConfiguration();
      ((FileConfiguration)var4).set("ability-bindings", (Object)null);
      HashMap var5 = new HashMap();

      for(Map.Entry var7 : var2.entrySet()) {
         var5.put(((AbilityBinding)var7.getKey()).getId(), ((AbilitySlot)var7.getValue()).getId());
      }

      ((FileConfiguration)var4).createSection("ability-bindings", var5);

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var8) {
         Logger var10000 = this.a.getLogger();
         String var10001 = String.valueOf(var1);
         var10000.warning("[AbilityBindings] Failed to save for " + var10001 + ": " + var8.getMessage());
      }

   }

   private File c(UUID var1) {
      File var2 = new File(this.a.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      return new File(var2, String.valueOf(var1) + ".yml");
   }

   static {
      c.put(AbilityBinding.RIGHT_CLICK, AbilitySlot.PRIMARY);
      c.put(AbilityBinding.SHIFT_RIGHT_CLICK, AbilitySlot.SECONDARY);
      c.put(AbilityBinding.SWAP_HAND, AbilitySlot.TERTIARY);
      c.put(AbilityBinding.SHIFT_SWAP_HAND, AbilitySlot.QUATERNARY);
   }
}
