package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.EnergyState;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class EnergyManager {
   private final BlissGems a;
   private final File b;
   private final Map<UUID, Integer> c;

   public EnergyManager(BlissGems var1) {
      this.a = var1;
      this.b = new File(var1.getDataFolder(), "playerdata");
      this.c = new HashMap();
      if (!this.b.exists()) {
         this.b.mkdirs();
      }

   }

   public int getEnergy(Player var1) {
      return (Integer)this.c.computeIfAbsent(var1.getUniqueId(), (var2) -> {
         FileConfiguration var3 = this.a(var1);
         return var3.getInt("energy", this.a.getConfigManager().getStartingEnergy());
      });
   }

   public void setEnergy(Player var1, int var2) {
      int var3 = this.a.getConfigManager().getMaxEnergy();
      var2 = Math.max(0, Math.min(var3, var2));
      this.c.put(var1.getUniqueId(), var2);
      this.a(var1, var2);
      this.a.getGemManager().updateGemTextures(var1);
      if (this.a.getAchievementManager() != null) {
         if (var2 == 0) {
            this.a.getAchievementManager().unlock(var1, Achievement.SHATTERED);
         }

         if (var2 == var3) {
            this.a.getAchievementManager().unlock(var1, Achievement.OVERFLOWING);
         }
      }

   }

   public void addEnergy(Player var1, int var2) {
      this.setEnergy(var1, this.getEnergy(var1) + var2);
   }

   public void removeEnergy(Player var1, int var2) {
      int var3 = this.getEnergy(var1);
      if (var3 > 0) {
         this.setEnergy(var1, var3 - var2);
      }
   }

   public EnergyState getEnergyState(Player var1) {
      return EnergyState.fromEnergy(this.getEnergy(var1));
   }

   public boolean arePassivesActive(Player var1) {
      return this.getEnergyState(var1).passivesActive();
   }

   public boolean canUseAbilities(Player var1) {
      return this.getEnergyState(var1).abilitiesUsable();
   }

   private FileConfiguration a(Player var1) {
      File var2 = new File(this.b, String.valueOf(var1.getUniqueId()) + ".yml");
      return !var2.exists() ? new YamlConfiguration() : YamlConfiguration.loadConfiguration(var2);
   }

   private void a(Player var1, int var2) {
      File var3 = new File(this.b, String.valueOf(var1.getUniqueId()) + ".yml");
      FileConfiguration var4 = this.a(var1);
      var4.set("energy", var2);

      try {
         var4.save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.a.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save player data for " + var10001 + ": " + var6.getMessage());
      }

   }

   public void saveAll() {
      for(Player var2 : this.a.getServer().getOnlinePlayers()) {
         if (this.c.containsKey(var2.getUniqueId())) {
            this.a(var2, (Integer)this.c.get(var2.getUniqueId()));
         }
      }

   }

   public void clearCache(UUID var1) {
      this.c.remove(var1);
   }
}
