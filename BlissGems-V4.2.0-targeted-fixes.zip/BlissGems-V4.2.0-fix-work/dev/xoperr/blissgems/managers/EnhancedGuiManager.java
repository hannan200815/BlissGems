package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.EnergyState;
import dev.xoperr.blissgems.utils.GemType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public class EnhancedGuiManager implements Listener {
   private final BlissGems plugin;
   private final Map<UUID, Integer> playerPage = new HashMap();
   private final Map<UUID, Integer> playerSubPage = new HashMap();
   private static final String PLAYER_GUI_TITLE = "§5§lBlissGems Menu";
   private static final String ADMIN_GUI_TITLE = "§c§l[ADMIN] BlissGems Control";
   private static final String ADMIN_GEMS_TITLE = "§9§l[ADMIN] Enabled Gems";
   private static final String ADMIN_SETTINGS_TITLE = "§6§l[ADMIN] Settings";
   private static final String ADMIN_GEMOPS_TITLE = "§d§l[ADMIN] Gem Operations";
   private static final String ADMIN_ENERGY_TITLE = "§c§l[ADMIN] Energy Control";
   private static final String ADMIN_PLAYERS_TITLE = "§a§l[ADMIN] Player Management";
   private static final String ADMIN_CONFIG_EDITOR_TITLE = "§e§l[ADMIN] Config Editor";

   public EnhancedGuiManager(BlissGems var1) {
      this.plugin = var1;
   }

   public void openMainMenu(Player var1) {
      if (var1.hasPermission("blissgems.admin")) {
         this.openAdminDashboard(var1, 0);
      } else {
         this.openPlayerDashboard(var1);
      }

   }

   private void openPlayerDashboard(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§5§lBlissGems Menu");
      var2.setItem(11, this.createGemInfoItem(var1));
      var2.setItem(13, this.createEnergyInfoItem(var1));
      if (var1.hasPermission("blissgems.admin")) {
         var2.setItem(15, this.createRerollItem(var1));
      }

      var2.setItem(20, this.createAbilitiesItem(var1));
      var2.setItem(22, this.createPassivesItem(var1));
      var2.setItem(24, this.createCooldownsItem(var1));
      var2.setItem(29, this.createTrustedItem(var1));
      var2.setItem(31, this.createStatsItem(var1));
      var2.setItem(33, this.createSettingsItem(var1));
      var1.openInventory(var2);
      this.playerPage.put(var1.getUniqueId(), 0);
   }

   private void openAdminDashboard(Player var1, int var2) {
      Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 54, "§c§l[ADMIN] BlissGems Control");
      var3.setItem(10, this.createPlayersControlItem());
      var3.setItem(12, this.createEnabledGemsItem());
      var3.setItem(14, this.createSettingsControlItem());
      var3.setItem(16, this.createGemOpsItem());
      var3.setItem(19, this.createEnergyControlItem());
      var3.setItem(21, this.createReloadConfigItem());
      var3.setItem(23, this.createConfigEditorItem());
      var1.openInventory(var3);
   }

   private ItemStack createGemInfoItem(Player var1) {
      GemType var2 = this.plugin.getGemManager().getGemType(var1);
      int var3 = this.plugin.getGemManager().getGemTier(var1);
      ArrayList var5 = new ArrayList();
      ItemStack var4;
      if (var2 != null) {
         var4 = new ItemStack(Material.ECHO_SHARD);
         ItemMeta var6 = var4.getItemMeta();
         var6.setDisplayName("§d§lYour Gem");
         var5.add("§7Type: §f" + var2.getDisplayName());
         var5.add("§7Tier: §f" + var3);
         var5.add("");
         var5.add("§7Description:");
         String[] var7 = var2.getDescription().split("\n");

         for(String var11 : var7) {
            var5.add("§8" + var11);
         }

         var6.setLore(var5);
         var4.setItemMeta(var6);
      } else {
         var4 = new ItemStack(Material.BARRIER);
         ItemMeta var12 = var4.getItemMeta();
         var12.setDisplayName("§c§lNo Gem");
         var5.add("§7You don't have a gem equipped!");
         var12.setLore(var5);
         var4.setItemMeta(var12);
      }

      return var4;
   }

   private ItemStack createEnergyInfoItem(Player var1) {
      int var2 = this.plugin.getEnergyManager().getEnergy(var1);
      EnergyState var3 = this.plugin.getEnergyManager().getEnergyState(var1);
      ItemStack var4 = new ItemStack(Material.NETHER_STAR);
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName("§b§lEnergy Status");
      ArrayList var6 = new ArrayList();
      var6.add("§7Energy: §f" + var2 + "§8/§f10");
      var6.add("§7State: §f" + var3.getDisplayName());
      var6.add("");
      StringBuilder var7 = new StringBuilder("§8[");

      for(int var8 = 0; var8 < 10; ++var8) {
         if (var8 < var2) {
            var7.append("§a■");
         } else {
            var7.append("§7■");
         }
      }

      var7.append("§8]");
      var6.add(var7.toString());
      var6.add("");
      if (var2 == 0) {
         var6.add("§c✘ Abilities disabled");
         var6.add("§c✘ Passives disabled");
      } else if (var2 == 1) {
         var6.add("§a✔ Abilities enabled");
         var6.add("§c✘ Passives disabled");
      } else {
         var6.add("§a✔ Abilities enabled");
         var6.add("§a✔ Passives enabled");
      }

      var5.setLore(var6);
      var4.setItemMeta(var5);
      return var4;
   }

   private ItemStack createRerollItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.TRIPWIRE_HOOK);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§e§l\ud83c\udfb0 SPIN FOR NEW GEM");
      ArrayList var4 = new ArrayList();
      var4.add("§7Click to reroll your gem!");
      var4.add("§7Cost: 2 Energy");
      var4.add("§7You get random gem (no repeats)");
      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createAbilitiesItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.BLAZE_ROD);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§c§lAbilities");
      ArrayList var4 = new ArrayList();
      GemType var5 = this.plugin.getGemManager().getGemType(var1);
      if (var5 != null) {
         var4.add("§7T1: §f" + var5.getDisplayName());
         var4.add("§7T2: §fAvailable");
      } else {
         var4.add("§7No gem equipped");
      }

      var4.add("§8Click for details");
      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createPassivesItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.AMETHYST_SHARD);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§6§lPassive Effects");
      ArrayList var4 = new ArrayList();
      GemType var5 = this.plugin.getGemManager().getGemType(var1);
      if (var5 != null) {
         var4.add("§7Gem: §f" + var5.getDisplayName());
         var4.add("§7Status: §aActive");
      } else {
         var4.add("§7No passives");
      }

      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createCooldownsItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.REPEATER);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§3§lCooldowns");
      ArrayList var4 = new ArrayList();
      var4.add("§7Track your ability");
      var4.add("§7cooldown timers");
      var4.add("§8Click for details");
      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createTrustedItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.EMERALD);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§2§lTrusted Players");
      int var4 = this.plugin.getTrustedPlayersManager().getTrustedPlayers(var1).size();
      ArrayList var5 = new ArrayList();
      var5.add("§7Count: §f" + var4);
      var5.add("§8Use /bliss trust <player>");
      var3.setLore(var5);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createStatsItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.GOLDEN_APPLE);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§6§lYour Stats");
      int var4 = this.plugin.getStatsManager().getKills(var1);
      ArrayList var5 = new ArrayList();
      var5.add("§7Kills: §f" + var4);
      var5.add("§8Type /bliss stats");
      var3.setLore(var5);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createSettingsItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.COMPARATOR);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§e§lSettings");
      ArrayList var4 = new ArrayList();
      boolean var5 = this.plugin.getClickActivationManager().isClickActivationEnabled(var1);
      var4.add("§7Click Activation: " + (var5 ? "§aEnabled" : "§cDisabled"));
      var4.add("§8Use /bliss toggle_click");
      var3.setLore(var4);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createPlayersControlItem() {
      ItemStack var1 = new ItemStack(Material.PLAYER_HEAD);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§a§l[Admin] Players");
      ArrayList var3 = new ArrayList();
      var3.add("§7Manage player gems & energy");
      var3.add("§7(Click for player list)");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createEnabledGemsItem() {
      ItemStack var1 = new ItemStack(Material.DIAMOND);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§9§l[Admin] Enabled Gems");
      ArrayList var3 = new ArrayList();
      var3.add("§7Toggle gems on/off");
      var3.add("§7(Click to see status)");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createSettingsControlItem() {
      ItemStack var1 = new ItemStack(Material.REPEATING_COMMAND_BLOCK);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§6§l[Admin] Settings");
      ArrayList var3 = new ArrayList();
      var3.add("§7Max Energy: 10");
      var3.add("§7Starting Energy: 5");
      var3.add("§7(Click to adjust)");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createGemOpsItem() {
      ItemStack var1 = new ItemStack(Material.SHULKER_BOX);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§d§l[Admin] Gem Ops");
      ArrayList var3 = new ArrayList();
      var3.add("§7Give items:");
      var3.add("§7- Energy Bottles");
      var3.add("§7- Reroll Tokens");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createEnergyControlItem() {
      ItemStack var1 = new ItemStack(Material.REDSTONE_BLOCK);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§c§l[Admin] Energy Control");
      ArrayList var3 = new ArrayList();
      var3.add("§7Global energy settings");
      var3.add("§7Scale all players by 1.5x");
      var3.add("§7Or set all to X energy");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createReloadConfigItem() {
      ItemStack var1 = new ItemStack(Material.LEVER);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§b§l[Admin] Reload Config");
      ArrayList var3 = new ArrayList();
      var3.add("§7Reload config.yml");
      var3.add("§7All changes apply");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createConfigEditorItem() {
      ItemStack var1 = new ItemStack(Material.WRITABLE_BOOK);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§e§l[Admin] Config Editor");
      ArrayList var3 = new ArrayList();
      var3.add("§7Edit config values");
      var3.add("§7in-game!");
      var3.add("§aClick to open editor");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private void openEnabledGemsMenu(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§9§l[ADMIN] Enabled Gems");
      var2.setItem(10, this.createGemToggleItem(GemType.FIRE));
      var2.setItem(11, this.createGemToggleItem(GemType.SPEED));
      var2.setItem(12, this.createGemToggleItem(GemType.WEALTH));
      var2.setItem(13, this.createGemToggleItem(GemType.ASTRA));
      var2.setItem(14, this.createGemToggleItem(GemType.PUFF));
      var2.setItem(15, this.createGemToggleItem(GemType.FLUX));
      var2.setItem(16, this.createGemToggleItem(GemType.LIFE));
      var2.setItem(19, this.createGemToggleItem(GemType.STRENGTH));
      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private void openSettingsControl(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§6§l[ADMIN] Settings");
      int var3 = this.plugin.getConfig().getInt("energy.max-energy", 10);
      int var4 = this.plugin.getConfig().getInt("energy.starting-energy", 10);
      int var5 = this.plugin.getConfig().getInt("energy.gain-on-kill", 1);
      int var6 = this.plugin.getConfig().getInt("energy.loss-on-death", 1);
      var2.setItem(11, this.createSettingItem("Max Energy", var3, "Maximum energy capacity"));
      var2.setItem(13, this.createSettingItem("Starting Energy", var4, "Energy for new gems"));
      var2.setItem(15, this.createSettingItem("Gain on Kill", var5, "Energy gained per kill"));
      var2.setItem(20, this.createSettingItem("Loss on Death", var6, "Energy lost on death"));
      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private void openGemOpsMenu(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§d§l[ADMIN] Gem Operations");
      var2.setItem(11, this.createGiveItemButton("Energy Bottle", Material.HONEY_BOTTLE, "Give 1 energy bottle"));
      var2.setItem(13, this.createGiveItemButton("Repair Kit", Material.RECOVERY_COMPASS, "Give 1 repair kit"));
      var2.setItem(15, this.createGiveItemButton("Upgrader", Material.NETHER_STAR, "Give 1 upgrader"));
      var2.setItem(20, this.createGiveItemButton("Trader", Material.EMERALD, "Give 1 trader"));
      var2.setItem(22, this.createGiveItemButton("Gem Fragment", Material.PRISMARINE_SHARD, "Give 1 gem fragment"));
      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private void openEnergyControl(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§c§l[ADMIN] Energy Control");
      var2.setItem(11, this.createEnergyOpButton("Set All to 10", "§aSet everyone to max energy"));
      var2.setItem(13, this.createEnergyOpButton("Set All to 5", "§eSet everyone to half energy"));
      var2.setItem(15, this.createEnergyOpButton("Add 1 to All", "§bGive everyone +1 energy"));
      var2.setItem(20, this.createEnergyOpButton("Remove 1 from All", "§cTake -1 energy from everyone"));
      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private void openPlayersControl(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§a§l[ADMIN] Player Management");
      ArrayList var3 = new ArrayList(Bukkit.getOnlinePlayers());
      int var4 = 0;

      for(int var5 = 0; var5 < Math.min(45, var3.size()); ++var5) {
         Player var6 = (Player)var3.get(var5);
         var2.setItem(var4++, this.createPlayerManageItem(var6));
      }

      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private void openConfigEditor(Player var1) {
      Inventory var2 = Bukkit.createInventory((InventoryHolder)null, 54, "§e§l[ADMIN] Config Editor");
      var2.setItem(10, this.createEditableConfigItem("Max Energy", "energy.max-energy", 10));
      var2.setItem(11, this.createEditableConfigItem("Starting Energy", "energy.starting-energy", 10));
      var2.setItem(12, this.createEditableConfigItem("Gain on Kill", "energy.gain-on-kill", 1));
      var2.setItem(13, this.createEditableConfigItem("Loss on Death", "energy.loss-on-death", 1));
      var2.setItem(19, this.createEditableConfigItem("Astra Daggers", "abilities.cooldowns.astra-daggers", 15));
      var2.setItem(20, this.createEditableConfigItem("Fire Fireball", "abilities.cooldowns.fire-fireball", 10));
      var2.setItem(21, this.createEditableConfigItem("Flux Ground", "abilities.cooldowns.flux-ground", 45));
      var2.setItem(22, this.createEditableConfigItem("Life Drainer", "abilities.cooldowns.life-heart-drainer", 60));
      var2.setItem(23, this.createEditableConfigItem("Puff Dash", "abilities.cooldowns.puff-dash", 5));
      var2.setItem(24, this.createEditableConfigItem("Speed Sedative", "abilities.cooldowns.speed-sedative", 35));
      var2.setItem(25, this.createEditableConfigItem("Strength Thorns", "abilities.cooldowns.strength-bloodthorns", 20));
      var2.setItem(28, this.createEditableConfigItem("Astral Projection", "abilities.cooldowns.astra-projection", 120));
      var2.setItem(29, this.createEditableConfigItem("Fire Campfire", "abilities.cooldowns.fire-campfire", 60));
      var2.setItem(30, this.createEditableConfigItem("Flux Beam", "abilities.cooldowns.flux-beam", 240));
      var2.setItem(31, this.createEditableConfigItem("Circle of Life", "abilities.cooldowns.life-circle-of-life", 60));
      var2.setItem(32, this.createEditableConfigItem("Breezy Bash", "abilities.cooldowns.puff-breezy-bash", 10));
      var2.setItem(33, this.createEditableConfigItem("Adrenaline Rush", "abilities.cooldowns.adrenaline-rush", 90));
      var2.setItem(34, this.createEditableConfigItem("Speed Storm", "abilities.cooldowns.speed-storm", 45));
      var2.setItem(37, this.createEditableConfigItem("Frailer", "abilities.cooldowns.strength-frailer", 25));
      var2.setItem(38, this.createEditableConfigItem("Chad Strength", "abilities.cooldowns.strength-chad", 30));
      var2.setItem(39, this.createEditableConfigItem("Durability Chip", "abilities.cooldowns.wealth-durability-chip", 30));
      var2.setItem(40, this.createEditableConfigItem("Unfortunate", "abilities.cooldowns.wealth-unfortunate", 90));
      var2.setItem(41, this.createEditableConfigItem("Rich Rush", "abilities.cooldowns.wealth-rich-rush", 540));
      var2.setItem(42, this.createEditableConfigItem("Amplification", "abilities.cooldowns.wealth-amplification", 180));
      var2.setItem(49, this.createBackButton());
      var1.openInventory(var2);
   }

   private ItemStack createGemToggleItem(GemType var1) {
      FileConfiguration var10000 = this.plugin.getConfig();
      String var10001 = var1.name().toLowerCase();
      boolean var2 = var10000.getBoolean("gems.enabled." + var10001, true);
      ItemStack var3 = new ItemStack(var2 ? Material.LIME_DYE : Material.GRAY_DYE);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName((var2 ? "§a" : "§7") + var1.getDisplayName());
      ArrayList var5 = new ArrayList();
      var5.add("§7Status: " + (var2 ? "§aEnabled" : "§cDisabled"));
      var5.add("");
      var5.add("§eClick to toggle!");
      var4.setLore(var5);
      var3.setItemMeta(var4);
      return var3;
   }

   private ItemStack createSettingItem(String var1, int var2, String var3) {
      ItemStack var4 = new ItemStack(Material.COMPARATOR);
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName("§6" + var1);
      ArrayList var6 = new ArrayList();
      var6.add("§7Current: §f" + var2);
      var6.add("§7" + var3);
      var6.add("");
      var6.add("§8(Read-only - use Config Editor)");
      var5.setLore(var6);
      var4.setItemMeta(var5);
      return var4;
   }

   private ItemStack createEditableConfigItem(String var1, String var2, int var3) {
      int var4 = this.plugin.getConfig().getInt(var2, var3);
      ItemStack var5 = new ItemStack(Material.PAPER);
      ItemMeta var6 = var5.getItemMeta();
      var6.setDisplayName("§e" + var1);
      ArrayList var7 = new ArrayList();
      var7.add("§7Current: §f" + var4);
      var7.add("§7Path: §8" + var2);
      var7.add("");
      var7.add("§aLeft-Click: §7+1");
      var7.add("§aShift Left-Click: §7+10");
      var7.add("§cRight-Click: §7-1");
      var7.add("§cShift Right-Click: §7-10");
      var6.setLore(var7);
      var5.setItemMeta(var6);
      return var5;
   }

   private ItemStack createGiveItemButton(String var1, Material var2, String var3) {
      ItemStack var4 = new ItemStack(var2);
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName("§d" + var1);
      ArrayList var6 = new ArrayList();
      var6.add("§7" + var3);
      var6.add("");
      var6.add("§eLeft-click: Give to yourself");
      var6.add("§eRight-click: Give to all online");
      var5.setLore(var6);
      var4.setItemMeta(var5);
      return var4;
   }

   private ItemStack createEnergyOpButton(String var1, String var2) {
      ItemStack var3 = new ItemStack(Material.REDSTONE);
      ItemMeta var4 = var3.getItemMeta();
      var4.setDisplayName("§c" + var1);
      ArrayList var5 = new ArrayList();
      var5.add(var2);
      var5.add("");
      var5.add("§eClick to execute!");
      var4.setLore(var5);
      var3.setItemMeta(var4);
      return var3;
   }

   private ItemStack createPlayerManageItem(Player var1) {
      ItemStack var2 = new ItemStack(Material.PLAYER_HEAD);
      ItemMeta var3 = var2.getItemMeta();
      var3.setDisplayName("§e" + var1.getName());
      GemType var4 = this.plugin.getGemManager().getGemType(var1);
      int var5 = this.plugin.getEnergyManager().getEnergy(var1);
      ArrayList var6 = new ArrayList();
      String var10001 = var4 != null ? var4.getDisplayName() : "None";
      var6.add("§7Gem: §f" + var10001);
      var6.add("§7Energy: §f" + var5 + "§8/§f10");
      var6.add("");
      var6.add("§eLeft-click: Manage player");
      var3.setLore(var6);
      var2.setItemMeta(var3);
      return var2;
   }

   private ItemStack createBackButton() {
      ItemStack var1 = new ItemStack(Material.BARRIER);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName("§c« Back");
      ArrayList var3 = new ArrayList();
      var3.add("§7Return to main menu");
      var2.setLore(var3);
      var1.setItemMeta(var2);
      return var1;
   }

   private ItemStack createBorderItem(Player var1) {
      GemType var2 = this.plugin.getGemManager().getGemType(var1);
      Material var3 = Material.GRAY_STAINED_GLASS_PANE;
      if (var2 != null) {
         Material var10000;
         switch (var2) {
            case FIRE -> var10000 = Material.RED_STAINED_GLASS_PANE;
            case SPEED -> var10000 = Material.YELLOW_STAINED_GLASS_PANE;
            case WEALTH -> var10000 = Material.CYAN_STAINED_GLASS_PANE;
            case ASTRA -> var10000 = Material.MAGENTA_STAINED_GLASS_PANE;
            case PUFF -> var10000 = Material.LIME_STAINED_GLASS_PANE;
            case FLUX -> var10000 = Material.BLUE_STAINED_GLASS_PANE;
            case LIFE -> var10000 = Material.PINK_STAINED_GLASS_PANE;
            case STRENGTH -> var10000 = Material.ORANGE_STAINED_GLASS_PANE;
            default -> throw new IncompatibleClassChangeError();
         }

         var3 = var10000;
      }

      ItemStack var4 = new ItemStack(var3);
      ItemMeta var5 = var4.getItemMeta();
      var5.setDisplayName(" ");
      var4.setItemMeta(var5);
      return var4;
   }

   private ItemStack createAdminBorderItem() {
      ItemStack var1 = new ItemStack(Material.RED_STAINED_GLASS_PANE);
      ItemMeta var2 = var1.getItemMeta();
      var2.setDisplayName(" ");
      var1.setItemMeta(var2);
      return var1;
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent var1) {
      String var2 = var1.getView().getTitle();
      Player var3 = (Player)var1.getWhoClicked();
      if (var2.equals("§5§lBlissGems Menu") || var2.equals("§c§l[ADMIN] BlissGems Control") || var2.equals("§9§l[ADMIN] Enabled Gems") || var2.equals("§6§l[ADMIN] Settings") || var2.equals("§d§l[ADMIN] Gem Operations") || var2.equals("§c§l[ADMIN] Energy Control") || var2.equals("§a§l[ADMIN] Player Management") || var2.equals("§e§l[ADMIN] Config Editor")) {
         var1.setCancelled(true);
         int var4 = var1.getSlot();
         boolean var5 = var1.getClick().isRightClick();
         boolean var6 = var1.getClick().isShiftClick();
         if (var2.equals("§c§l[ADMIN] BlissGems Control")) {
            this.handleAdminDashboardClick(var3, var4);
         } else if (var2.equals("§5§lBlissGems Menu")) {
            this.handlePlayerGuiClick(var3, var4);
         } else if (var2.equals("§9§l[ADMIN] Enabled Gems")) {
            this.handleEnabledGemsClick(var3, var4);
         } else if (var2.equals("§6§l[ADMIN] Settings")) {
            this.handleSettingsClick(var3, var4);
         } else if (var2.equals("§d§l[ADMIN] Gem Operations")) {
            this.handleGemOpsClick(var3, var4, var5);
         } else if (var2.equals("§c§l[ADMIN] Energy Control")) {
            this.handleEnergyControlClick(var3, var4);
         } else if (var2.equals("§a§l[ADMIN] Player Management")) {
            this.handlePlayersClick(var3, var4);
         } else if (var2.equals("§e§l[ADMIN] Config Editor")) {
            this.handleConfigEditorClick(var3, var4, var5, var6);
         }
      }

   }

   private void handlePlayerGuiClick(Player var1, int var2) {
      switch (var2) {
         case 15:
            this.handleRerollGem(var1);
         case 16:
         case 17:
         case 18:
         case 19:
         case 21:
         case 22:
         case 23:
         case 25:
         case 26:
         case 27:
         case 28:
         case 30:
         case 32:
         default:
            break;
         case 20:
            var1.closeInventory();
            var1.sendMessage("§c§l⚔ ABILITIES §r§7- Check /bliss for ability commands!");
            var1.sendMessage("§7Your gem abilities can be activated by right-clicking your gem.");
            break;
         case 24:
            var1.closeInventory();
            var1.sendMessage("§3§l⏱ COOLDOWNS §r§7- Hold your gem to see cooldowns in action bar!");
            break;
         case 29:
            var1.closeInventory();
            var1.performCommand("bliss trusted");
            break;
         case 31:
            var1.closeInventory();
            var1.performCommand("bliss stats me");
            break;
         case 33:
            this.handleSettingsToggle(var1);
      }

   }

   private void handleRerollGem(Player var1) {
      if (!var1.hasPermission("blissgems.admin")) {
         var1.sendMessage("§c§lNo Permission! §7Only admins can reroll gems.");
         var1.playSound(var1.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0F, 1.0F);
      } else {
         int var2 = this.plugin.getEnergyManager().getEnergy(var1);
         if (var2 < 2) {
            var1.sendMessage("§c§lInsufficient Energy! §7You need §c2 energy §7to reroll.");
            var1.playSound(var1.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0F, 1.0F);
         } else {
            GemType var3 = this.plugin.getGemManager().getGemType(var1);
            if (var3 == null) {
               var1.sendMessage("§c§lNo gem found! §7You need a gem to reroll.");
               var1.playSound(var1.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0F, 1.0F);
            } else {
               GemType[] var4 = GemType.values();

               GemType var5;
               do {
                  var5 = var4[(new Random()).nextInt(var4.length)];
               } while(var5 == var3);

               boolean var6 = this.plugin.getGemManager().replaceGemType(var1, var5);
               if (!var6) {
                  var1.sendMessage("§c§lReroll failed! §7Could not replace gem.");
                  var1.playSound(var1.getLocation(), Sound.ENTITY_VILLAGER_NO, 1.0F, 1.0F);
               } else {
                  this.plugin.getEnergyManager().setEnergy(var1, var2 - 2);
                  var1.closeInventory();
                  var1.sendMessage("§a§l✔ GEM REROLLED!");
                  var1.sendMessage("§7New Gem: §f" + var5.getDisplayName());
                  var1.sendMessage("§7Energy: §c" + (var2 - 2) + " §8(-2)");
                  var1.playSound(var1.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
                  var1.playSound(var1.getLocation(), Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0F, 1.2F);
                  var1.spawnParticle(Particle.TOTEM_OF_UNDYING, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                  var1.spawnParticle(Particle.ENCHANT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, 0.8, (double)1.0F, 0.8);
               }
            }
         }
      }
   }

   private void handleSettingsToggle(Player var1) {
      boolean var2 = this.plugin.getClickActivationManager().isClickActivationEnabled(var1);
      this.plugin.getClickActivationManager().setClickActivation(var1, !var2);
      var1.sendMessage("§e§l⚙ SETTINGS");
      var1.sendMessage("§7Click Activation: " + (!var2 ? "§aEnabled" : "§cDisabled"));
      var1.playSound(var1.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
      this.openPlayerDashboard(var1);
   }

   private void handleAdminDashboardClick(Player var1, int var2) {
      switch (var2) {
         case 10:
            this.openPlayersControl(var1);
         case 11:
         case 13:
         case 15:
         case 17:
         case 18:
         case 20:
         case 22:
         default:
            break;
         case 12:
            this.openEnabledGemsMenu(var1);
            break;
         case 14:
            this.openSettingsControl(var1);
            break;
         case 16:
            this.openGemOpsMenu(var1);
            break;
         case 19:
            this.openEnergyControl(var1);
            break;
         case 21:
            var1.closeInventory();
            this.plugin.reloadConfig();
            this.plugin.getConfigManager().reload();
            var1.sendMessage("§a§l✔ Config reloaded successfully!");
            var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.5F);
            break;
         case 23:
            this.openConfigEditor(var1);
      }

   }

   private void handleEnabledGemsClick(Player var1, int var2) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         GemType var3 = null;
         switch (var2) {
            case 10:
               var3 = GemType.FIRE;
               break;
            case 11:
               var3 = GemType.SPEED;
               break;
            case 12:
               var3 = GemType.WEALTH;
               break;
            case 13:
               var3 = GemType.ASTRA;
               break;
            case 14:
               var3 = GemType.PUFF;
               break;
            case 15:
               var3 = GemType.FLUX;
               break;
            case 16:
               var3 = GemType.LIFE;
            case 17:
            case 18:
            default:
               break;
            case 19:
               var3 = GemType.STRENGTH;
         }

         if (var3 != null) {
            String var10000 = var3.name().toLowerCase();
            String var4 = "gems.enabled." + var10000;
            boolean var5 = this.plugin.getConfig().getBoolean(var4, true);
            this.plugin.getConfig().set(var4, !var5);
            this.plugin.saveConfig();
            String var10001 = var3.getDisplayName();
            var1.sendMessage("§e" + var10001 + " §7is now " + (!var5 ? "§aEnabled" : "§cDisabled"));
            var1.playSound(var1.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, !var5 ? 1.5F : 0.8F);
            this.openEnabledGemsMenu(var1);
         }

      }
   }

   private void handleSettingsClick(Player var1, int var2) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         var1.sendMessage("§7Settings are read-only. Use Config Editor to change values.");
         var1.playSound(var1.getLocation(), Sound.ENTITY_VILLAGER_NO, 0.5F, 1.0F);
      }
   }

   private void handleGemOpsClick(Player var1, int var2, boolean var3) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         String var4 = null;
         String var5 = null;
         switch (var2) {
            case 11:
               var4 = "energy_bottle";
               var5 = "Energy Bottle";
            case 12:
            case 14:
            case 16:
            case 17:
            case 18:
            case 19:
            case 21:
            default:
               break;
            case 13:
               var4 = "repair_kit";
               var5 = "Repair Kit";
               break;
            case 15:
               var4 = "gem_upgrader";
               var5 = "Upgrader";
               break;
            case 20:
               var4 = "gem_trader";
               var5 = "Trader";
               break;
            case 22:
               var4 = "gem_fragment";
               var5 = "Gem Fragment";
         }

         if (var4 != null) {
            if (var3) {
               int var6 = 0;

               for(Player var8 : Bukkit.getOnlinePlayers()) {
                  ItemStack var9 = CustomItemManager.getItemById(var4);
                  if (var9 != null) {
                     var8.getInventory().addItem(new ItemStack[]{var9});
                     var8.sendMessage("§a§l✔ Received " + var5 + " from admin!");
                     ++var6;
                  }
               }

               var1.sendMessage("§a§l✔ Gave " + var5 + " to " + var6 + " players!");
               var1.playSound(var1.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
            } else {
               ItemStack var10 = CustomItemManager.getItemById(var4);
               if (var10 != null) {
                  var1.getInventory().addItem(new ItemStack[]{var10});
                  var1.sendMessage("§a§l✔ Received " + var5 + "!");
                  var1.playSound(var1.getLocation(), Sound.ENTITY_ITEM_PICKUP, 1.0F, 1.5F);
               }
            }
         }

      }
   }

   private void handleEnergyControlClick(Player var1, int var2) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         int var3 = 0;
         String var4 = "";
         switch (var2) {
            case 11:
               for(Player var14 : Bukkit.getOnlinePlayers()) {
                  this.plugin.getEnergyManager().setEnergy(var14, 10);
                  ++var3;
               }

               var4 = "Set all players to 10 energy";
            case 12:
            case 14:
            case 16:
            case 17:
            case 18:
            case 19:
            default:
               break;
            case 13:
               for(Player var13 : Bukkit.getOnlinePlayers()) {
                  this.plugin.getEnergyManager().setEnergy(var13, 5);
                  ++var3;
               }

               var4 = "Set all players to 5 energy";
               break;
            case 15:
               for(Player var12 : Bukkit.getOnlinePlayers()) {
                  int var16 = this.plugin.getEnergyManager().getEnergy(var12);
                  this.plugin.getEnergyManager().setEnergy(var12, Math.min(10, var16 + 1));
                  ++var3;
               }

               var4 = "Added +1 energy to all players";
               break;
            case 20:
               for(Player var6 : Bukkit.getOnlinePlayers()) {
                  int var7 = this.plugin.getEnergyManager().getEnergy(var6);
                  this.plugin.getEnergyManager().setEnergy(var6, Math.max(0, var7 - 1));
                  ++var3;
               }

               var4 = "Removed -1 energy from all players";
         }

         if (!var4.isEmpty()) {
            var1.sendMessage("§c§l⚡ ENERGY CONTROL");
            var1.sendMessage("§7" + var4 + " §8(§f" + var3 + " §7players)");
            var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0F, 1.5F);

            for(Player var15 : Bukkit.getOnlinePlayers()) {
               var15.sendMessage("§c§l⚡ Energy updated by admin!");
            }
         }

      }
   }

   private void handlePlayersClick(Player var1, int var2) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         if (var2 < 45) {
            ArrayList var3 = new ArrayList(Bukkit.getOnlinePlayers());
            if (var2 < var3.size()) {
               Player var4 = (Player)var3.get(var2);
               var1.closeInventory();
               var1.sendMessage("§a§l» Managing: §f" + var4.getName());
               var1.sendMessage("§7Use commands:");
               var1.sendMessage("§e/bliss give " + var4.getName() + " <gem> [tier]");
               var1.sendMessage("§e/bliss energy " + var4.getName() + " set <amount>");
               var1.playSound(var1.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, 1.0F);
            }
         }

      }
   }

   private void handleConfigEditorClick(Player var1, int var2, boolean var3, boolean var4) {
      if (var2 == 49) {
         this.openMainMenu(var1);
      } else {
         String var5 = null;
         short var6 = 0;
         String var7 = "";
         switch (var2) {
            case 10:
               var5 = "energy.max-energy";
               var6 = 10;
               var7 = "Max Energy";
               break;
            case 11:
               var5 = "energy.starting-energy";
               var6 = 10;
               var7 = "Starting Energy";
               break;
            case 12:
               var5 = "energy.gain-on-kill";
               var6 = 1;
               var7 = "Gain on Kill";
               break;
            case 13:
               var5 = "energy.loss-on-death";
               var6 = 1;
               var7 = "Loss on Death";
            case 14:
            case 15:
            case 16:
            case 17:
            case 18:
            case 26:
            case 27:
            case 35:
            case 36:
            default:
               break;
            case 19:
               var5 = "abilities.cooldowns.astra-daggers";
               var6 = 15;
               var7 = "Astra Daggers";
               break;
            case 20:
               var5 = "abilities.cooldowns.fire-fireball";
               var6 = 10;
               var7 = "Fire Fireball";
               break;
            case 21:
               var5 = "abilities.cooldowns.flux-ground";
               var6 = 45;
               var7 = "Flux Ground";
               break;
            case 22:
               var5 = "abilities.cooldowns.life-heart-drainer";
               var6 = 60;
               var7 = "Life Drainer";
               break;
            case 23:
               var5 = "abilities.cooldowns.puff-dash";
               var6 = 5;
               var7 = "Puff Dash";
               break;
            case 24:
               var5 = "abilities.cooldowns.speed-sedative";
               var6 = 35;
               var7 = "Speed Sedative";
               break;
            case 25:
               var5 = "abilities.cooldowns.strength-bloodthorns";
               var6 = 20;
               var7 = "Strength Thorns";
               break;
            case 28:
               var5 = "abilities.cooldowns.astra-projection";
               var6 = 120;
               var7 = "Astral Projection";
               break;
            case 29:
               var5 = "abilities.cooldowns.fire-campfire";
               var6 = 60;
               var7 = "Fire Campfire";
               break;
            case 30:
               var5 = "abilities.cooldowns.flux-beam";
               var6 = 240;
               var7 = "Flux Beam";
               break;
            case 31:
               var5 = "abilities.cooldowns.life-circle-of-life";
               var6 = 60;
               var7 = "Circle of Life";
               break;
            case 32:
               var5 = "abilities.cooldowns.puff-breezy-bash";
               var6 = 10;
               var7 = "Breezy Bash";
               break;
            case 33:
               var5 = "abilities.cooldowns.adrenaline-rush";
               var6 = 90;
               var7 = "Adrenaline Rush";
               break;
            case 34:
               var5 = "abilities.cooldowns.speed-storm";
               var6 = 45;
               var7 = "Speed Storm";
               break;
            case 37:
               var5 = "abilities.cooldowns.strength-frailer";
               var6 = 25;
               var7 = "Frailer";
               break;
            case 38:
               var5 = "abilities.cooldowns.strength-chad";
               var6 = 30;
               var7 = "Chad Strength";
               break;
            case 39:
               var5 = "abilities.cooldowns.wealth-durability-chip";
               var6 = 30;
               var7 = "Durability Chip";
               break;
            case 40:
               var5 = "abilities.cooldowns.wealth-unfortunate";
               var6 = 90;
               var7 = "Unfortunate";
               break;
            case 41:
               var5 = "abilities.cooldowns.wealth-rich-rush";
               var6 = 540;
               var7 = "Rich Rush";
               break;
            case 42:
               var5 = "abilities.cooldowns.wealth-amplification";
               var6 = 180;
               var7 = "Amplification";
         }

         if (var5 != null) {
            int var8 = this.plugin.getConfig().getInt(var5, var6);
            int var9 = 0;
            if (var3) {
               var9 = var4 ? -10 : -1;
            } else {
               var9 = var4 ? 10 : 1;
            }

            int var10 = Math.max(0, var8 + var9);
            this.plugin.getConfig().set(var5, var10);
            this.plugin.saveConfig();
            var1.sendMessage("§e§l⚙ CONFIG EDITOR");
            var1.sendMessage("§7" + var7 + ": §f" + var8 + " §7→ §f" + var10 + " §8(" + (var9 >= 0 ? "+" : "") + var9 + ")");
            var1.playSound(var1.getLocation(), Sound.UI_BUTTON_CLICK, 1.0F, var9 >= 0 ? 1.2F : 0.8F);
            this.openConfigEditor(var1);
         }

      }
   }

   @EventHandler
   public void onInventoryClose(InventoryCloseEvent var1) {
      Player var2 = (Player)var1.getPlayer();
      this.playerPage.remove(var2.getUniqueId());
      this.playerSubPage.remove(var2.getUniqueId());
   }
}
