package dev.xoperr.blissgems.managers;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import java.util.stream.Collectors;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;

public class TrustedPlayersManager {
   private final BlissGems a;
   private final Map<UUID, Set<UUID>> b = new HashMap();
   private final File c;

   public TrustedPlayersManager(BlissGems var1) {
      this.a = var1;
      this.c = new File(var1.getDataFolder(), "playerdata");
      if (!this.c.exists()) {
         this.c.mkdirs();
      }

   }

   public boolean isTrusted(Player var1, Player var2) {
      if (var1.getUniqueId().equals(var2.getUniqueId())) {
         return true;
      } else {
         UUID var3 = var1.getUniqueId();
         if (!this.b.containsKey(var3)) {
            this.a(var1);
         }

         Set var4 = (Set)this.b.get(var3);
         return var4 != null && var4.contains(var2.getUniqueId());
      }
   }

   public void addTrustedPlayer(Player var1, Player var2) {
      UUID var3 = var1.getUniqueId();
      if (!this.b.containsKey(var3)) {
         this.a(var1);
      }

      Object var4 = (Set)this.b.get(var3);
      if (var4 == null) {
         var4 = new HashSet();
         this.b.put(var3, var4);
      }

      ((Set)var4).add(var2.getUniqueId());
      this.b(var1);
   }

   public boolean removeTrustedPlayer(Player var1, Player var2) {
      UUID var3 = var1.getUniqueId();
      if (!this.b.containsKey(var3)) {
         this.a(var1);
      }

      Set var4 = (Set)this.b.get(var3);
      if (var4 == null) {
         return false;
      } else {
         boolean var5 = var4.remove(var2.getUniqueId());
         if (var5) {
            this.b(var1);
         }

         return var5;
      }
   }

   public Set<UUID> getTrustedPlayers(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (!this.b.containsKey(var2)) {
         this.a(var1);
      }

      Set var3 = (Set)this.b.get(var2);
      return var3 != null ? new HashSet(var3) : new HashSet();
   }

   private void a(Player var1) {
      UUID var2 = var1.getUniqueId();
      File var3 = this.c(var1);
      HashSet var4 = new HashSet();
      if (var3.exists()) {
         YamlConfiguration var5 = YamlConfiguration.loadConfiguration(var3);

         for(String var8 : ((FileConfiguration)var5).getStringList("trusted-players")) {
            try {
               var4.add(UUID.fromString(var8));
            } catch (IllegalArgumentException var10) {
               Logger var10000 = this.a.getLogger();
               String var10001 = var1.getName();
               var10000.warning("Invalid UUID in trusted players for " + var10001 + ": " + var8);
            }
         }
      }

      this.b.put(var2, var4);
   }

   private void b(Player var1) {
      UUID var2 = var1.getUniqueId();
      Object var3 = (Set)this.b.get(var2);
      if (var3 == null) {
         var3 = new HashSet();
      }

      File var4 = this.c(var1);
      YamlConfiguration var5 = YamlConfiguration.loadConfiguration(var4);
      List var6 = (List)((Set)var3).stream().map(UUID::toString).collect(Collectors.toList());
      ((FileConfiguration)var5).set("trusted-players", var6);

      try {
         ((FileConfiguration)var5).save(var4);
      } catch (IOException var8) {
         Logger var10000 = this.a.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save trusted players for " + var10001 + ": " + var8.getMessage());
      }

   }

   private File c(Player var1) {
      return new File(this.c, String.valueOf(var1.getUniqueId()) + ".yml");
   }

   public void clearCache(Player var1) {
      this.b.remove(var1.getUniqueId());
   }
}
