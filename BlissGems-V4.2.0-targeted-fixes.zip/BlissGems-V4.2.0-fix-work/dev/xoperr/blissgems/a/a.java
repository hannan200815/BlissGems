package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Horse;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Vector;

public class a implements GemAbilityHandler {
   private final BlissGems a;
   private final Map<UUID, Horse> b = new HashMap();
   private final Map<UUID, BukkitTask> c = new HashMap();
   private final Set<UUID> d = new HashSet();
   private final Set<UUID> e = new HashSet();
   private final Map<UUID, BukkitTask> f = new HashMap();
   private final Map<UUID, Location> g = new HashMap();
   private final Map<UUID, GameMode> h = new HashMap();
   private final Set<UUID> i = new HashSet();
   private final Map<UUID, BukkitTask> j = new HashMap();
   private final Map<UUID, Integer> k = new HashMap();

   public a(BlissGems var1) {
      this.a = var1;
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.h(var1);
      } else {
         this.g(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.g(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.h(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.a(var1);
   }

   public void onQuaternary(Player var1, int var2) {
      this.b(var1);
   }

   public void a(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         this.j(var1);
      }
   }

   public void b(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         this.l(var1);
      }
   }

   public boolean c(Player var1) {
      return this.e.contains(var1.getUniqueId());
   }

   public Location d(Player var1) {
      return (Location)this.g.get(var1.getUniqueId());
   }

   public boolean e(Player var1) {
      return this.d.contains(var1.getUniqueId());
   }

   public boolean f(Player var1) {
      return this.i.contains(var1.getUniqueId());
   }

   public void g(Player var1) {
      String var2 = "astra-daggers";
      if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         Location var3 = var1.getEyeLocation();
         Vector var4 = var3.getDirection();

         for(int var5 = 0; var5 < 3; ++var5) {
            this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
               Location var5x = var3.clone().add(var4.clone().multiply(1));
               Vector var6 = var4.clone().rotateAroundAxis(new Vector(0, 1, 0), Math.toRadians((double)(var5 * 15 - 15)));
               boolean var7 = false;

               label53: {
                  for(int var8 = 0; var8 < 30; ++var8) {
                     Location var9 = var5x.clone().add(var6.clone().multiply((double)var8 * (double)0.5F));
                     Particle.DustOptions var10 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.0F);
                     var1.getWorld().spawnParticle(Particle.DUST, var9, 3, 0.1, 0.1, 0.1, (double)0.0F, var10, true);
                     var1.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var9, 2, 0.05, 0.05, 0.05, 0.01);
                     var1.getWorld().spawnParticle(Particle.WITCH, var9, 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);

                     for(Entity var12 : var9.getWorld().getNearbyEntities(var9, (double)0.5F, (double)0.5F, (double)0.5F)) {
                        if (var12 instanceof LivingEntity var13) {
                           if (var12 != var1) {
                              if (!(var12 instanceof Player)) {
                                 break label53;
                              }

                              Player var14 = (Player)var12;
                              if (var1.canSee(var14) && !this.a.getTrustedPlayersManager().isTrusted(var1, var14)) {
                                 break label53;
                              }
                           }
                        }
                     }

                     if (!var9.getBlock().getType().isSolid()) {
                        ;
                     }
                     break;
                  }

                  if (!var7) {
                     this.k.put(var1.getUniqueId(), 0);
                  }

                  return;
               }

               double var19 = this.a.getConfigManager().getAbilityDamage("astra-daggers");
               var13.damage(var19, var1);
               if (var13 instanceof Player && this.a.getAchievementManager() != null) {
                  UUID var16 = var1.getUniqueId();
                  int var17 = (Integer)this.k.getOrDefault(var16, 0) + 1;
                  this.k.put(var16, var17);
                  this.a.getAchievementManager().setProgress(var1, Achievement.PIERCING_PRECISION, var17);
               }

               Particle.DustOptions var20 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.5F);
               var13.getWorld().spawnParticle(Particle.DUST, var13.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 80, 0.9, 0.9, 0.9, (double)0.0F, var20, true);
               var13.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var13.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.7, 0.7, 0.7);
               var13.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var13.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, 0.7, 0.7, 0.7);
               var13.getWorld().spawnParticle(Particle.WITCH, var13.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F);
               var13.getWorld().spawnParticle(Particle.END_ROD, var13.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 25, (double)0.5F, (double)0.5F, (double)0.5F);
               var7 = true;
            }, (long)var5 * 5L);
         }

         var1.playSound(var1.getLocation(), Sound.ENTITY_ARROW_SHOOT, 1.0F, 1.5F);
         this.a.getAbilityManager().useAbility(var1, var2);
         String var7 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Astral Daggers");
         if (var7 != null && !var7.isEmpty()) {
            var1.sendMessage(var7);
         }

      }
   }

   public void h(final Player var1) {
      String var2 = "astra-projection";
      if (this.c(var1)) {
         this.i(var1);
      } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         UUID var3 = var1.getUniqueId();
         final Location var4 = var1.getLocation().clone();
         int var5 = this.a.getConfig().getInt("abilities.durations.astra-projection", 10);
         final int var6 = var5 * 20;
         final double var7 = this.a.getConfig().getDouble("abilities.astra-projection.radius", (double)128.0F);
         this.g.put(var3, var4);
         this.h.put(var3, var1.getGameMode());
         this.e.add(var3);
         Particle.DustOptions var9 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.0F);
         var4.getWorld().spawnParticle(Particle.DUST, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.4, (double)1.0F, 0.4, (double)0.0F, var9, true);
         var4.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 40, 0.4, (double)1.0F, 0.4);
         var4.getWorld().spawnParticle(Particle.SOUL, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, (double)0.5F, 0.3, 0.02);
         var1.playSound(var4, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0F, 1.5F);
         var1.playSound(var4, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.3F);
         var1.setGameMode(GameMode.SPECTATOR);
         BukkitTask var10 = (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && !var1.isDead() && a.this.c(var1)) {
                  ++this.a;
                  if (this.a % 4 == 0) {
                     Location var1x = var1.getLocation();
                     if (!var1x.getWorld().equals(var4.getWorld()) || var1x.distance(var4) > var7) {
                        var1.teleport(var4);
                        var1.sendMessage("§d§oYou cannot travel that far from your body!");
                     }
                  }

                  if (this.a % 20 == 0) {
                     Particle.DustOptions var2 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 0.7F);
                     var4.getWorld().spawnParticle(Particle.DUST, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 8, 0.3, 0.8, 0.3, (double)0.0F, var2, true);
                     var4.getWorld().spawnParticle(Particle.SOUL, var4.clone().add((double)0.0F, 1.2, (double)0.0F), 3, 0.2, 0.3, 0.2, 0.01);
                  }

                  int var3 = var6 - this.a;
                  if (var3 == 60) {
                     var1.sendMessage("§d§o3 seconds remaining...");
                  }

                  if (this.a >= var6) {
                     a.this.i(var1);
                     this.cancel();
                  }

               } else {
                  a.this.i(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.f.put(var3, var10);
         this.a.getAbilityManager().useAbility(var1, var2);
         String var11 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Astral Projection");
         if (var11 != null && !var11.isEmpty()) {
            var1.sendMessage(var11);
         }

         var1.sendMessage("§d§oYour soul leaves your body... (" + var5 + "s)");
      }
   }

   public void i(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (this.e.contains(var2)) {
         this.e.remove(var2);
         BukkitTask var3 = (BukkitTask)this.f.remove(var2);
         if (var3 != null) {
            var3.cancel();
         }

         Location var4 = (Location)this.g.remove(var2);
         GameMode var5 = (GameMode)this.h.remove(var2);
         if (var1.isOnline()) {
            if (var4 != null) {
               var1.teleport(var4);
            }

            var1.setGameMode(var5 != null ? var5 : GameMode.SURVIVAL);
            Location var6 = var1.getLocation();
            Particle.DustOptions var7 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.0F);
            var6.getWorld().spawnParticle(Particle.DUST, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.4, (double)1.0F, 0.4, (double)0.0F, var7, true);
            var6.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 40, 0.4, (double)1.0F, 0.4);
            var6.getWorld().spawnParticle(Particle.SOUL, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 15, 0.3, (double)0.5F, 0.3, 0.02);
            var1.playSound(var6, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0F, 0.8F);
            var1.sendMessage("§d§oYour soul returns to your body.");
         }

      }
   }

   public void j(final Player var1) {
      String var2 = "astra-drift";
      if (this.e(var1)) {
         this.k(var1);
      } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         UUID var3 = var1.getUniqueId();
         Location var4 = var1.getLocation();
         int var5 = this.a.getConfig().getInt("abilities.durations.astra-drift", 15);
         final int var6 = var5 * 20;
         Horse var7 = (Horse)var1.getWorld().spawn(var4, Horse.class, (var1x) -> {
            var1x.setTamed(true);
            var1x.setOwner(var1);
            var1x.setAdult();
            var1x.setInvisible(true);
            var1x.setSilent(true);
            var1x.setInvulnerable(true);
            var1x.setAI(false);
            var1x.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, Integer.MAX_VALUE, 0, false, false));
            var1x.getInventory().setSaddle(new ItemStack(Material.SADDLE));
         });
         var7.addPassenger(var1);
         this.b.put(var3, var7);
         this.d.add(var3);
         var1.addPotionEffect(new PotionEffect(PotionEffectType.INVISIBILITY, var6 + 20, 0, false, false));
         Particle.DustOptions var8 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.3F);
         var4.getWorld().spawnParticle(Particle.DUST, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.6, (double)1.0F, 0.6, (double)0.0F, var8, true);
         var4.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var4.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, 0.8, (double)0.5F, 0.02);
         var4.getWorld().spawnParticle(Particle.WITCH, var4, 20, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
         var1.playSound(var4, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0F, 1.5F);
         var1.playSound(var4, Sound.ENTITY_HORSE_SADDLE, 0.5F, 2.0F);
         BukkitTask var9 = (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && !var1.isDead() && a.this.e(var1)) {
                  ++this.a;
                  if (this.a % 8 == 0) {
                     Location var1x = var1.getLocation();
                     Particle.DustOptions var2 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 0.5F);
                     var1x.getWorld().spawnParticle(Particle.DUST, var1x.clone().add((double)0.0F, 0.3, (double)0.0F), 2, 0.3, 0.1, 0.3, (double)0.0F, var2, true);
                     var1x.getWorld().spawnParticle(Particle.END_ROD, var1x.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 1, 0.2, 0.1, 0.2, 0.005);
                  }

                  if (this.a >= var6) {
                     a.this.k(var1);
                     this.cancel();
                  }

               } else {
                  a.this.k(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.c.put(var3, var9);
         String var10 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Dimensional Drift");
         if (var10 != null && !var10.isEmpty()) {
            var1.sendMessage(var10);
         }

         var1.sendMessage("§d§oYou fade into the dimensional rift... (" + var5 + "s)");
      }
   }

   public void k(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (this.d.contains(var2)) {
         this.d.remove(var2);
         BukkitTask var3 = (BukkitTask)this.c.remove(var2);
         if (var3 != null) {
            var3.cancel();
         }

         Horse var4 = (Horse)this.b.remove(var2);
         if (var4 != null) {
            var4.removePassenger(var1);
            var4.remove();
         }

         var1.removePotionEffect(PotionEffectType.INVISIBILITY);
         Location var5 = var1.getLocation();
         Particle.DustOptions var6 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.3F);
         var5.getWorld().spawnParticle(Particle.DUST, var5.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.6, (double)1.0F, 0.6, (double)0.0F, var6, true);
         var5.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var5.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, 0.8, (double)0.5F, 0.02);
         var1.playSound(var5, Sound.ENTITY_ILLUSIONER_MIRROR_MOVE, 1.0F, 0.8F);
         this.a.getAbilityManager().useAbility(var1, "astra-drift");
         var1.sendMessage("§d§oDimensional Drift ended.");
      }
   }

   public void l(final Player var1) {
      String var2 = "astra-void";
      if (this.f(var1)) {
         var1.sendMessage("§c§oDimensional Void is already active!");
      } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         UUID var3 = var1.getUniqueId();
         Location var4 = var1.getLocation().clone();
         final double var5 = this.a.getConfig().getDouble("abilities.astra-void.radius", (double)10.0F);
         int var7 = this.a.getConfig().getInt("abilities.durations.astra-void", 8);
         final int var8 = var7 * 20;
         this.i.add(var3);
         ParticleUtils.drawDome(var4, ParticleUtils.ASTRA_PURPLE, 1.2F, var5);
         var1.playSound(var4, Sound.ENTITY_WARDEN_SONIC_BOOM, 0.8F, 1.5F);
         var1.playSound(var4, Sound.BLOCK_BEACON_DEACTIVATE, 1.0F, 0.5F);

         for(Entity var10 : var4.getWorld().getNearbyEntities(var4, var5, var5, var5)) {
            if (var10 instanceof Player && var10 != var1) {
               Player var11 = (Player)var10;
               if (!this.a.getTrustedPlayersManager().isTrusted(var1, var11)) {
                  var11.sendMessage("§4§l§oYour gem abilities have been nullified!");
                  var11.playSound(var11.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 1.0F, 0.3F);
               }
            }
         }

         BukkitTask var12 = (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && !var1.isDead() && this.a < var8) {
                  ++this.a;
                  if (this.a % 20 == 0) {
                     Location var1x = var1.getLocation();

                     for(Entity var3 : var1x.getWorld().getNearbyEntities(var1x, var5, var5, var5)) {
                        if (var3 instanceof Player && var3 != var1) {
                           Player var4 = (Player)var3;
                           if (!a.this.a.getTrustedPlayersManager().isTrusted(var1, var4)) {
                              var4.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 30, 1, false, true));
                              var4.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 30, 0, false, true));
                           }
                        }
                     }
                  }

                  if (this.a % 10 == 0) {
                     Location var12 = var1.getLocation();
                     Particle.DustOptions var13 = new Particle.DustOptions(ParticleUtils.ASTRA_PURPLE, 1.0F);

                     for(int var14 = 0; var14 < 32; ++var14) {
                        double var16 = (double)var14 / (double)32.0F * (double)2.0F * Math.PI;
                        double var6 = Math.cos(var16) * var5;
                        double var8x = Math.sin(var16) * var5;
                        var12.getWorld().spawnParticle(Particle.DUST, var12.clone().add(var6, 0.3, var8x), 2, 0.1, 0.1, 0.1, (double)0.0F, var13, true);
                        var12.getWorld().spawnParticle(Particle.REVERSE_PORTAL, var12.clone().add(var6, 0.8, var8x), 1, 0.1, 0.1, 0.1, 0.01);
                     }

                     for(int var15 = 0; var15 < 4; ++var15) {
                        double var17 = (double)var15 * Math.PI / (double)2.0F;
                        double var18 = Math.cos(var17) * var5;
                        double var19 = Math.sin(var17) * var5;

                        for(double var10 = (double)0.0F; var10 < (double)3.0F; var10 += (double)0.5F) {
                           var12.getWorld().spawnParticle(Particle.SOUL, var12.clone().add(var18, var10, var19), 1, 0.05, 0.1, 0.05, 0.01);
                        }
                     }
                  }

                  if (this.a % 40 == 0) {
                     var1.getLocation().getWorld().playSound(var1.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.5F, 0.3F);
                  }

               } else {
                  a.this.n(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.j.put(var3, var12);
         this.a.getAbilityManager().useAbility(var1, var2);
         String var13 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Dimensional Void");
         if (var13 != null && !var13.isEmpty()) {
            var1.sendMessage(var13);
         }

         var1.sendMessage("§d§oDimensional Void active for " + var7 + "s. Enemy abilities nullified in " + (int)var5 + " block radius.");
      }
   }

   private void n(Player var1) {
      UUID var2 = var1.getUniqueId();
      this.i.remove(var2);
      BukkitTask var3 = (BukkitTask)this.j.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

      if (var1.isOnline()) {
         var1.sendMessage("§d§oDimensional Void faded.");
         var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 0.5F, 1.5F);
      }

   }

   public boolean m(Player var1) {
      for(UUID var3 : this.i) {
         Player var4 = Bukkit.getPlayer(var3);
         if (var4 != null && var4.isOnline() && var4.getWorld().equals(var1.getWorld())) {
            double var5 = this.a.getConfig().getDouble("abilities.astra-void.radius", (double)10.0F);
            if (var4.getLocation().distance(var1.getLocation()) <= var5 && !this.a.getTrustedPlayersManager().isTrusted(var4, var1)) {
               return true;
            }
         }
      }

      return false;
   }

   private LivingEntity b(Player var1, int var2) {
      RayTraceResult var3 = var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)var2, (var1x) -> var1x instanceof LivingEntity && var1x != var1);
      return var3 != null ? (LivingEntity)var3.getHitEntity() : null;
   }

   private String a(Location var1, Location var2) {
      Vector var3 = var2.toVector().subtract(var1.toVector()).normalize();
      double var4 = Math.atan2(var3.getZ(), var3.getX());
      double var6 = Math.toRadians((double)var1.getYaw());

      double var8;
      for(var8 = var4 - var6; var8 > Math.PI; var8 -= (Math.PI * 2D)) {
      }

      while(var8 < -Math.PI) {
         var8 += (Math.PI * 2D);
      }

      if (var8 > (-Math.PI / 4D) && var8 <= (Math.PI / 4D)) {
         return "→";
      } else if (var8 > (Math.PI / 4D) && var8 <= 2.356194490192345) {
         return "↓";
      } else {
         return var8 > -2.356194490192345 && var8 <= (-Math.PI / 4D) ? "↑" : "←";
      }
   }

   public void cleanup(Player var1) {
      if (this.c(var1)) {
         this.i(var1);
      }

      if (this.e(var1)) {
         this.k(var1);
      }

      if (this.f(var1)) {
         this.n(var1);
      }

   }
}
