package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class c implements GemAbilityHandler {
   private final BlissGems a;
   private static final Set<UUID> b = new HashSet();
   private final Map<UUID, Integer> c = new HashMap();
   private final Map<UUID, BukkitTask> d = new HashMap();
   private final Map<UUID, Long> e = new HashMap();
   private static final int f = 100;
   private static final int g = 300;

   public c(BlissGems var1) {
      this.a = var1;
   }

   public static boolean a(UUID var0) {
      return b.contains(var0);
   }

   public boolean a(Player var1) {
      return this.c.containsKey(var1.getUniqueId());
   }

   public int b(Player var1) {
      return (Integer)this.c.getOrDefault(var1.getUniqueId(), 0);
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.e(var1);
      } else {
         this.c(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.c(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.e(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.f(var1);
   }

   public void onQuaternary(Player var1, int var2) {
      this.g(var1);
   }

   public void c(final Player var1) {
      String var2 = "flux-beam";
      if (this.a(var1)) {
         long var5 = (Long)this.e.getOrDefault(var1.getUniqueId(), 0L);
         if (System.currentTimeMillis() - var5 >= 250L) {
            this.h(var1);
         }
      } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         final UUID var3 = var1.getUniqueId();
         this.c.put(var3, 0);
         this.e.put(var3, System.currentTimeMillis());
         var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.5F, 1.5F);
         var1.sendMessage("§b⚡ §oCharging Flux Beam... Right-click again to fire!");
         BukkitTask var4 = (new BukkitRunnable() {
            int a = 0;
            boolean b = false;

            public void run() {
               if (var1.isOnline() && !var1.isDead() && c.this.c.containsKey(var3)) {
                  ++this.a;
                  int var1x = Math.min(this.a * 100 / 300, 100);
                  c.this.c.put(var3, var1x);
                  c.this.b(var1, var1x);
                  Location var2 = var1.getLocation();
                  Particle.DustOptions var3x = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.0F);
                  double var4 = 1.4;

                  for(int var6 = 0; var6 < 8; ++var6) {
                     double var7 = (double)var6 / (double)8.0F * (double)2.0F * Math.PI + (double)this.a * 0.1;
                     double var9 = Math.cos(var7) * var4;
                     double var11 = Math.sin(var7) * var4;
                     var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add(var9, 0.2, var11), 3, 0.1, 0.1, 0.1, (double)0.0F, var3x, true);
                     var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var2.clone().add(var9 * 0.8, 0.8, var11 * 0.8), 2, 0.05, 0.05, 0.05, 0.02);
                  }

                  double var19 = (double)this.a * 0.3 % (Math.PI * 2D);
                  double var8 = (double)1.0F;

                  for(int var10 = 0; var10 < 3; ++var10) {
                     double var22 = (double)var10 * 0.4;
                     double var13 = Math.cos(var19 + (double)var10) * var8;
                     double var15 = Math.sin(var19 + (double)var10) * var8;
                     var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var2.clone().add(var13, var22, var15), 1, 0.05, 0.05, 0.05, (double)0.0F);
                  }

                  if (this.a % 5 == 0) {
                     int var20 = 5 + var1x / 15;
                     Particle.DustOptions var23 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 0.9F);
                     var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add((double)0.0F, 0.8, (double)0.0F), var20 * 2, 1.2, (double)0.5F, 1.2, (double)0.0F, var23, true);
                     var1.getWorld().spawnParticle(Particle.SMOKE, var2.clone().add((double)0.0F, (double)0.5F, (double)0.0F), var20, (double)1.5F, 0.4, (double)1.5F, 0.02);

                     for(int var12 = 0; var12 < 8; ++var12) {
                        double var24 = (double)var12 / (double)8.0F * (double)2.0F * Math.PI;
                        double var25 = Math.cos(var24) * 1.8;
                        double var17 = Math.sin(var24) * 1.8;
                        var1.getWorld().spawnParticle(Particle.END_ROD, var1.getLocation().add(var25, 0.1, var17), 2, 0.1, 0.1, 0.1, (double)0.0F);
                     }
                  }

                  if (var1x == 25 || var1x == 50 || var1x == 75) {
                     var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_AMBIENT, 0.3F, 1.0F + (float)var1x / 100.0F);
                  }

                  if (var1x >= 100 && !this.b) {
                     var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0F, 2.0F);
                     var1.sendMessage("§b⚡§l Fully charged! §eRight-click to fire!");
                     this.b = true;
                  }

                  if (var1x >= 100 && this.a % 3 == 0) {
                     Particle.DustOptions var21 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.0F);
                     var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add((double)0.0F, 0.6, (double)0.0F), 30, 1.8, 0.4, 1.8, (double)0.0F, var21, true);
                     var1.getWorld().spawnParticle(Particle.SMOKE, var2.clone().add((double)0.0F, 0.3, (double)0.0F), 20, (double)1.5F, 0.3, (double)1.5F, 0.08);
                     var1.getWorld().spawnParticle(Particle.END_ROD, var1.getLocation().add((double)0.0F, 0.1, (double)0.0F), 15, (double)2.0F, 0.1, (double)2.0F, (double)0.0F);
                  }

               } else {
                  c.this.d(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.d.put(var3, var4);
      }
   }

   private void b(Player var1, int var2) {
      int var3 = var2 / 5;
      StringBuilder var4 = new StringBuilder("§b⚡ Flux Beam: §e");

      for(int var5 = 0; var5 < 20; ++var5) {
         if (var5 < var3) {
            var4.append("█");
         } else {
            var4.append("§8█");
         }
      }

      var4.append(" §b").append(var2).append("%");
      var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var4.toString()));
   }

   private void h(Player var1) {
      UUID var2 = var1.getUniqueId();
      int var3 = (Integer)this.c.getOrDefault(var2, 0);
      if (var3 >= 100 && this.a.getAchievementManager() != null) {
         this.a.getAchievementManager().unlock(var1, Achievement.OVERCHARGED);
      }

      BukkitTask var4 = (BukkitTask)this.d.remove(var2);
      if (var4 != null) {
         var4.cancel();
      }

      this.c.remove(var2);
      this.e.remove(var2);
      if (var3 < 10) {
         var1.sendMessage("§c§oNot enough charge!");
      } else {
         LivingEntity var5 = this.e(var1, 30);
         if (var5 == null) {
            var1.sendMessage("§cNo target found!");
         } else {
            if (var5 instanceof Player) {
               Player var6 = (Player)var5;
               if (this.a.getTrustedPlayersManager().isTrusted(var1, var6)) {
                  int var7 = this.a.getConfig().getInt("abilities.damage.flux-beam-max-armor-damage", 150);
                  int var31 = (int)((double)var3 / (double)100.0F * (double)var7);
                  this.d(var6, var31);
                  String var40 = var6.getName();
                  var1.sendMessage("§a§lRestored " + var40 + "'s armor! (+" + var31 + " durability)");
                  this.a(var1.getEyeLocation(), var6.getEyeLocation().add((double)0.0F, (double)1.0F, (double)0.0F));
                  return;
               }
            }

            double var30 = this.a.getConfig().getDouble("abilities.damage.flux-beam-base", (double)5.0F);
            double var8 = (double)1.0F + (double)var3 / (double)50.0F;
            double var10 = var30 * var8;
            int var12 = this.a.getConfig().getInt("abilities.damage.flux-beam-max-armor-damage", 150);
            int var13 = (int)((double)var3 / (double)100.0F * (double)var12);
            if (var5 instanceof Player) {
               Player var14 = (Player)var5;
               if (var14.getGameMode() == GameMode.CREATIVE || var14.getGameMode() == GameMode.SPECTATOR) {
                  var1.sendMessage("§cCannot hit players in creative/spectator mode!");
                  return;
               }
            }

            double var32 = var5.getHealth();
            boolean var16 = var32 <= var10;
            boolean var17 = false;
            if (var16 && var5 instanceof Player) {
               Player var18 = (Player)var5;
               ItemStack var19 = var18.getInventory().getItemInMainHand();
               ItemStack var20 = var18.getInventory().getItemInOffHand();
               if (var19.getType() == Material.TOTEM_OF_UNDYING) {
                  var17 = true;
                  var18.getInventory().setItemInMainHand(new ItemStack(Material.AIR));
               } else if (var20.getType() == Material.TOTEM_OF_UNDYING) {
                  var17 = true;
                  var18.getInventory().setItemInOffHand(new ItemStack(Material.AIR));
               }

               if (var17) {
                  var18.setHealth((double)1.0F);
                  var18.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 800, 1));
                  var18.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 100, 1));
                  var18.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, 800, 0));
                  var18.getWorld().spawnParticle(Particle.TOTEM_OF_UNDYING, var18.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.5F);
                  var18.playSound(var18.getLocation(), Sound.ITEM_TOTEM_USE, 1.0F, 1.0F);
                  var1.sendMessage("§e⚡ Totem of Undying activated!");
               }
            }

            if (!var17) {
               double var33 = Math.max((double)0.0F, var32 - var10);
               var5.setHealth(var33);
            }

            if (var5 instanceof Player) {
               Player var34 = (Player)var5;
               this.c(var34, var13);
               var34.sendTitle("", "§c§l-" + String.format("%.1f", var10) + " HP", 5, 15, 10);
               Player.Spigot var10000 = var34.spigot();
               ChatMessageType var10001 = ChatMessageType.ACTION_BAR;
               String var10004 = String.format("%.1f", var10);
               var10000.sendMessage(var10001, new TextComponent("§c§l⚡ FLUX BEAM HIT! -" + var10004 + " HP §7(Armor: -" + var13 + ")"));
            }

            this.a(var1.getEyeLocation(), var5.getEyeLocation().add((double)0.0F, (double)1.0F, (double)0.0F));
            Location var35 = var5.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F);
            Particle.DustOptions var36 = new Particle.DustOptions(Color.fromRGB(255, 50, 50), 1.5F);
            Particle.DustOptions var37 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.3F);
            var5.getWorld().spawnParticle(Particle.DUST, var35, 150, 1.2, (double)1.5F, 1.2, (double)0.0F, var37, true);
            var5.getWorld().spawnParticle(Particle.DUST, var35, 100, 0.9, 1.2, 0.9, (double)0.0F, var36, true);
            var5.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var35, 200, (double)1.0F, 1.3, (double)1.0F, 0.15);
            var5.getWorld().spawnParticle(Particle.CRIT, var35, 80, 0.8, (double)1.0F, 0.8, 0.3);
            var5.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var35, 100, 0.9, 1.2, 0.9, 0.2);
            var5.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var35, 60, 0.7, (double)1.0F, 0.7, 0.08);
            var5.getWorld().spawnParticle(Particle.EXPLOSION, var35, 5, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);

            for(int var21 = 0; var21 < 32; ++var21) {
               double var22 = (double)var21 / (double)32.0F * (double)2.0F * Math.PI;
               double var24 = (double)1.5F;
               double var26 = Math.cos(var22) * var24;
               double var28 = Math.sin(var22) * var24;
               var5.getWorld().spawnParticle(Particle.DUST, var5.getLocation().add(var26, (double)0.5F, var28), 5, 0.1, 0.3, 0.1, (double)0.0F, var36, true);
               var5.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var5.getLocation().add(var26, (double)0.5F, var28), 3, 0.1, 0.2, 0.1, 0.05);
            }

            var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5F, 1.8F);
            var5.getWorld().playSound(var5.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.5F, 1.5F);
            var5.getWorld().playSound(var5.getLocation(), Sound.ENTITY_GENERIC_EXPLODE, 0.8F, 1.5F);
            var5.getWorld().playSound(var5.getLocation(), Sound.ENTITY_PLAYER_HURT, 1.0F, 0.8F);
            this.a.getAbilityManager().useAbility(var1, "flux-beam");
            String var38 = var5 instanceof Player ? ((Player)var5).getName() : var5.getType().name();
            var1.sendMessage("§b⚡§l FLUX BEAM HIT! §r§o" + var38 + " §7(" + var3 + "% charge)");
            String var39 = String.format("%.1f", var10);
            var1.sendMessage("§c  ❤ Damage: " + var39 + " HP §8| §7Armor: -" + var13);
         }
      }
   }

   private void a(Location var1, Location var2) {
      double var3 = var1.distance(var2);
      int var5 = (int)(var3 * (double)8.0F);
      Particle.DustOptions var6 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.2F);
      Particle.DustOptions var7 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 0.8F);

      for(int var8 = 0; var8 <= var5; ++var8) {
         double var9 = (double)var8 / (double)var5;
         double var11 = var1.getX() + (var2.getX() - var1.getX()) * var9;
         double var13 = var1.getY() + (var2.getY() - var1.getY()) * var9;
         double var15 = var1.getZ() + (var2.getZ() - var1.getZ()) * var9;
         new Location(var1.getWorld(), var11, var13, var15);
         var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var11, var13, var15, 8, 0.08, 0.08, 0.08, 0.03);
         var1.getWorld().spawnParticle(Particle.DUST, var11, var13, var15, 6, 0.1, 0.1, 0.1, (double)0.0F, var6, true);
         var1.getWorld().spawnParticle(Particle.DUST, var11, var13, var15, 4, 0.15, 0.15, 0.15, (double)0.0F, var7, true);
         var1.getWorld().spawnParticle(Particle.END_ROD, var11, var13, var15, 3, 0.05, 0.05, 0.05, 0.01);
         var1.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var11, var13, var15, 2, 0.08, 0.08, 0.08, 0.01);
         if (var8 % 3 == 0) {
            double var18 = (double)var8 * (double)0.5F;
            double var20 = (double)0.25F;

            for(int var22 = 0; var22 < 3; ++var22) {
               double var23 = var18 + (double)var22 * Math.PI * (double)2.0F / (double)3.0F;
               double var25 = Math.cos(var23) * var20;
               double var27 = Math.sin(var23) * var20;
               var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var11 + var25, var13, var15 + var27, 1, 0.02, 0.02, 0.02, (double)0.0F);
            }
         }
      }

   }

   private void c(Player var1, int var2) {
      if (var2 > 0) {
         for(ItemStack var6 : var1.getInventory().getArmorContents()) {
            if (var6 != null && var6.getType() != Material.AIR) {
               ItemMeta var7 = var6.getItemMeta();
               if (var7 instanceof Damageable) {
                  Damageable var8 = (Damageable)var7;
                  int var9 = var8.getDamage() + var2;
                  short var10 = var6.getType().getMaxDurability();
                  if (var9 >= var10) {
                     var6.setAmount(0);
                  } else {
                     var8.setDamage(var9);
                     var6.setItemMeta(var7);
                  }
               }
            }
         }

      }
   }

   private void d(Player var1, int var2) {
      if (var2 > 0) {
         for(ItemStack var6 : var1.getInventory().getArmorContents()) {
            if (var6 != null && var6.getType() != Material.AIR) {
               ItemMeta var7 = var6.getItemMeta();
               if (var7 instanceof Damageable) {
                  Damageable var8 = (Damageable)var7;
                  int var9 = Math.max(0, var8.getDamage() - var2);
                  var8.setDamage(var9);
                  var6.setItemMeta(var7);
               }
            }
         }

         var1.getWorld().spawnParticle(Particle.HAPPY_VILLAGER, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F);
         var1.playSound(var1.getLocation(), Sound.BLOCK_ANVIL_USE, 0.5F, 2.0F);
      }
   }

   public void d(Player var1) {
      UUID var2 = var1.getUniqueId();
      BukkitTask var3 = (BukkitTask)this.d.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

      this.c.remove(var2);
      this.e.remove(var2);
   }

   public void cleanup(Player var1) {
      this.d(var1);
   }

   public void e(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "flux-ground";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            LivingEntity var3 = this.e(var1, 20);
            if (var3 == null) {
               var1.sendMessage("§cNo target found!");
            } else {
               if (var3 instanceof Player) {
                  Player var4 = (Player)var3;
                  if (this.a.getTrustedPlayersManager().isTrusted(var1, var4)) {
                     var1.sendMessage("§c§lYou cannot stun " + var4.getName() + " because they are trusted!");
                     return;
                  }
               }

               int var14 = this.a.getConfig().getInt("abilities.durations.flux-ground-freeze", 5);
               int var5 = var14 * 20;
               var3.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, var5, 255, false, true));
               var3.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, var5, 255, false, true));
               var3.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, var5, 250, false, true));
               var3.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, var5, 1, false, true));
               if (var3 instanceof Player) {
                  b.add(var3.getUniqueId());
                  Bukkit.getScheduler().runTaskLater(this.a, () -> b.remove(var3.getUniqueId()), (long)var5);
               }

               Particle.DustOptions var6 = new Particle.DustOptions(ParticleUtils.FLUX_DARK_CYAN, 1.5F);
               var3.getWorld().spawnParticle(Particle.DUST, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 200, (double)1.0F, 1.8, (double)1.0F, (double)0.0F, var6, true);
               var3.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, 0.7, 1.2, 0.7);
               var3.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var3.getLocation(), 60, 0.7, 0.2, 0.7);
               var3.getWorld().spawnParticle(Particle.SMOKE, var3.getLocation().add((double)0.0F, (double)0.5F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F);

               for(int var7 = 0; var7 < 24; ++var7) {
                  double var8 = (double)var7 / (double)24.0F * (double)2.0F * Math.PI;
                  double var10 = Math.cos(var8) * 1.8;
                  double var12 = Math.sin(var8) * 1.8;
                  var3.getWorld().spawnParticle(Particle.DUST, var3.getLocation().add(var10, 0.1, var12), 8, 0.15, 0.15, 0.15, (double)0.0F, var6, true);
                  var3.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var3.getLocation().add(var10, (double)0.5F, var12), 3, 0.1, 0.1, 0.1, (double)0.0F);
               }

               var3.getWorld().playSound(var3.getLocation(), Sound.BLOCK_GLASS_BREAK, 1.0F, 0.5F);
               var3.getWorld().playSound(var3.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 0.8F, 1.5F);
               var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 1.0F, 1.2F);
               var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, 1.2, 1.2, 1.2);
               this.a.getAbilityManager().useAbility(var1, var2);
               String var15 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Ground");
               if (var15 != null && !var15.isEmpty()) {
                  var1.sendMessage(var15);
               }

               if (var3 instanceof Player) {
                  Player var16 = (Player)var3;
                  var16.sendMessage("§c§lYou have been grounded for " + var14 + " seconds! You cannot move or jump!");
               }

               String var17 = var3 instanceof Player ? ((Player)var3).getName() : var3.getType().name();
               var1.sendMessage("§b⚡ §oGrounded " + var17 + " for " + var14 + " seconds!");
            }
         }
      }
   }

   public void f(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "flux-flashbang";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            double var3 = this.a.getConfig().getDouble("abilities.flux-flashbang.radius", (double)8.0F);
            int var5 = this.a.getConfigManager().getAbilityDuration("flux-flashbang") * 20;
            Location var6 = var1.getLocation();
            int var7 = 0;

            for(Entity var9 : var1.getWorld().getNearbyEntities(var6, var3, var3, var3)) {
               if (var9 instanceof LivingEntity && !var9.equals(var1)) {
                  LivingEntity var10 = (LivingEntity)var9;
                  if (var10 instanceof Player) {
                     Player var11 = (Player)var10;
                     if (this.a.getTrustedPlayersManager().isTrusted(var1, var11)) {
                        continue;
                     }
                  }

                  var10.addPotionEffect(new PotionEffect(PotionEffectType.BLINDNESS, var5, 0, false, true));
                  var10.addPotionEffect(new PotionEffect(PotionEffectType.NAUSEA, var5, 1, false, true));
                  Particle.DustOptions var14 = new Particle.DustOptions(Color.WHITE, 1.5F);
                  var10.getWorld().spawnParticle(Particle.DUST, var10.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 80, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var14, true);
                  ++var7;
                  if (var10 instanceof Player) {
                     ((Player)var10).sendMessage("§f§lFLASHBANGED! §7You are blinded!");
                  }
               }
            }

            Particle.DustOptions var12 = new Particle.DustOptions(Color.WHITE, 2.0F);
            var6.getWorld().spawnParticle(Particle.DUST, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 200, var3 / (double)2.0F, var3 / (double)2.0F, var3 / (double)2.0F, (double)0.0F, var12, true);
            var6.getWorld().spawnParticle(Particle.FIREWORK, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 50, var3 / (double)3.0F, var3 / (double)3.0F, var3 / (double)3.0F, 0.2);
            var6.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var6.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 80, var3 / (double)2.0F, var3 / (double)2.0F, var3 / (double)2.0F, 0.1);
            var1.getWorld().playSound(var6, Sound.ENTITY_GENERIC_EXPLODE, 1.5F, 1.8F);
            var1.getWorld().playSound(var6, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.0F, 2.0F);
            this.a.getAbilityManager().useAbility(var1, var2);
            String var13 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Flashbang");
            if (var13 != null && !var13.isEmpty()) {
               var1.sendMessage(var13);
            }

            var1.sendMessage("§b⚡ §oFlashbang! Blinded " + var7 + " enemies!");
         }
      }
   }

   public void g(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "flux-kinetic-burst";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            double var3 = this.a.getConfig().getDouble("abilities.flux-kinetic-burst.radius", (double)6.0F);
            double var5 = this.a.getConfig().getDouble("abilities.flux-kinetic-burst.knockback", (double)2.5F);
            Location var7 = var1.getLocation();
            int var8 = 0;

            for(Entity var10 : var1.getWorld().getNearbyEntities(var7, var3, var3, var3)) {
               if (!var10.equals(var1)) {
                  if (var10 instanceof Player) {
                     Player var11 = (Player)var10;
                     if (this.a.getTrustedPlayersManager().isTrusted(var1, var11)) {
                        continue;
                     }
                  }

                  Vector var14 = var10.getLocation().toVector().subtract(var7.toVector());
                  if (var14.lengthSquared() > (double)0.0F) {
                     var14.normalize();
                  }

                  var14.setY((double)0.5F);
                  var14.multiply(var5);
                  var10.setVelocity(var14);
                  ++var8;
               }
            }

            var1.getWorld().spawnParticle(Particle.SONIC_BOOM, var7.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F);
            Particle.DustOptions var12 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.5F);
            var1.getWorld().spawnParticle(Particle.DUST, var7.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 150, var3 / (double)2.0F, var3 / (double)2.0F, var3 / (double)2.0F, (double)0.0F, var12, true);
            var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var7.clone().add((double)0.0F, (double)1.0F, (double)0.0F), 100, var3 / (double)2.0F, var3 / (double)2.0F, var3 / (double)2.0F, 0.2);
            ParticleUtils.drawRing(var7, ParticleUtils.FLUX_CYAN, 1.2F, var3 * 0.33, 0.1, 32);
            ParticleUtils.drawRing(var7, ParticleUtils.FLUX_CYAN, 1.2F, var3 * 0.66, 0.1, 32);
            ParticleUtils.drawRing(var7, ParticleUtils.FLUX_CYAN, 1.2F, var3, 0.1, 32);
            var1.getWorld().playSound(var7, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.5F, 0.8F);
            var1.getWorld().playSound(var7, Sound.ENTITY_GENERIC_EXPLODE, 1.2F, 0.5F);
            this.a.getAbilityManager().useAbility(var1, var2);
            String var13 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Kinetic Burst");
            if (var13 != null && !var13.isEmpty()) {
               var1.sendMessage(var13);
            }

            var1.sendMessage("§b⚡ §oKinetic Burst! Knocked back " + var8 + " entities!");
         }
      }
   }

   private LivingEntity e(Player player, int range) {
      // A small ray radius makes the beam easier to aim without changing its range.
      org.bukkit.util.RayTraceResult result = player.getWorld().rayTraceEntities(
         player.getEyeLocation(),
         player.getEyeLocation().getDirection(),
         (double) range,
         0.45D,
         entity -> entity instanceof LivingEntity && entity != player
      );
      if (result == null || !(result.getHitEntity() instanceof LivingEntity)) {
         return null;
      }
      return (LivingEntity) result.getHitEntity();
   }
}
