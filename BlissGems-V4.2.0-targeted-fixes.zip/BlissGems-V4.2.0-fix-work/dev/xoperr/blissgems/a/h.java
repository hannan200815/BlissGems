package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.util.RayTraceResult;

public class h implements GemAbilityHandler {
   private final BlissGems a;
   private final Map<UUID, Inventory> b;
   private final Map<UUID, Boolean> c;
   private final File d;
   private static final Set<UUID> e = new HashSet();
   private static final Map<UUID, ItemStack> f = new HashMap();
   private final Set<UUID> g = new HashSet();
   private static final String h = "amp_orig_";
   private static final String i = "ae_orig_";
   private static final Set<UUID> j = new HashSet();

   public h(BlissGems var1) {
      this.a = var1;
      this.b = new HashMap();
      this.c = new HashMap();
      this.d = new File(var1.getDataFolder(), "pockets");
      if (!this.d.exists()) {
         this.d.mkdirs();
      }

   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.d(var1);
      } else {
         this.b(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.b(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.d(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.c(var1);
   }

   public void onQuaternary(Player var1, int var2) {
      this.e(var1);
   }

   public void a(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         Inventory var2 = (Inventory)this.b.computeIfAbsent(var1.getUniqueId(), (var2x) -> {
            Inventory var3 = Bukkit.createInventory((InventoryHolder)null, 9, "§6§lPockets");
            this.a(var1.getUniqueId(), var3);
            return var3;
         });
         var1.openInventory(var2);
         var1.playSound(var1.getLocation(), Sound.BLOCK_CHEST_OPEN, 1.0F, 1.0F);
      }
   }

   public void b(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var3 = "wealth-unfortunate";
         if (this.a.getAbilityManager().canUseAbility(var1, var3)) {
            RayTraceResult var4 = var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)15.0F, (var1x) -> var1x instanceof Player && var1x != var1);
            Entity var2;
            if (var4 != null && (var2 = var4.getHitEntity()) instanceof Player) {
               Player var5 = (Player)var2;
               int var6 = this.a.getConfigManager().getAbilityDuration("wealth-unfortunate");
               UUID var7 = var5.getUniqueId();
               e.add(var7);
               Bukkit.getScheduler().runTaskLater(this.a, () -> {
                  e.remove(var7);
                  if (var5.isOnline()) {
                     var5.sendMessage("§a§oUnfortunate has worn off.");
                  }

               }, (long)var6 * 20L);
               Particle.DustOptions var8 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.5F);
               var5.getWorld().spawnParticle(Particle.DUST, var5.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var8, true);
               var5.getWorld().spawnParticle(Particle.SMOKE, var5.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F);
               var1.playSound(var1.getLocation(), Sound.ENTITY_WITCH_CELEBRATE, 1.0F, 0.8F);
               var5.sendMessage("§c§oYou've been afflicted with Unfortunate! Actions disabled for " + var6 + "s!");
               this.a.getAbilityManager().useAbility(var1, var3);
               this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Unfortunate");
            } else {
               var1.sendMessage("§cNo player target found!");
            }
         }
      }
   }

   public void c(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "wealth-item-lock";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            RayTraceResult var3 = var1.getWorld().rayTraceEntities(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)15.0F, (var1x) -> var1x instanceof Player && var1x != var1);
            if (var3 != null && var3.getHitEntity() instanceof Player) {
               Player var4 = (Player)var3.getHitEntity();
               ItemStack var5 = var4.getInventory().getItemInMainHand();
               if (var5 != null && !var5.getType().isAir()) {
                  UUID var6 = var4.getUniqueId();
                  f.put(var6, var5.clone());
                  int var7 = this.a.getConfig().getInt("abilities.durations.wealth-item-lock", 10);
                  Bukkit.getScheduler().runTaskLater(this.a, () -> {
                     f.remove(var6);
                     if (var4.isOnline()) {
                        var4.sendMessage("§a§oItem Lock has worn off.");
                     }

                  }, (long)var7 * 20L);
                  Particle.DustOptions var8 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.5F);
                  var4.getWorld().spawnParticle(Particle.DUST, var4.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var8, true);
                  var4.playSound(var4.getLocation(), Sound.BLOCK_CHAIN_PLACE, 1.0F, 0.5F);
                  String var9 = var5.getType().name().toLowerCase().replace('_', ' ');
                  if (var5.hasItemMeta() && var5.getItemMeta().hasDisplayName()) {
                     var9 = var5.getItemMeta().getDisplayName();
                  }

                  var4.sendMessage("§c§oYour " + var9 + " has been locked for " + var7 + "s!");
                  this.a.getAbilityManager().useAbility(var1, var2);
                  this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Item Lock");
               } else {
                  var1.sendMessage("§cTarget isn't holding an item!");
               }
            } else {
               var1.sendMessage("§cNo player target found!");
            }
         }
      }
   }

   public void d(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "wealth-rich-rush";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            int var3 = this.a.getConfigManager().getAbilityDuration("wealth-rich-rush");
            UUID var4 = var1.getUniqueId();
            var1.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, var3 * 20, 2, false, true));
            var1.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, var3 * 20, 3, false, true));
            j.add(var4);
            Bukkit.getScheduler().runTaskLater(this.a, () -> {
               j.remove(var4);
               Player var1 = Bukkit.getPlayer(var4);
               if (var1 != null && var1.isOnline()) {
                  var1.sendMessage("§e§oRich Rush has worn off.");
               }

            }, (long)var3 * 20L);
            Particle.DustOptions var5 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.5F);
            var1.playSound(var1.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1.0F, 1.5F);
            var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var5, true);
            var1.spawnParticle(Particle.TOTEM_OF_UNDYING, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F);
            this.a.getAbilityManager().useAbility(var1, var2);
            this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Rich Rush");
            var1.sendMessage("§6§lRich Rush! §eMob and ore drops doubled for " + var3 + "s!");
         }
      }
   }

   public static boolean a(UUID var0) {
      return j.contains(var0);
   }

   public void e(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "wealth-amplification";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            UUID var3 = var1.getUniqueId();
            if (this.g.contains(var3)) {
               var1.sendMessage("§c§oAmplification is already active!");
            } else {
               int var4 = this.a.getConfigManager().getAbilityDuration("wealth-amplification");
               boolean var5 = false;
               ItemStack[] var6 = var1.getInventory().getArmorContents();

               for(int var7 = 0; var7 < var6.length; ++var7) {
                  if (this.c(var6[var7])) {
                     var5 = true;
                  }
               }

               var1.getInventory().setArmorContents(var6);
               ItemStack var10 = var1.getInventory().getItemInMainHand();
               if (this.c(var10)) {
                  var5 = true;
               }

               ItemStack var8 = var1.getInventory().getItemInOffHand();
               if (this.c(var8)) {
                  var5 = true;
               }

               this.g.add(var3);
               Bukkit.getScheduler().runTaskLater(this.a, () -> {
                  this.g.remove(var3);
                  Player var2 = Bukkit.getPlayer(var3);
                  if (var2 != null && var2.isOnline()) {
                     this.g(var2);
                     var2.sendMessage("§e§oAmplification has worn off. Enchantments restored.");
                  }
               }, (long)var4 * 20L);
               Particle.DustOptions var9 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.5F);
               var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_POWER_SELECT, 1.0F, 1.5F);
               var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, (double)0.5F, (double)1.0F, (double)0.5F, (double)0.0F, var9, true);
               var1.spawnParticle(Particle.ENCHANT, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 80, (double)0.5F, (double)1.0F, (double)0.5F);
               if (this.a.getAchievementManager() != null && var5) {
                  this.a.getAchievementManager().unlock(var1, Achievement.BOUNDARY_BREAK);
               }

               this.a.getAbilityManager().useAbility(var1, var2);
               this.a.getConfigManager().sendFormattedMessage(var1, "ability-activated", "ability", "Amplification");
            }
         }
      }
   }

   private boolean c(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         Map var2 = var1.getEnchantments();
         if (var2.isEmpty()) {
            return false;
         } else {
            ItemMeta var3 = var1.getItemMeta();
            if (var3 == null) {
               return false;
            } else {
               PersistentDataContainer var4 = var3.getPersistentDataContainer();
               boolean var5 = false;

               for(Map.Entry var7 : var2.entrySet()) {
                  Enchantment var8 = (Enchantment)var7.getKey();
                  int var9 = (Integer)var7.getValue();
                  NamespacedKey var10 = new NamespacedKey(this.a, "ae_orig_" + var8.getKey().getKey());
                  if (!var4.has(var10, PersistentDataType.INTEGER)) {
                     NamespacedKey var11 = new NamespacedKey(this.a, "amp_orig_" + var8.getKey().getKey());
                     if (!var4.has(var11, PersistentDataType.INTEGER)) {
                        var4.set(var11, PersistentDataType.INTEGER, var9);
                        var3.addEnchant(var8, var9 + 1, true);
                        var5 = true;
                     }
                  }
               }

               if (var5) {
                  var1.setItemMeta(var3);
               }

               return var5;
            }
         }
      } else {
         return false;
      }
   }

   private void g(Player var1) {
      for(int var2 = 0; var2 < var1.getInventory().getSize(); ++var2) {
         ItemStack var3 = var1.getInventory().getItem(var2);
         if (var3 != null && !var3.getType().isAir()) {
            a(var3);
         }
      }

      ItemStack[] var5 = var1.getInventory().getArmorContents();
      boolean var6 = false;

      for(int var4 = 0; var4 < var5.length; ++var4) {
         if (var5[var4] != null && !var5[var4].getType().isAir() && a(var5[var4])) {
            var6 = true;
         }
      }

      if (var6) {
         var1.getInventory().setArmorContents(var5);
      }

      ItemStack var7 = var1.getInventory().getItemInOffHand();
      if (!var7.getType().isAir()) {
         a(var7);
      }

   }

   public static boolean a(ItemStack var0) {
      if (var0 != null && !var0.getType().isAir() && var0.hasItemMeta()) {
         ItemMeta var1 = var0.getItemMeta();
         if (var1 == null) {
            return false;
         } else {
            PersistentDataContainer var2 = var1.getPersistentDataContainer();
            boolean var3 = false;

            for(Enchantment var7 : Enchantment.values()) {
               NamespacedKey var8 = a(var0, var7);
               if (var8 != null && var2.has(var8, PersistentDataType.INTEGER)) {
                  int var9 = (Integer)var2.get(var8, PersistentDataType.INTEGER);
                  if (var9 == 0) {
                     var1.removeEnchant(var7);
                  } else {
                     var1.addEnchant(var7, var9, true);
                  }

                  var2.remove(var8);
                  var3 = true;
               }
            }

            if (var3) {
               var0.setItemMeta(var1);
            }

            return var3;
         }
      } else {
         return false;
      }
   }

   public static boolean b(ItemStack var0) {
      if (var0 != null && var0.hasItemMeta()) {
         PersistentDataContainer var1 = var0.getItemMeta().getPersistentDataContainer();

         for(Enchantment var5 : Enchantment.values()) {
            NamespacedKey var6 = a(var0, var5);
            if (var6 != null && var1.has(var6, PersistentDataType.INTEGER)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private static NamespacedKey a(ItemStack var0, Enchantment var1) {
      return !var0.hasItemMeta() ? null : NamespacedKey.fromString("blissgems:amp_orig_" + var1.getKey().getKey());
   }

   public static boolean b(UUID var0) {
      return e.contains(var0);
   }

   public static boolean a(UUID var0, double var1) {
      return e.contains(var0) && Math.random() < var1;
   }

   public static boolean c(UUID var0) {
      return f.containsKey(var0);
   }

   public static ItemStack d(UUID var0) {
      return (ItemStack)f.get(var0);
   }

   public void cleanup(Player var1) {
      UUID var2 = var1.getUniqueId();
      if (this.g.remove(var2)) {
         this.g(var1);
      }

      e.remove(var2);
      f.remove(var2);
      j.remove(var2);
   }

   public Inventory e(UUID var1) {
      return (Inventory)this.b.get(var1);
   }

   public boolean f(Player var1) {
      return (Boolean)this.c.getOrDefault(var1.getUniqueId(), false);
   }

   public void a(Player var1, boolean var2) {
      this.c.put(var1.getUniqueId(), var2);
   }

   public void f(UUID var1) {
      Inventory var2 = (Inventory)this.b.get(var1);
      if (var2 != null) {
         File var3 = new File(this.d, var1.toString() + ".yml");
         YamlConfiguration var4 = new YamlConfiguration();

         for(int var5 = 0; var5 < var2.getSize(); ++var5) {
            ItemStack var6 = var2.getItem(var5);
            if (var6 != null && !var6.getType().isAir()) {
               ((FileConfiguration)var4).set("items." + var5, var6);
            }
         }

         try {
            ((FileConfiguration)var4).save(var3);
         } catch (IOException var7) {
            Logger var10000 = this.a.getLogger();
            String var10001 = String.valueOf(var1);
            var10000.severe("Failed to save pockets inventory for " + var10001 + ": " + var7.getMessage());
         }

      }
   }

   private void a(UUID var1, Inventory var2) {
      File var3 = new File(this.d, var1.toString() + ".yml");
      if (var3.exists()) {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (((FileConfiguration)var4).contains("items")) {
            for(String var6 : ((FileConfiguration)var4).getConfigurationSection("items").getKeys(false)) {
               try {
                  int var7 = Integer.parseInt(var6);
                  ItemStack var8 = ((FileConfiguration)var4).getItemStack("items." + var6);
                  if (var8 != null && var7 >= 0 && var7 < var2.getSize()) {
                     var2.setItem(var7, var8);
                  }
               } catch (NumberFormatException var9) {
                  this.a.getLogger().warning("Invalid slot key in pockets data: " + var6);
               }
            }
         }

      }
   }

   public void a() {
      for(UUID var2 : this.b.keySet()) {
         this.f(var2);
      }

   }
}
