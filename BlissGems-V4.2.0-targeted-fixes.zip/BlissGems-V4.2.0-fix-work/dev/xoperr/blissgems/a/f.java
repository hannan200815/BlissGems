package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

public class f implements GemAbilityHandler {
   private final BlissGems a;
   private final Set<UUID> b = new HashSet();
   private final Map<UUID, BukkitTask> c = new HashMap();
   private static final Set<UUID> d = new HashSet();

   public f(BlissGems var1) {
      this.a = var1;
   }

   public static boolean a(UUID var0) {
      return d.contains(var0);
   }

   public static void b(UUID var0) {
      d.add(var0);
   }

   public static void c(UUID var0) {
      d.remove(var0);
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.d(var1);
      } else {
         this.c(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.a(var1, var2);
   }

   public void onSecondary(Player var1, int var2) {
      this.d(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.a(var1);
   }

   public void cleanup(Player var1) {
      this.d(var1.getUniqueId());
   }

   public void a(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         this.e(var1);
      }
   }

   public boolean b(Player var1) {
      return this.b.contains(var1.getUniqueId());
   }

   public void c(final Player var1) {
      String var2 = "speed-blur";
      if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         final int var3 = this.a.getConfig().getInt("abilities.blur.strikes", 3);
         int var4 = this.a.getConfig().getInt("abilities.blur.strike-delay", 8);
         final double var5 = this.a.getConfigManager().getAbilityDamage("blur");
         final double var7 = this.a.getConfig().getDouble("abilities.blur.knockback", (double)1.5F);
         final Location var9 = var1.getTargetBlock((Set)null, 20).getLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
         Particle.DustOptions var10 = new Particle.DustOptions(ParticleUtils.SPEED_YELLOW, 2.0F);
         var1.playSound(var1.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1.0F, 2.0F);
         var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 150, 0.8, 0.8, 0.8, (double)0.0F, var10, true);
         var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 80, 0.8, 0.8, 0.8);
         var1.spawnParticle(Particle.GUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F);
         (new BukkitRunnable() {
            int a = 0;

            public void run() {
               if (var1.isOnline() && this.a < var3) {
                  double var1x = (Math.random() - (double)0.5F) * (double)3.0F;
                  double var3x = (Math.random() - (double)0.5F) * (double)3.0F;
                  Location var5x = var9.clone().add(var1x, (double)0.0F, var3x);
                  var5x.getWorld().strikeLightningEffect(var5x);
                  Particle.DustOptions var6 = new Particle.DustOptions(ParticleUtils.SPEED_YELLOW, 2.5F);
                  var5x.getWorld().spawnParticle(Particle.DUST, var5x, 250, (double)1.5F, (double)2.0F, (double)1.5F, (double)0.0F, var6, true);
                  var5x.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var5x, 150, 1.2, (double)1.5F, 1.2, 0.1);
                  var5x.getWorld().spawnParticle(Particle.EXPLOSION, var5x, 8, (double)1.0F, (double)1.0F, (double)1.0F);
                  var5x.getWorld().spawnParticle(Particle.GUST, var5x, 60, (double)1.0F, (double)1.5F, (double)1.0F);

                  for(int var7x = 0; var7x < 32; ++var7x) {
                     double var8 = (double)var7x / (double)32.0F * (double)2.0F * Math.PI;
                     double var10 = Math.cos(var8) * (double)3.0F;
                     double var12 = Math.sin(var8) * (double)3.0F;
                     var5x.getWorld().spawnParticle(Particle.DUST, var5x.clone().add(var10, 0.2, var12), 8, 0.2, 0.1, 0.2, (double)0.0F, var6, true);
                  }

                  for(Entity var15 : var5x.getWorld().getNearbyEntities(var5x, (double)3.5F, (double)3.5F, (double)3.5F)) {
                     if (var15 instanceof LivingEntity) {
                        LivingEntity var9x = (LivingEntity)var15;
                        if (!var15.equals(var1)) {
                           if (var15 instanceof Player) {
                              Player var16 = (Player)var15;
                              if (f.this.a.getTrustedPlayersManager().isTrusted(var1, var16)) {
                                 continue;
                              }
                           }

                           var9x.damage(var5, var1);
                           Location var11 = var5x.clone();
                           (new BukkitRunnable() {
                              // $FF: synthetic field
                              final LivingEntity a;
                              // $FF: synthetic field
                              final Location b;
                              // $FF: synthetic field
                              final <undefinedtype> c;

                              {
                                 this.c = var1;
                                 this.a = var2;
                                 this.b = var3;
                              }

                              public void run() {
                                 if (this.a.isValid() && !this.a.isDead()) {
                                    Vector var1 = this.a.getLocation().toVector().subtract(this.b.toVector()).normalize().multiply(this.c.f).setY((double)0.5F);
                                    this.a.setVelocity(var1);
                                 }

                              }
                           }).runTaskLater(f.this.a, 1L);
                           var9x.getWorld().spawnParticle(Particle.DUST, var9x.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var6, true);
                           var9x.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var9x.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 25, (double)0.5F, (double)0.5F, (double)0.5F);
                        }
                     }
                  }

                  var5x.getWorld().playSound(var5x, Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5F, 1.0F);
                  var5x.getWorld().playSound(var5x, Sound.ENTITY_GENERIC_EXPLODE, 0.8F, 1.2F);
                  ++this.a;
               } else {
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, (long)var4);
         this.a.getAbilityManager().useAbility(var1, var2);
         String var11 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Blur");
         if (var11 != null && !var11.isEmpty()) {
            var1.sendMessage(var11);
         }

         var1.sendMessage("§e§oBlur unleashes " + var3 + " successive lightning strikes!");
      }
   }

   public void d(final Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "speed-storm";
         if (this.b(var1)) {
            this.f(var1);
         } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            UUID var3 = var1.getUniqueId();
            int var4 = this.a.getConfig().getInt("abilities.durations.speed-storm", 10);
            final int var5 = var4 * 20;
            final double var6 = this.a.getConfig().getDouble("abilities.speed-storm.radius", (double)8.0F);
            this.b.add(var3);
            Particle.DustOptions var8 = new Particle.DustOptions(ParticleUtils.SPEED_YELLOW, 2.0F);
            var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5F, 1.5F);
            var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 1.8F);
            var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 300, (double)2.0F, (double)2.0F, (double)2.0F, (double)0.0F, var8, true);
            var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 200, (double)2.0F, (double)2.0F, (double)2.0F);
            var1.spawnParticle(Particle.GUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, (double)1.5F, (double)1.5F, (double)1.5F);
            var1.spawnParticle(Particle.EXPLOSION, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)1.0F, (double)1.0F, (double)1.0F);
            BukkitTask var9 = (new BukkitRunnable() {
               int a = 0;

               public void run() {
                  if (var1.isOnline() && !var1.isDead() && this.a < var5) {
                     ++this.a;
                     Location var1x = var1.getLocation();
                     if (this.a % 20 == 0) {
                        for(Entity var3 : var1x.getWorld().getNearbyEntities(var1x, var6, var6, var6)) {
                           if (var3 instanceof Player) {
                              Player var4 = (Player)var3;
                              boolean var5x = f.this.a.getTrustedPlayersManager().isTrusted(var1, var4);
                              if (!var5x && !var4.equals(var1)) {
                                 f.b(var4.getUniqueId());
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 40, 255, false, true));
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, 40, 255, false, true));
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, 40, 128, false, true));
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, 40, 1, false, true));
                                 UUID var6x = var4.getUniqueId();
                                 (new BukkitRunnable() {
                                    // $FF: synthetic field
                                    final UUID a;
                                    // $FF: synthetic field
                                    final <undefinedtype> b;

                                    {
                                       this.b = var1;
                                       this.a = var2;
                                    }

                                    public void run() {
                                       Player var1 = this.b.e.a.getServer().getPlayer(this.a);
                                       if (var1 != null && var1.isOnline()) {
                                          boolean var2 = false;

                                          for(UUID var4 : this.b.e.b) {
                                             Player var5 = this.b.e.a.getServer().getPlayer(var4);
                                             if (var5 != null && var5.isOnline() && var1.getLocation().distance(var5.getLocation()) <= this.b.d) {
                                                var2 = true;
                                                break;
                                             }
                                          }

                                          if (!var2) {
                                             f.c(this.a);
                                          }

                                       } else {
                                          f.c(this.a);
                                       }
                                    }
                                 }).runTaskLater(f.this.a, 42L);
                              } else {
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 40, 2, false, true));
                                 var4.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, 40, 1, false, true));
                                 f.c(var4.getUniqueId());
                              }
                           }
                        }
                     }

                     if (this.a % 5 == 0) {
                        Particle.DustOptions var12 = new Particle.DustOptions(ParticleUtils.SPEED_YELLOW, 1.8F);

                        for(int var13 = 0; var13 < 40; ++var13) {
                           double var16 = (double)var13 / (double)40.0F * (double)2.0F * Math.PI;
                           double var18 = Math.cos(var16) * var6;
                           double var8 = Math.sin(var16) * var6;
                           var1x.getWorld().spawnParticle(Particle.DUST, var1x.clone().add(var18, 0.3, var8), 5, 0.2, 0.1, 0.2, (double)0.0F, var12, true);
                           var1x.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var1x.clone().add(var18, (double)0.5F, var8), 2, 0.1, 0.1, 0.1, 0.02);
                        }

                        for(int var14 = 0; var14 < 8; ++var14) {
                           double var17 = (double)var14 * Math.PI / (double)4.0F;
                           double var19 = Math.cos(var17) * var6;
                           double var20 = Math.sin(var17) * var6;

                           for(double var10 = (double)0.0F; var10 < (double)4.0F; var10 += (double)0.5F) {
                              var1x.getWorld().spawnParticle(Particle.DUST, var1x.clone().add(var19, var10, var20), 3, 0.1, 0.1, 0.1, (double)0.0F, var12, true);
                           }
                        }

                        for(double var15 = (double)0.0F; var15 < (double)3.0F; var15 += 0.3) {
                           var1x.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var1x.clone().add((double)0.0F, var15, (double)0.0F), 4, 0.2, 0.1, 0.2, 0.01);
                        }
                     }

                     if (this.a % 40 == 0) {
                        var1x.getWorld().playSound(var1x, Sound.BLOCK_BEACON_AMBIENT, 0.6F, 1.8F);
                     }

                  } else {
                     f.this.f(var1);
                     this.cancel();
                  }
               }
            }).runTaskTimer(this.a, 0L, 1L);
            this.c.put(var3, var9);
            this.a.getAbilityManager().useAbility(var1, var2);
            String var10 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Speed Storm");
            if (var10 != null && !var10.isEmpty()) {
               var1.sendMessage(var10);
            }

            var1.sendMessage("§e§oSpeed Storm active for " + var4 + "s! Allies gain Speed + Haste, enemies freeze!");
         }
      }
   }

   private void f(Player var1) {
      UUID var2 = var1.getUniqueId();
      this.b.remove(var2);
      BukkitTask var3 = (BukkitTask)this.c.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

      double var4 = this.a.getConfig().getDouble("abilities.speed-storm.radius", (double)8.0F);
      if (var1.isOnline()) {
         for(Entity var7 : var1.getLocation().getWorld().getNearbyEntities(var1.getLocation(), var4 + (double)5.0F, var4 + (double)5.0F, var4 + (double)5.0F)) {
            if (var7 instanceof Player) {
               Player var8 = (Player)var7;
               if (!var8.equals(var1)) {
                  UUID var9 = var8.getUniqueId();
                  if (a(var9)) {
                     boolean var10 = false;

                     for(UUID var12 : this.b) {
                        Player var13 = this.a.getServer().getPlayer(var12);
                        if (var13 != null && var13.isOnline() && !var13.equals(var1) && var8.getLocation().distance(var13.getLocation()) <= var4) {
                           var10 = true;
                           break;
                        }
                     }

                     if (!var10) {
                        c(var9);
                        var8.sendMessage("§e§oYou are no longer frozen.");
                     }
                  }
               }
            }
         }

         var1.sendMessage("§e§oSpeed Storm faded.");
         var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_DEACTIVATE, 0.6F, 1.5F);
      }

   }

   public void e(Player var1) {
      String var2 = "speed-terminal";
      if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         int var3 = this.a.getConfig().getInt("abilities.durations.terminal-velocity", 10) * 20;
         var1.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, var3, 2, false, true));
         var1.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, var3, 1, false, true));
         Particle.DustOptions var4 = new Particle.DustOptions(ParticleUtils.SPEED_YELLOW, 2.0F);
         var1.playSound(var1.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_THUNDER, 1.5F, 2.0F);
         var1.playSound(var1.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1.5F, 2.0F);
         var1.playSound(var1.getLocation(), Sound.BLOCK_BEACON_ACTIVATE, 1.0F, 2.0F);
         var1.spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 300, (double)1.5F, (double)2.0F, (double)1.5F, (double)0.0F, var4, true);
         var1.spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 200, (double)1.5F, (double)2.0F, (double)1.5F);
         var1.spawnParticle(Particle.GUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 100, (double)1.0F, (double)1.5F, (double)1.0F);
         var1.spawnParticle(Particle.EXPLOSION, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 8, (double)1.0F, (double)1.0F, (double)1.0F);
         var1.spawnParticle(Particle.HAPPY_VILLAGER, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 60, (double)1.0F, (double)1.0F, (double)1.0F);

         for(int var5 = 0; var5 < 32; ++var5) {
            double var6 = (double)var5 / (double)32.0F * (double)2.0F * Math.PI;
            double var8 = Math.cos(var6) * (double)2.5F;
            double var10 = Math.sin(var6) * (double)2.5F;
            var1.getWorld().spawnParticle(Particle.DUST, var1.getLocation().add(var8, (double)0.5F, var10), 8, 0.2, 0.1, 0.2, (double)0.0F, var4, true);
            var1.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var1.getLocation().add(var8, (double)1.0F, var10), 4, 0.1, 0.1, 0.1);
         }

         this.a.getAbilityManager().useAbility(var1, var2);
         String var12 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Terminal Velocity");
         if (var12 != null && !var12.isEmpty()) {
            var1.sendMessage(var12);
         }

         var1.sendMessage("§e§l⚡ TERMINAL VELOCITY §7- Speed III + Haste II for " + var3 / 20 + " seconds!");
      }
   }

   public void d(UUID var1) {
      if (this.c.containsKey(var1)) {
         ((BukkitTask)this.c.get(var1)).cancel();
         this.c.remove(var1);
      }

      this.b.remove(var1);
      c(var1);
   }

   public static void a() {
      d.clear();
   }
}
