package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Random;
import java.util.Set;
import java.util.UUID;
import net.md_5.bungee.api.ChatMessageType;
import net.md_5.bungee.api.chat.TextComponent;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.block.Block;
import org.bukkit.entity.Display;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.ItemDisplay;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.RayTraceResult;
import org.bukkit.util.Transformation;
import org.bukkit.util.Vector;
import org.joml.Vector3f;

public class b implements GemAbilityHandler {
   private final BlissGems a;
   private final Map<UUID, Integer> b = new HashMap();
   private final Map<UUID, BukkitTask> c = new HashMap();
   private final Map<UUID, ItemDisplay> d = new HashMap();
   private final Map<UUID, Location> e = new HashMap();
   private final Map<UUID, BukkitTask> f = new HashMap();
   private final Set<UUID> g = new HashSet();
   private final Map<UUID, BukkitTask> h = new HashMap();
   private final Map<UUID, Map<Location, Material>> i = new HashMap();
   private final Map<UUID, Map<Location, Material>> j = new HashMap();
   private final Set<UUID> k = new HashSet();
   private final Map<UUID, BukkitTask> l = new HashMap();
   private static final int m = 100;
   private static final int n = 300;
   private static final Material[] o;
   private final Random p = new Random();

   private static boolean a(Material var0) {
      String var1 = var0.name();
      return var1.contains("CHEST") || var1.contains("SHULKER_BOX") || var1.contains("BARREL") || var1.contains("HOPPER") || var1.contains("FURNACE") || var1.contains("BLAST_FURNACE") || var1.contains("SMOKER") || var1.contains("DROPPER") || var1.contains("DISPENSER") || var1.contains("BREWING_STAND") || var0 == Material.JUKEBOX || var0 == Material.LECTERN || var0 == Material.CHISELED_BOOKSHELF;
   }

   public b(BlissGems var1) {
      this.a = var1;
   }

   public boolean a(Player var1) {
      return this.b.containsKey(var1.getUniqueId());
   }

   public int b(Player var1) {
      return (Integer)this.b.getOrDefault(var1.getUniqueId(), 0);
   }

   public boolean c(Player var1) {
      return this.g.contains(var1.getUniqueId());
   }

   public boolean a(Location var1) {
      for(Map var3 : this.i.values()) {
         if (var3.containsKey(var1)) {
            return true;
         }
      }

      for(Location var5 : this.e.values()) {
         if (var5 != null && var5.getWorld().equals(var1.getWorld()) && var5.getBlockX() == var1.getBlockX() && var5.getBlockY() == var1.getBlockY() && var5.getBlockZ() == var1.getBlockZ()) {
            return true;
         }
      }

      return false;
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.f(var1);
      } else {
         this.d(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.d(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.f(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.h(var1);
   }

   public void onQuaternary(Player var1, int var2) {
      this.i(var1);
   }

   public void d(final Player var1) {
      String var2 = "fire-fireball";
      if (this.a(var1)) {
         this.j(var1);
      } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         final UUID var3 = var1.getUniqueId();
         this.b.put(var3, 0);
         var1.playSound(var1.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 1.0F, 0.5F);
         var1.sendMessage("§6§oCharging fireball... Right-click again to fire!");
         this.l(var1);
         this.k(var1);
         BukkitTask var4 = (new BukkitRunnable() {
            int a = 0;
            boolean b = false;
            boolean c = false;

            public void run() {
               if (var1.isOnline() && !var1.isDead() && b.this.b.containsKey(var3)) {
                  ++this.a;
                  int var1x = (Integer)b.this.b.getOrDefault(var3, 0);
                  int var3x = Math.max(1, b.this.a.getConfig().getInt("abilities.fire-fireball.charge-duration-ticks", 300));
                  int var2;
                  if (!this.c) {
                     var2 = Math.min(this.a * 100 / var3x, 100);
                     if (var2 >= 100) {
                        this.c = true;
                        var2 = 100;
                     }
                  } else {
                     Block var4 = var1.getLocation().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
                     if (var4.getType() != Material.OBSIDIAN && var4.getType() != Material.CRYING_OBSIDIAN) {
                        var2 = var1x - 1;
                     } else {
                        var2 = var1x;
                     }

                     if (var2 <= 0) {
                        var1.sendMessage("§c§oFireball charge fizzled!");
                        var1.playSound(var1.getLocation(), Sound.BLOCK_FIRE_EXTINGUISH, 1.0F, 1.0F);
                        b.this.e(var1);
                        this.cancel();
                        return;
                     }
                  }

                  b.this.b.put(var3, var2);
                  b.this.c(var1, var2);
                  b.this.b(var1, var2);
                  if (var2 == 25 || var2 == 50 || var2 == 75) {
                     var1.playSound(var1.getLocation(), Sound.BLOCK_FIRE_AMBIENT, 0.5F, 1.0F + (float)var2 / 100.0F);
                  }

                  if (var2 >= 100 && !this.b) {
                     var1.playSound(var1.getLocation(), Sound.ENTITY_BLAZE_AMBIENT, 1.0F, 1.5F);
                     var1.sendMessage("§6§lFully charged! §eRight-click to fire!");
                     this.b = true;
                  }

               } else {
                  b.this.e(var1);
                  this.cancel();
               }
            }
         }).runTaskTimer(this.a, 0L, 1L);
         this.c.put(var3, var4);
      }
   }

   private void b(Player var1, int var2) {
      int var3 = var2 / 5;
      StringBuilder var4 = new StringBuilder("§6Fireball: §c");

      for(int var5 = 0; var5 < 20; ++var5) {
         if (var5 < var3) {
            var4.append("█");
         } else {
            var4.append("§8█");
         }
      }

      var4.append(" §e").append(var2).append("%");
      var1.spigot().sendMessage(ChatMessageType.ACTION_BAR, new TextComponent(var4.toString()));
   }

   private void j(Player var1) {
      UUID var2 = var1.getUniqueId();
      int var3 = (Integer)this.b.getOrDefault(var2, 0);
      BukkitTask var4 = (BukkitTask)this.c.remove(var2);
      if (var4 != null) {
         var4.cancel();
      }

      this.b.remove(var2);
      this.a(var2);
      if (var3 < 10) {
         var1.sendMessage("§c§oNot enough charge!");
      } else {
         double var5 = this.a.getConfig().getDouble("abilities.damage.fire-fireball", (double)9.0F);
         double var7 = (double)var3 / (double)100.0F;
         double var9 = this.a.getConfig().getDouble("abilities.fire-fireball.yield-base", (double)1.5F);
         double var11 = this.a.getConfig().getDouble("abilities.fire-fireball.yield-per-percent", 0.025);
         float var13 = (float)(var9 + var11 * (double)var3);
         Location var14 = var1.getEyeLocation();
         Vector var15 = var14.getDirection();
         Fireball var16 = (Fireball)var1.getWorld().spawn(var14.clone().add(var15.clone().multiply((double)1.5F)), Fireball.class);
         var16.setShooter(var1);
         var16.setVelocity(var15.multiply((double)1.5F + (double)var3 / (double)100.0F));
         var16.setYield(var13);
         var16.setIsIncendiary(true);
         int var17 = 20 + var3 / 2;
         var1.playSound(var1.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0F, 0.5F + (float)var3 / 200.0F);
         var1.spawnParticle(Particle.FLAME, var14, var17, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
         this.a.getAbilityManager().useAbility(var1, "fire-fireball");
         var1.sendMessage("§6§oFired at " + var3 + "% power!");
      }
   }

   public void e(Player var1) {
      UUID var2 = var1.getUniqueId();
      BukkitTask var3 = (BukkitTask)this.c.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

      this.b.remove(var2);
      this.a(var2);
   }

   private void k(Player var1) {
      Location var2 = var1.getLocation();
      Particle.DustOptions var3 = new Particle.DustOptions(ParticleUtils.FIRE_ORANGE, 1.5F);

      for(int var4 = 0; var4 < 24; ++var4) {
         double var5 = (double)var4 / (double)24.0F * (double)2.0F * Math.PI;
         double var7 = Math.cos(var5) * 1.4;
         double var9 = Math.sin(var5) * 1.4;
         var1.getWorld().spawnParticle(Particle.FLAME, var2.clone().add(var7, 0.2, var9), 2, 0.05, 0.05, 0.05, 0.02);
         var1.getWorld().spawnParticle(Particle.DUST, var2.clone().add(var7, 0.4, var9), 1, 0.05, 0.05, 0.05, (double)0.0F, var3, true);
      }

      var1.getWorld().spawnParticle(Particle.FLAME, var2.clone().add((double)0.0F, 0.6, (double)0.0F), 25, 0.4, 0.4, 0.4, 0.06);
      var1.getWorld().spawnParticle(Particle.LAVA, var2.clone().add((double)0.0F, 0.3, (double)0.0F), 6, (double)0.5F, 0.1, (double)0.5F, (double)0.0F);
   }

   private void l(Player var1) {
      try {
         UUID var2 = var1.getUniqueId();
         this.a(var2);
         Location var3 = this.m(var1);
         ItemDisplay var4 = (ItemDisplay)var1.getWorld().spawnEntity(var3, EntityType.ITEM_DISPLAY);
         var4.setItemStack(new ItemStack(Material.FIRE_CHARGE));
         var4.setBrightness(new Display.Brightness(15, 15));
         var4.setTeleportDuration(2);
         this.a(var4, 0.3F);
         this.d.put(var2, var4);
      } catch (Throwable var5) {
         this.a.getLogger().warning("Failed to spawn fireball charge display: " + var5.getMessage());
      }

   }

   private void c(Player var1, int var2) {
      ItemDisplay var3 = (ItemDisplay)this.d.get(var1.getUniqueId());
      if (var3 != null && var3.isValid()) {
         float var4 = 0.3F + (float)Math.max(0, Math.min(var2, 100)) / 100.0F * 0.7F;
         this.a(var3, var4);
         var3.teleport(this.m(var1));
      }
   }

   private void a(UUID var1) {
      ItemDisplay var2 = (ItemDisplay)this.d.remove(var1);
      if (var2 != null && var2.isValid()) {
         var2.remove();
      }

   }

   private Location m(Player var1) {
      return var1.getLocation().add((double)0.0F, (double)2.5F, (double)0.0F);
   }

   private void a(ItemDisplay var1, float var2) {
      Transformation var3 = var1.getTransformation();
      var1.setTransformation(new Transformation(var3.getTranslation(), var3.getLeftRotation(), new Vector3f(var2, var2, var2), var3.getRightRotation()));
   }

   public void f(final Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "fire-campfire";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            final UUID var3 = var1.getUniqueId();
            if (this.e.containsKey(var3)) {
               this.g(var1);
            }

            Block var4 = var1.getLocation().getBlock();
            if (var4.getType() != Material.AIR) {
               var4 = var4.getRelative(0, 1, 0);
            }

            if (var4.getType() != Material.AIR && var4.getType() != Material.CAVE_AIR) {
               var1.sendMessage("§c§oCannot place campfire here!");
            } else {
               Material var5 = var4.getType();
               var4.setType(Material.CAMPFIRE);
               final Location var6 = var4.getLocation().clone();
               this.e.put(var3, var6);
               final double var7 = this.a.getConfig().getDouble("abilities.fire-campfire.radius", (double)5.0F);
               final double var9 = this.a.getConfig().getDouble("abilities.damage.fire-campfire", (double)2.0F);
               final int var11 = this.a.getConfig().getInt("abilities.fire-campfire.burn-duration", 3);
               final int var12 = this.a.getConfig().getInt("abilities.durations.fire-campfire", 60) * 20;
               var1.playSound(var6, Sound.BLOCK_CAMPFIRE_CRACKLE, 1.0F, 1.0F);
               var1.sendMessage("§6§oPlaced Campfire! Heals you and burns enemies for 1 minute.");
               BukkitTask var13 = (new BukkitRunnable() {
                  int a = 0;

                  public void run() {
                     Block var1x = var6.getBlock();
                     if (var1x.getType() != Material.CAMPFIRE) {
                        b.this.e.remove(var3);
                        b.this.f.remove(var3);
                        var1.sendMessage("§6§oCampfire was destroyed!");
                        this.cancel();
                     } else if (this.a >= var12) {
                        b.this.b(var6);
                        b.this.e.remove(var3);
                        b.this.f.remove(var3);
                        var1.sendMessage("§6§oCampfire expired!");
                        this.cancel();
                     } else {
                        if (this.a % 20 == 0) {
                           for(Entity var3x : var6.getWorld().getNearbyEntities(var6, var7, var7, var7)) {
                              if (var3x instanceof Player) {
                                 Player var4 = (Player)var3x;
                                 if (var4.equals(var1) || b.this.a.getTrustedPlayersManager().isTrusted(var1, var4)) {
                                    var4.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, 40, 3));
                                 }
                              }
                           }

                           for(Entity var13 : var6.getWorld().getNearbyEntities(var6, var7, var7, var7)) {
                              if (var13 instanceof LivingEntity && var13 != var1) {
                                 LivingEntity var15 = (LivingEntity)var13;
                                 if (var13 instanceof Player) {
                                    Player var5 = (Player)var13;
                                    if (b.this.a.getTrustedPlayersManager().isTrusted(var1, var5)) {
                                       continue;
                                    }
                                 }

                                 var15.damage(var9, var1);
                                 var15.setFireTicks(var11 * 20);
                                 var15.getWorld().spawnParticle(Particle.FLAME, var15.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, (double)0.5F, 0.3, 0.02);
                              }
                           }

                           var6.getWorld().playSound(var6, Sound.BLOCK_CAMPFIRE_CRACKLE, 0.5F, 1.0F);
                        }

                        if (this.a % 5 == 0) {
                           byte var12x = 48;
                           Particle.DustOptions var14 = new Particle.DustOptions(ParticleUtils.FIRE_ORANGE, 1.0F);

                           for(int var16 = 0; var16 < var12x; ++var16) {
                              double var17 = (double)var16 / (double)var12x * (double)2.0F * Math.PI;
                              double var7x = Math.cos(var17) * var7;
                              double var9x = Math.sin(var17) * var7;
                              var6.getWorld().spawnParticle(Particle.DUST, var6.clone().add(var7x, 0.3, var9x), 3, 0.1, 0.1, 0.1, (double)0.0F, var14, true);
                              var6.getWorld().spawnParticle(Particle.FLAME, var6.clone().add(var7x, 0.8, var9x), 2, 0.1, 0.1, 0.1, 0.01);
                              if (var16 % 4 == 0) {
                                 var6.getWorld().spawnParticle(Particle.LAVA, var6.clone().add(var7x, 1.2, var9x), 1, (double)0.0F, (double)0.0F, (double)0.0F, (double)0.0F);
                              }
                           }

                           var6.getWorld().spawnParticle(Particle.FLAME, var6.clone().add((double)0.5F, (double)1.0F, (double)0.5F), 15, 0.3, (double)0.5F, 0.3, 0.02);
                           var6.getWorld().spawnParticle(Particle.LAVA, var6.clone().add((double)0.5F, (double)0.5F, (double)0.5F), 8, (double)0.5F, 0.2, (double)0.5F, (double)0.0F);
                        }

                        ++this.a;
                     }
                  }
               }).runTaskTimer(this.a, 0L, 1L);
               this.f.put(var3, var13);
               this.a.getAbilityManager().useAbility(var1, var2);
            }
         }
      }
   }

   private void b(Location var1) {
      Block var2 = var1.getBlock();
      if (var2.getType() == Material.CAMPFIRE) {
         var2.setType(Material.AIR);
         var1.getWorld().playSound(var1, Sound.BLOCK_FIRE_EXTINGUISH, 1.0F, 1.0F);
      }

   }

   public void g(Player var1) {
      UUID var2 = var1.getUniqueId();
      BukkitTask var3 = (BukkitTask)this.f.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

      Location var4 = (Location)this.e.remove(var2);
      if (var4 != null) {
         this.b(var4);
      }

   }

   public void h(final Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "fire-crisp";
         if (this.c(var1)) {
            var1.sendMessage("§c§oCrisp is already active!");
         } else if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            final UUID var3 = var1.getUniqueId();
            Location var4 = var1.getLocation().clone();
            final int var5 = this.a.getConfig().getInt("abilities.fire-crisp.radius", 10);
            int var6 = this.a.getConfig().getInt("abilities.durations.fire-crisp", 15);
            final int var7 = var6 * 20;
            this.g.add(var3);
            var1.playSound(var4, Sound.BLOCK_LAVA_AMBIENT, 1.5F, 0.5F);
            var1.playSound(var4, Sound.ENTITY_BLAZE_AMBIENT, 1.0F, 0.7F);
            var1.sendMessage("§6§lCrisp! §eEvaporating water and scorching the earth for " + var6 + "s!");
            this.i.put(var3, new HashMap());
            this.j.put(var3, new HashMap());
            this.a(var4, var5, var3);

            for(int var8 = 0; var8 < 36; ++var8) {
               double var9 = (double)var8 / (double)36.0F * (double)2.0F * Math.PI;

               for(double var11 = (double)0.0F; var11 <= (double)var5; var11 += (double)0.5F) {
                  double var13 = Math.cos(var9) * var11;
                  double var15 = Math.sin(var9) * var11;
                  var4.getWorld().spawnParticle(Particle.FLAME, var4.clone().add(var13, 0.3, var15), 1, 0.05, 0.1, 0.05, 0.02);
               }
            }

            Particle.DustOptions var17 = new Particle.DustOptions(ParticleUtils.FIRE_ORANGE, 1.5F);

            for(int var18 = 0; var18 < 48; ++var18) {
               double var10 = (double)var18 / (double)48.0F * (double)2.0F * Math.PI;
               double var12 = Math.cos(var10) * (double)var5;
               double var14 = Math.sin(var10) * (double)var5;
               var4.getWorld().spawnParticle(Particle.DUST, var4.clone().add(var12, (double)0.5F, var14), 5, 0.1, 0.3, 0.1, (double)0.0F, var17, true);
            }

            BukkitTask var19 = (new BukkitRunnable() {
               int a = 0;

               public void run() {
                  if (var1.isOnline() && !var1.isDead() && this.a < var7) {
                     ++this.a;
                     if (this.a % 10 == 0) {
                        Location var1x = var1.getLocation();
                        b.this.b(var1x, var5, var3);
                        if (this.a % 20 == 0) {
                           for(int var2 = 0; var2 < 8; ++var2) {
                              double var3x = b.this.p.nextDouble() * (double)2.0F * Math.PI;
                              double var5x = b.this.p.nextDouble() * (double)var5;
                              double var7x = Math.cos(var3x) * var5x;
                              double var9 = Math.sin(var3x) * var5x;
                              var1x.getWorld().spawnParticle(Particle.LAVA, var1x.clone().add(var7x, 0.2, var9), 1, 0.1, 0.1, 0.1, (double)0.0F);
                              var1x.getWorld().spawnParticle(Particle.FLAME, var1x.clone().add(var7x, 0.3, var9), 1, 0.1, 0.1, 0.1, 0.01);
                           }

                           var1x.getWorld().playSound(var1x, Sound.BLOCK_FIRE_AMBIENT, 0.4F, 0.8F);
                        }
                     }

                  } else {
                     b.this.n(var1);
                     this.cancel();
                  }
               }
            }).runTaskTimer(this.a, 0L, 1L);
            this.h.put(var3, var19);
            this.a.getAbilityManager().useAbility(var1, var2);
         }
      }
   }

   private void a(Location var1, int var2, UUID var3) {
      this.b(var1, var2, var3);
      Map var4 = (Map)this.i.get(var3);

      for(int var5 = -var2; var5 <= var2; ++var5) {
         for(int var6 = -var2; var6 <= var2; ++var6) {
            if (var5 * var5 + var6 * var6 <= var2 * var2) {
               Location var7 = var1.clone().add((double)var5, (double)0.0F, (double)var6);
               Block var8 = var7.getWorld().getHighestBlockAt(var7);
               if (!a(var8.getType()) && var8.getType().isSolid() && !var8.getType().name().startsWith("NETHER") && var8.getType() != Material.MAGMA_BLOCK && var8.getType() != Material.SOUL_SAND) {
                  Location var9 = var8.getLocation();
                  if (var4 != null) {
                     var4.put(var9, var8.getType());
                  }

                  Material var10 = o[this.p.nextInt(o.length)];
                  var8.setType(var10);
               }
            }
         }
      }

   }

   private void b(Location var1, int var2, UUID var3) {
      Map var4 = (Map)this.j.get(var3);

      for(int var5 = -var2; var5 <= var2; ++var5) {
         for(int var6 = -var2; var6 <= var2; ++var6) {
            for(int var7 = -var2; var7 <= var2; ++var7) {
               if (var5 * var5 + var6 * var6 + var7 * var7 <= var2 * var2) {
                  Block var8 = var1.clone().add((double)var5, (double)var6, (double)var7).getBlock();
                  Material var9 = var8.getType();
                  if (var9 == Material.WATER || var9 == Material.BUBBLE_COLUMN || var9 == Material.KELP || var9 == Material.KELP_PLANT || var9 == Material.SEAGRASS || var9 == Material.TALL_SEAGRASS) {
                     if (var4 != null) {
                        var4.putIfAbsent(var8.getLocation(), var9);
                     }

                     var1.getWorld().spawnParticle(Particle.CLOUD, var8.getLocation().add((double)0.5F, (double)0.5F, (double)0.5F), 3, 0.2, 0.2, 0.2, 0.02);
                     var8.setType(Material.AIR);
                  }
               }
            }
         }
      }

   }

   private void n(Player var1) {
      UUID var2 = var1.getUniqueId();
      boolean var3 = this.g.remove(var2);
      BukkitTask var4 = (BukkitTask)this.h.remove(var2);
      if (var4 != null) {
         var4.cancel();
      }

      Map var5 = (Map)this.i.remove(var2);
      if (var5 != null) {
         for(Map.Entry var7 : var5.entrySet()) {
            Block var8 = ((Location)var7.getKey()).getBlock();
            String var9 = var8.getType().name();
            if (var9.startsWith("NETHER") || var8.getType() == Material.MAGMA_BLOCK || var8.getType() == Material.SOUL_SAND) {
               var8.setType((Material)var7.getValue());
            }
         }
      }

      Map var10 = (Map)this.j.remove(var2);
      if (var10 != null) {
         for(Map.Entry var12 : var10.entrySet()) {
            Block var13 = ((Location)var12.getKey()).getBlock();
            if (var13.getType() == Material.AIR) {
               var13.setType((Material)var12.getValue());
            }
         }
      }

      if (var3 && var1.isOnline()) {
         var1.sendMessage("§6§oCrisp faded. Terrain restored.");
      }

   }

   public void i(final Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "fire-meteor-shower";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            final UUID var3 = var1.getUniqueId();
            Location var4 = this.d(var1, 50);
            if (var4 == null) {
               var1.sendMessage("§c§oNo valid target area found!");
            } else {
               int var5 = this.a.getConfig().getInt("abilities.durations.fire-meteor-shower", 8);
               final int var6 = var5 * 20;
               final double var7 = this.a.getConfig().getDouble("abilities.fire-meteor-shower.radius", (double)8.0F);
               final double var9 = this.a.getConfig().getDouble("abilities.damage.fire-meteor-shower", (double)5.0F);
               final int var11 = this.a.getConfig().getInt("abilities.fire-meteor-shower.interval-ticks", 10);
               this.k.add(var3);
               var1.playSound(var1.getLocation(), Sound.ENTITY_BLAZE_SHOOT, 1.0F, 0.3F);
               var1.sendMessage("§6§lMeteor Shower! §eFire rains down for " + var5 + "s!");
               Particle.DustOptions var12 = new Particle.DustOptions(ParticleUtils.FIRE_ORANGE, 1.2F);

               for(int var13 = 0; var13 < 48; ++var13) {
                  double var14 = (double)var13 / (double)48.0F * (double)2.0F * Math.PI;
                  double var16 = Math.cos(var14) * var7;
                  double var18 = Math.sin(var14) * var7;
                  var4.getWorld().spawnParticle(Particle.DUST, var4.clone().add(var16, (double)0.5F, var18), 3, 0.1, 0.2, 0.1, (double)0.0F, var12, true);
               }

               final Location var20 = var4.clone();
               BukkitTask var21 = (new BukkitRunnable() {
                  int a = 0;

                  public void run() {
                     if (var1.isOnline() && !var1.isDead() && this.a < var6) {
                        ++this.a;
                        if (this.a % var11 == 0) {
                           double var1x = b.this.p.nextDouble() * (double)2.0F * Math.PI;
                           double var3x = Math.sqrt(b.this.p.nextDouble()) * var7;
                           double var5 = Math.cos(var1x) * var3x;
                           double var7x = Math.sin(var1x) * var3x;
                           int var9x = 20 + b.this.p.nextInt(10);
                           Location var10 = var20.clone().add(var5, (double)var9x, var7x);
                           Location var11x = var20.clone().add(var5, (double)0.0F, var7x);
                           Block var12 = var20.getWorld().getHighestBlockAt(var11x);
                           var11x.setY((double)var12.getY() + (double)0.5F);
                           Vector var13 = var11x.toVector().subtract(var10.toVector()).normalize();
                           b.this.a.getServer().getScheduler().runTaskLater(b.this.a, () -> {
                              if (var1.isOnline()) {
                                 double var8 = var10.distance(var11x);

                                 for(double var10x = (double)0.0F; var10x < var8; var10x += 0.8) {
                                    Location var12 = var10.clone().add(var13.clone().multiply(var10x));
                                    var20.getWorld().spawnParticle(Particle.FLAME, var12, 30, 0.3, 0.3, 0.3, 0.03);
                                    var20.getWorld().spawnParticle(Particle.LAVA, var12, 10, 0.15, 0.15, 0.15, (double)0.0F);
                                 }

                                 var20.getWorld().spawnParticle(Particle.FLAME, var11x, 400, (double)3.0F, (double)1.5F, (double)3.0F, 0.1);
                                 var20.getWorld().spawnParticle(Particle.LAVA, var11x, 150, (double)1.5F, 0.6, (double)1.5F, (double)0.0F);
                                 var20.getWorld().spawnParticle(Particle.EXPLOSION, var11x, 30, 0.9, 0.3, 0.9, (double)0.0F);
                                 var20.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var11x, 100, (double)1.5F, 0.9, (double)1.5F, 0.05);
                                 var20.getWorld().playSound(var11x, Sound.ENTITY_GENERIC_EXPLODE, 0.6F, 1.5F);
                                 var20.getWorld().playSound(var11x, Sound.BLOCK_LAVA_POP, 1.0F, 0.8F);
                                 double var16 = (double)2.5F;

                                 for(Entity var13x : var20.getWorld().getNearbyEntities(var11x, var16, var16, var16)) {
                                    if (var13x instanceof LivingEntity && var13x != var1) {
                                       LivingEntity var14 = (LivingEntity)var13x;
                                       if (var13x instanceof Player) {
                                          Player var15 = (Player)var13x;
                                          if (b.this.a.getTrustedPlayersManager().isTrusted(var1, var15)) {
                                             continue;
                                          }
                                       }

                                       var14.damage(var9, var1);
                                       var14.setFireTicks(60);
                                       var14.getWorld().spawnParticle(Particle.FLAME, var14.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 150, 1.2, 1.8, 1.2, 0.05);
                                    }
                                 }

                                 float var18 = (float)b.this.a.getConfig().getDouble("abilities.fire-meteor-shower.yield", (double)2.0F);
                                 boolean var19 = b.this.a.getConfig().getBoolean("abilities.fire-meteor-shower.break-blocks", true);
                                 if (var18 > 0.0F) {
                                    var11x.getWorld().createExplosion(var11x, var18, true, var19, var1);
                                 }

                                 Block var20x = var11x.getBlock();
                                 if (var20x.getType() == Material.AIR || var20x.getType() == Material.CAVE_AIR) {
                                    Block var21 = var20x.getRelative(0, -1, 0);
                                    if (var21.getType().isSolid()) {
                                       var20x.setType(Material.FIRE);
                                    }
                                 }

                              }
                           }, 0L);
                        }

                        if (this.a % 20 == 0) {
                           Particle.DustOptions var14 = new Particle.DustOptions(ParticleUtils.FIRE_ORANGE, 0.8F);

                           for(int var2 = 0; var2 < 24; ++var2) {
                              double var15 = (double)var2 / (double)24.0F * (double)2.0F * Math.PI;
                              double var16 = Math.cos(var15) * var7;
                              double var17 = Math.sin(var15) * var7;
                              var20.getWorld().spawnParticle(Particle.DUST, var20.clone().add(var16, 0.3, var17), 20, 0.3, 0.3, 0.3, (double)0.0F, var14, true);
                           }
                        }

                     } else {
                        b.this.k.remove(var3);
                        b.this.l.remove(var3);
                        if (var1.isOnline()) {
                           var1.sendMessage("§6§oMeteor Shower ended.");
                        }

                        this.cancel();
                     }
                  }
               }).runTaskTimer(this.a, 0L, 1L);
               this.l.put(var3, var21);
               this.a.getAbilityManager().useAbility(var1, var2);
            }
         }
      }
   }

   private Location d(Player var1, int var2) {
      RayTraceResult var3 = var1.getWorld().rayTraceBlocks(var1.getEyeLocation(), var1.getEyeLocation().getDirection(), (double)var2);
      if (var3 != null && var3.getHitBlock() != null) {
         return var3.getHitBlock().getLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
      } else {
         Location var4 = var1.getEyeLocation().add(var1.getEyeLocation().getDirection().multiply(20));
         Block var5 = var1.getWorld().getHighestBlockAt(var4);
         return var5.getLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
      }
   }

   public void cleanup(Player var1) {
      this.e(var1);
      this.g(var1);
      this.n(var1);
      UUID var2 = var1.getUniqueId();
      this.i.remove(var2);
      this.j.remove(var2);
      this.k.remove(var2);
      BukkitTask var3 = (BukkitTask)this.l.remove(var2);
      if (var3 != null) {
         var3.cancel();
      }

   }

   static {
      o = new Material[]{Material.NETHERRACK, Material.NETHER_BRICKS, Material.NETHER_BRICK_FENCE, Material.MAGMA_BLOCK, Material.SOUL_SAND};
   }
}
