package dev.xoperr.blissgems.a;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.util.Vector;

public class e implements GemAbilityHandler {
   private final BlissGems a;
   private final Set<UUID> b = new HashSet();

   public e(BlissGems var1) {
      this.a = var1;
   }

   public boolean a(Player var1) {
      return this.b.contains(var1.getUniqueId());
   }

   public void b(Player var1) {
      this.b.remove(var1.getUniqueId());
   }

   public void a(Player var1, int var2) {
      if (var2 == 2 && var1.isSneaking()) {
         this.d(var1);
      } else {
         this.c(var1);
      }

   }

   public void onPrimary(Player var1, int var2) {
      this.c(var1);
   }

   public void onSecondary(Player var1, int var2) {
      this.d(var1);
   }

   public void onTertiary(Player var1, int var2) {
      this.e(var1);
   }

   public void c(Player var1) {
      String var2 = "puff-dash";
      if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
         Vector var3 = var1.getLocation().getDirection();
         var3.setY(0.3);
         var3.multiply((double)2.5F);
         var1.setVelocity(var3);
         int var4 = this.a.getGemManager().getGemTier(var1);
         if (var4 >= 2) {
            this.a.getServer().getScheduler().runTaskLater(this.a, () -> {
               for(Entity var3 : var1.getNearbyEntities((double)2.0F, (double)2.0F, (double)2.0F)) {
                  if (var3 instanceof LivingEntity var4) {
                     if (!(var3 instanceof Player)) {
                        double var5 = this.a.getConfigManager().getAbilityDamage("puff-dash");
                        var4.damage(var5, var1);
                     }
                  }
               }

            }, 5L);
         }

         var1.playSound(var1.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 1.0F, 1.5F);
         Particle.DustOptions var5 = new Particle.DustOptions(ParticleUtils.PUFF_WHITE, 1.5F);
         var1.spawnParticle(Particle.DUST, var1.getLocation(), 30, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var5, true);
         var1.spawnParticle(Particle.CLOUD, var1.getLocation(), 20, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
         this.a.getAbilityManager().useAbility(var1, var2);
         String var6 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Dash");
         if (var6 != null && !var6.isEmpty()) {
            var1.sendMessage(var6);
         }

      }
   }

   public void d(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "puff-breezy-bash";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            Vector var3 = var1.getVelocity();
            var3.setY((double)2.0F);
            var1.setVelocity(var3);
            var1.playSound(var1.getLocation(), Sound.ENTITY_BREEZE_JUMP, 1.0F, 1.0F);
            Particle.DustOptions var4 = new Particle.DustOptions(ParticleUtils.PUFF_WHITE, 1.5F);
            var1.spawnParticle(Particle.DUST, var1.getLocation(), 50, (double)1.0F, (double)1.0F, (double)1.0F, (double)0.0F, var4, true);
            var1.spawnParticle(Particle.CLOUD, var1.getLocation(), 40, (double)1.0F, (double)1.0F, (double)1.0F, 0.2);
            UUID var5 = var1.getUniqueId();
            this.b.add(var5);
            this.a.getServer().getScheduler().runTaskLater(this.a, () -> this.b.remove(var5), 200L);
            this.a.getAbilityManager().useAbility(var1, var2);
            String var6 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Breezy Bash");
            if (var6 != null && !var6.isEmpty()) {
               var1.sendMessage(var6);
            }

         }
      }
   }

   public void e(Player var1) {
      if (this.a.getGemManager().getGemTier(var1) < 2) {
         var1.sendMessage("§c§oThis ability requires Tier 2!");
      } else {
         String var2 = "puff-group-bash";
         if (this.a.getAbilityManager().canUseAbility(var1, var2)) {
            double var3 = this.a.getConfig().getDouble("abilities.puff-group-bash.radius", (double)10.0F);
            double var5 = this.a.getConfig().getDouble("abilities.puff-group-bash.knockback", (double)2.5F);
            int var7 = 0;

            for(Entity var9 : var1.getNearbyEntities(var3, var3, var3)) {
               if (var9 instanceof Player) {
                  Player var10 = (Player)var9;
                  if (!this.a.getTrustedPlayersManager().isTrusted(var1, var10)) {
                     Vector var11 = var10.getLocation().toVector().subtract(var1.getLocation().toVector());
                     if (var11.lengthSquared() < 0.01) {
                        var11 = new Vector(1, 0, 0);
                     }

                     var11.normalize().multiply(var5);
                     var11.setY((double)1.5F);
                     var10.setVelocity(var11);
                     var10.sendMessage("§f§oA gust of wind blows you away!");
                     ++var7;
                  }
               }
            }

            Particle.DustOptions var12 = new Particle.DustOptions(ParticleUtils.PUFF_WHITE, 1.5F);
            var1.getWorld().spawnParticle(Particle.DUST, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 60, (double)2.0F, (double)1.0F, (double)2.0F, (double)0.0F, var12, true);
            var1.getWorld().spawnParticle(Particle.CLOUD, var1.getLocation().add((double)0.0F, (double)0.5F, (double)0.0F), 50, (double)2.0F, (double)0.5F, (double)2.0F, 0.1);
            var1.playSound(var1.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1.0F, 0.8F);
            this.a.getAbilityManager().useAbility(var1, var2);
            String var13 = this.a.getConfigManager().getFormattedMessage("ability-activated", "ability", "Group Breezy Bash");
            if (var13 != null && !var13.isEmpty()) {
               var1.sendMessage(var13);
            }

            if (var7 > 0) {
               var1.sendMessage("§f§o" + var7 + " player(s) knocked away!");
            }

         }
      }
   }
}
