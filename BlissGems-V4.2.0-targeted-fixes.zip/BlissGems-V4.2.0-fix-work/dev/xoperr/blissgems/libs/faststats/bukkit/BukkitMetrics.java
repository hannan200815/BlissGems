package dev.xoperr.blissgems.libs.faststats.bukkit;

import dev.xoperr.blissgems.libs.faststats.core.Metrics;
import org.b.a.e;
import org.bukkit.plugin.IllegalPluginAccessException;
import org.bukkit.plugin.Plugin;

public sealed interface BukkitMetrics extends Metrics permits BukkitMetricsImpl {
   @e(
      b = true
   )
   static Factory factory() {
      return new BukkitMetricsImpl.Factory();
   }

   void ready() throws IllegalPluginAccessException;

   public interface Factory extends Metrics.Factory<Plugin, Factory> {
      BukkitMetrics create(Plugin var1) throws IllegalStateException;
   }
}
