package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadFactory;
import java.util.concurrent.atomic.AtomicInteger;

final class SimpleTrackingThreadFactory implements TrackingThreadFactory {
   private static final AtomicInteger poolNumber = new AtomicInteger(1);
   private final ThreadGroup group;
   private final AtomicInteger threadNumber = new AtomicInteger(1);
   private final String namePrefix;
   private final ErrorTracker tracker;

   public SimpleTrackingThreadFactory(ErrorTracker var1) {
      this.tracker = var1;
      this.group = Thread.currentThread().getThreadGroup();
      this.namePrefix = "tracking-pool-" + poolNumber.getAndIncrement() + "-thread-";
   }

   public Thread newThread(Runnable var1) {
      return this.newThread(this.namePrefix + this.threadNumber.getAndIncrement(), var1);
   }

   public Thread newThread(String var1, Runnable var2) {
      Thread var3 = new Thread(this.group, this.tracker.base().tracked(var2), var1, 0L);
      if (var3.isDaemon()) {
         var3.setDaemon(false);
      }

      if (var3.getPriority() != 5) {
         var3.setPriority(5);
      }

      return var3;
   }
}
