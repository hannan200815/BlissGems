package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingBase;
import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;

final class SimpleTrackingBase implements TrackingBase {
   private final ErrorTracker tracker;

   public SimpleTrackingBase(ErrorTracker var1) {
      this.tracker = var1;
   }

   public Runnable tracked(Runnable var1) {
      return () -> {
         try {
            var1.run();
         } catch (Throwable var3) {
            this.tracker.trackError(var3);
            throw var3;
         }
      };
   }

   public <T> PrivilegedAction<T> tracked(PrivilegedAction<T> var1) {
      return () -> {
         try {
            return var1.run();
         } catch (Throwable var3) {
            this.tracker.trackError(var3);
            throw var3;
         }
      };
   }

   public <T> PrivilegedExceptionAction<T> tracked(PrivilegedExceptionAction<T> var1) {
      return () -> {
         try {
            return var1.run();
         } catch (Throwable var3) {
            this.tracker.trackError(var3);
            throw var3;
         }
      };
   }
}
