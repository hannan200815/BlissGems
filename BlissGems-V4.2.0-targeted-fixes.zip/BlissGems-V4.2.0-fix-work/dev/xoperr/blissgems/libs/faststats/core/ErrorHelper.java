package dev.xoperr.blissgems.libs.faststats.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.List;
import java.util.Set;
import java.util.regex.Pattern;
import org.c.a.d;

final class ErrorHelper {
   private static final int MESSAGE_LENGTH = Math.min(1000, Integer.getInteger("faststats.message-length", 500));
   private static final int STACK_TRACE_LENGTH = Math.min(500, Integer.getInteger("faststats.stack-trace-length", 300));
   private static final int STACK_TRACE_LIMIT = Math.min(50, Integer.getInteger("faststats.stack-trace-limit", 15));
   private static final Pattern IPV4_PATTERN = Pattern.compile("\\b(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\b");
   private static final Pattern IPV6_PATTERN = Pattern.compile("(?i)\\b([0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\\b|(?i)\\b([0-9a-f]{1,4}:){1,7}:\\b|(?i)\\b([0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}\\b|(?i)\\b([0-9a-f]{1,4}:){1,5}(:[0-9a-f]{1,4}){1,2}\\b|(?i)\\b([0-9a-f]{1,4}:){1,4}(:[0-9a-f]{1,4}){1,3}\\b|(?i)\\b([0-9a-f]{1,4}:){1,3}(:[0-9a-f]{1,4}){1,4}\\b|(?i)\\b([0-9a-f]{1,4}:){1,2}(:[0-9a-f]{1,4}){1,5}\\b|(?i)\\b[0-9a-f]{1,4}:(:[0-9a-f]{1,4}){1,6}\\b|(?i)\\b:(:[0-9a-f]{1,4}){1,7}\\b|(?i)\\b::([0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4}\\b|(?i)\\b::\\b");
   private static final Pattern USER_HOME_PATH_PATTERN = Pattern.compile("(/home/)[^/\\s]+|(/Users/)[^/\\s]+|((?i)[A-Z]:\\\\Users\\\\)[^\\\\\\s]+");

   public static JsonObject compile(Throwable var0, @d List<String> var1) {
      JsonObject var2 = new JsonObject();
      String var3 = getAnonymizedMessage(var0);
      JsonArray var4 = new JsonArray();
      String var5 = var3 != null ? var0.getClass().getName() + ": " + var3 : var0.getClass().getName();
      var4.add(var5);
      StackTraceElement[] var6 = var0.getStackTrace();
      List var7 = collapseStackTrace(var6);
      ArrayList var8 = new ArrayList(var7);
      if (var1 != null) {
         var8.removeAll(var1);
      }

      int var9 = Math.min(var8.size(), STACK_TRACE_LIMIT);
      populateTraces(var9, var8, var6, var4);
      appendCauseChain(var0.getCause(), var7, var1, var4);
      var2.addProperty("error", var0.getClass().getName());
      if (var3 != null) {
         var2.addProperty("message", var3);
      }

      var2.add("stack", var4);
      return var2;
   }

   private static void appendCauseChain(@d Throwable var0, List<String> var1, @d List<String> var2, JsonArray var3) {
      ArrayList var4 = new ArrayList(var1);
      if (var2 != null) {
         var4.addAll(var2);
      }

      for(Set var5 = Collections.newSetFromMap(new IdentityHashMap()); var0 != null && var5.add(var0); var0 = var0.getCause()) {
         String var6 = getAnonymizedMessage(var0);
         String var7 = var6 != null ? "Caused by: " + var0.getClass().getName() + ": " + var6 : "Caused by: " + var0.getClass().getName();
         var3.add(var7);
         StackTraceElement[] var8 = var0.getStackTrace();
         List var9 = collapseStackTrace(var8);
         ArrayList var10 = new ArrayList(var9);
         var10.removeAll(var4);
         int var11 = Math.min(var10.size(), STACK_TRACE_LIMIT);
         populateTraces(var11, var10, var8, var3);
      }

   }

   private static void populateTraces(int var0, List<String> var1, StackTraceElement[] var2, JsonArray var3) {
      for(int var4 = 0; var4 < var0; ++var4) {
         String var5 = (String)var1.get(var4);
         if (var5.length() <= STACK_TRACE_LENGTH) {
            var3.add("  at " + var5);
         } else {
            var3.add("  at " + var5.substring(0, STACK_TRACE_LENGTH) + "...");
         }
      }

      if (var0 > 0 && var0 < var1.size()) {
         var3.add("  ... " + (var1.size() - var0) + " more");
      } else {
         int var6 = var2.length - var1.size();
         if (var6 > 0) {
            var3.add("  ... " + var6 + " more");
         }
      }

   }

   private static List<String> collapseStackTrace(StackTraceElement[] var0) {
      List var1 = Arrays.stream(var0).map(StackTraceElement::toString).toList();
      return collapseRepeatingPattern(var1);
   }

   private static List<String> collapseRepeatingPattern(List<String> var0) {
      List var1 = collapseConsecutiveDuplicates(var0);
      int var2 = var1.size();

      for(int var3 = 1; var3 <= var2 / 2; ++var3) {
         boolean var4 = true;
         int var5 = 0;

         for(int var6 = 0; var6 < var2; ++var6) {
            if (!((String)var1.get(var6)).equals(var1.get(var6 % var3))) {
               var4 = false;
               break;
            }

            if (var6 > 0 && var6 % var3 == 0) {
               ++var5;
            }
         }

         if (var4 && var5 >= 2) {
            return var1.subList(0, var3);
         }
      }

      return var1;
   }

   private static List<String> collapseConsecutiveDuplicates(List<String> var0) {
      if (var0.isEmpty()) {
         return var0;
      } else {
         ArrayList var1 = new ArrayList();
         String var2 = null;

         for(String var4 : var0) {
            if (!var4.equals(var2)) {
               var1.add(var4);
               var2 = var4;
            }
         }

         return var1;
      }
   }

   public static boolean isSameLoader(ClassLoader var0, Throwable var1) {
      return isSameLoader(var0, var1, Collections.newSetFromMap(new IdentityHashMap()));
   }

   private static boolean isSameLoader(ClassLoader var0, @d Throwable var1, Set<Throwable> var2) {
      if (var1 != null && var2.add(var1)) {
         StackTraceElement[] var3 = var1.getStackTrace();
         if (var3 != null && var3.length != 0) {
            int var4 = findFirstNonLibraryFrameIndex(var3);
            if (var4 == -1) {
               return isSameLoader(var0, var1.getCause(), var2);
            } else {
               int var5 = Math.min(5, var3.length - var4);

               for(int var6 = 0; var6 < var5; ++var6) {
                  StackTraceElement var7 = var3[var4 + var6];
                  if (!isLibraryClass(var7.getClassName()) && !isFromLoader(var7, var0)) {
                     return isSameLoader(var0, var1.getCause(), var2);
                  }
               }

               return true;
            }
         } else {
            return isSameLoader(var0, var1.getCause(), var2);
         }
      } else {
         return false;
      }
   }

   private static int findFirstNonLibraryFrameIndex(StackTraceElement[] var0) {
      for(int var1 = 0; var1 < var0.length; ++var1) {
         if (!isLibraryClass(var0[var1].getClassName())) {
            return var1;
         }
      }

      return -1;
   }

   private static boolean isLibraryClass(String var0) {
      return var0.startsWith("java.") || var0.startsWith("javax.") || var0.startsWith("sun.") || var0.startsWith("com.sun.") || var0.startsWith("jdk.");
   }

   private static boolean isFromLoader(StackTraceElement var0, ClassLoader var1) {
      try {
         Class var2 = Class.forName(var0.getClassName(), false, var1);
         return isSameClassLoader(var2.getClassLoader(), var1);
      } catch (Throwable var3) {
         return false;
      }
   }

   private static boolean isSameClassLoader(ClassLoader var0, ClassLoader var1) {
      if (var0 == var1) {
         return true;
      } else {
         ClassLoader var2;
         for(var2 = var0; var2 != null && var2 != var1; var2 = var2.getParent()) {
         }

         return var1 == var2;
      }
   }

   private static String anonymize(String var0) {
      var0 = IPV4_PATTERN.matcher(var0).replaceAll("[IP hidden]");
      var0 = IPV6_PATTERN.matcher(var0).replaceAll("[IP hidden]");
      var0 = USER_HOME_PATH_PATTERN.matcher(var0).replaceAll("$1$2$3[username hidden]");
      String var1 = System.getProperty("user.name");
      if (var1 != null) {
         var0 = var0.replace(var1, "[username hidden]");
      }

      return var0;
   }

   private static @d String getAnonymizedMessage(Throwable var0) {
      String var1 = var0.getMessage();
      if (var1 == null) {
         return null;
      } else {
         String var2 = var1.length() > MESSAGE_LENGTH ? var1.substring(0, MESSAGE_LENGTH) + "..." : var1;
         return anonymize(var2);
      }
   }
}
