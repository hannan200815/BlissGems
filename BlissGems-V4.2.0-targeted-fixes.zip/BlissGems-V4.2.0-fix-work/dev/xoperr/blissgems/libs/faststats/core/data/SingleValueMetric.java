package dev.xoperr.blissgems.libs.faststats.core.data;

import com.google.gson.JsonElement;
import com.google.gson.JsonPrimitive;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import org.c.a.d;

final class SingleValueMetric<T> extends SimpleMetric<T> {
   public SingleValueMetric(@SourceId String var1, Callable<@d T> var2) throws IllegalArgumentException {
      super(var1, var2);
   }

   public Optional<JsonElement> getData() throws Exception {
      return this.compute().map((var0) -> {
         Objects.requireNonNull(var0);
         byte var2 = 0;
         JsonPrimitive var10000;
         //$FF: var2->value
         //0->java/lang/Boolean
         //1->java/lang/Number
         switch (((Class)var0).typeSwitch<invokedynamic>(var0, var2)) {
            case 0:
               Boolean var3 = (Boolean)var0;
               var10000 = new JsonPrimitive(var3);
               break;
            case 1:
               Number var4 = (Number)var0;
               var10000 = new JsonPrimitive(var4);
               break;
            default:
               var10000 = new JsonPrimitive(var0.toString());
         }

         return var10000;
      });
   }
}
