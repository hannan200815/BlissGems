package dev.xoperr.blissgems.libs.faststats.core.concurrent;

import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.b.a.a;
import org.b.a.o;

@a.d
public interface TrackingThreadPoolExecutor {
   ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6);

   ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, ThreadFactory var7);

   ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, RejectedExecutionHandler var7);

   ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, ThreadFactory var7, RejectedExecutionHandler var8);
}
