package dev.xoperr.blissgems.libs.faststats.core.data;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;
import org.a.a.a.f;
import org.b.a.k;

@Retention(RetentionPolicy.CLASS)
@Target({ElementType.METHOD, ElementType.FIELD, ElementType.PARAMETER, ElementType.LOCAL_VARIABLE})
@k
@f(
   a = "[a-z_]+"
)
public @interface SourceId {
   String PATTERN = "[a-z_]+";
}
