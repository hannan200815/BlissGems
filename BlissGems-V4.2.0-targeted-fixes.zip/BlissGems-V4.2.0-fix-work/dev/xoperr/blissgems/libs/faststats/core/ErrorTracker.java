package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingBase;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingExecutors;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadFactory;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadPoolExecutor;
import java.util.Optional;
import java.util.function.BiConsumer;
import org.b.a.e;
import org.c.a.d;

public sealed interface ErrorTracker permits SimpleErrorTracker {
   @e(
      a = " -> new"
   )
   static ErrorTracker contextAware() {
      SimpleErrorTracker var0 = new SimpleErrorTracker();
      var0.attachErrorContext(ErrorTracker.class.getClassLoader());
      return var0;
   }

   @e(
      a = " -> new"
   )
   static ErrorTracker contextUnaware() {
      return new SimpleErrorTracker();
   }

   @e(
      c = "this"
   )
   void trackError(String var1);

   @e(
      c = "this"
   )
   void trackError(Throwable var1);

   void attachErrorContext(@d ClassLoader var1) throws IllegalStateException;

   void detachErrorContext();

   boolean isContextAttached();

   @e(
      c = "this"
   )
   void setContextErrorHandler(@d BiConsumer<@d ClassLoader, Throwable> var1);

   @e(
      b = true
   )
   Optional<BiConsumer<@d ClassLoader, Throwable>> getContextErrorHandler();

   @e(
      b = true
   )
   TrackingBase base();

   @e(
      b = true
   )
   TrackingExecutors executors();

   @e(
      b = true
   )
   TrackingThreadFactory threadFactory();

   @e(
      b = true
   )
   TrackingThreadPoolExecutor threadPoolExecutor();

   @e(
      b = true
   )
   static boolean isSameLoader(ClassLoader var0, Throwable var1) {
      return ErrorHelper.isSameLoader(var0, var1);
   }
}
