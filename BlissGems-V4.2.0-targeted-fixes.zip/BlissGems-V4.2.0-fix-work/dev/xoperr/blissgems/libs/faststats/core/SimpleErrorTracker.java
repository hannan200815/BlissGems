package dev.xoperr.blissgems.libs.faststats.core;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingBase;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingExecutors;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadFactory;
import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadPoolExecutor;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.BiConsumer;
import org.c.a.d;

final class SimpleErrorTracker implements ErrorTracker {
   private final Map<String, Integer> collected = new ConcurrentHashMap();
   private final Map<String, JsonObject> reports = new ConcurrentHashMap();
   private final TrackingBase base = new SimpleTrackingBase(this);
   private final TrackingExecutors executors = new SimpleTrackingExecutors(this);
   private final TrackingThreadFactory threadFactory = new SimpleTrackingThreadFactory(this);
   private final TrackingThreadPoolExecutor threadPoolExecutor = new SimpleTrackingThreadPoolExecutor(this);
   private volatile @d BiConsumer<@d ClassLoader, Throwable> errorEvent = null;
   private volatile Thread.@d UncaughtExceptionHandler originalHandler = null;

   public void trackError(String var1) {
      this.trackError((Throwable)(new RuntimeException(var1)));
   }

   public void trackError(Throwable var1) {
      try {
         JsonObject var2 = ErrorHelper.compile(var1, (List)null);
         String var3 = MurmurHash3.hash(var2);
         if ((Integer)this.collected.compute(var3, (var0, var1x) -> var1x == null ? 1 : var1x + 1) > 1) {
            return;
         }

         this.reports.put(var3, var2);
      } catch (NoClassDefFoundError var4) {
      }

   }

   public JsonArray getData() {
      JsonArray var1 = new JsonArray(this.reports.size());
      this.reports.forEach((var2, var3) -> {
         JsonObject var4 = var3.deepCopy();
         var4.addProperty("hash", var2);
         Integer var5 = (Integer)this.collected.getOrDefault(var2, 1);
         if (var5 > 1) {
            var4.addProperty("count", (Number)var5);
         }

         var1.add((JsonElement)var4);
      });
      this.collected.forEach((var2, var3) -> {
         if (var3 > 0 && !this.reports.containsKey(var2)) {
            JsonObject var4 = new JsonObject();
            var4.addProperty("hash", var2);
            if (var3 > 1) {
               var4.addProperty("count", (Number)var3);
            }

            var1.add((JsonElement)var4);
         }
      });
      return var1;
   }

   public void clear() {
      this.collected.replaceAll((var0, var1) -> 0);
      this.reports.clear();
   }

   public boolean needsFlushing() {
      if (!this.reports.isEmpty()) {
         return true;
      } else {
         for(Integer var2 : this.collected.values()) {
            if (var2 > 0) {
               return true;
            }
         }

         return false;
      }
   }

   public synchronized void attachErrorContext(@d ClassLoader var1) throws IllegalStateException {
      if (this.originalHandler != null) {
         throw new IllegalStateException("Error context already attached");
      } else {
         this.originalHandler = Thread.getDefaultUncaughtExceptionHandler();
         Thread.setDefaultUncaughtExceptionHandler((var2, var3) -> {
            Thread.UncaughtExceptionHandler var4 = this.originalHandler;
            if (var4 != null) {
               var4.uncaughtException(var2, var3);
            }

            try {
               if (var1 != null && !ErrorTracker.isSameLoader(var1, var3)) {
                  return;
               }

               BiConsumer var5 = this.errorEvent;
               if (var5 != null) {
                  var5.accept(var1, var3);
               }

               this.trackError(var3);
            } catch (Throwable var6) {
               this.trackError(var6);
            }

         });
      }
   }

   public synchronized void detachErrorContext() {
      if (this.originalHandler != null) {
         Thread.setDefaultUncaughtExceptionHandler(this.originalHandler);
         this.originalHandler = null;
      }
   }

   public synchronized boolean isContextAttached() {
      return this.originalHandler != null;
   }

   public synchronized void setContextErrorHandler(@d BiConsumer<@d ClassLoader, Throwable> var1) {
      this.errorEvent = var1;
   }

   public synchronized Optional<BiConsumer<@d ClassLoader, Throwable>> getContextErrorHandler() {
      return Optional.ofNullable(this.errorEvent);
   }

   public TrackingBase base() {
      return this.base;
   }

   public TrackingExecutors executors() {
      return this.executors;
   }

   public TrackingThreadFactory threadFactory() {
      return this.threadFactory;
   }

   public TrackingThreadPoolExecutor threadPoolExecutor() {
      return this.threadPoolExecutor;
   }
}
