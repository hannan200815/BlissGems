package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadPoolExecutor;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.RejectedExecutionHandler;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import org.b.a.o;

final class SimpleTrackingThreadPoolExecutor implements TrackingThreadPoolExecutor {
   private final ErrorTracker tracker;

   public SimpleTrackingThreadPoolExecutor(ErrorTracker var1) {
      this.tracker = var1;
   }

   public ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6) {
      return new ThreadPoolExecutor(var1, var2, var3, var5, var6, this.tracker.threadFactory()) {
         protected void afterExecute(Runnable var1, Throwable var2) {
            super.afterExecute(var1, var2);
            SimpleTrackingThreadPoolExecutor.this.tracker.trackError(var2);
         }
      };
   }

   public ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, ThreadFactory var7) {
      return new ThreadPoolExecutor(var1, var2, var3, var5, var6, var7) {
         protected void afterExecute(Runnable var1, Throwable var2) {
            super.afterExecute(var1, var2);
            SimpleTrackingThreadPoolExecutor.this.tracker.trackError(var2);
         }
      };
   }

   public ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, RejectedExecutionHandler var7) {
      return new ThreadPoolExecutor(var1, var2, var3, var5, var6, var7) {
         protected void afterExecute(Runnable var1, Throwable var2) {
            super.afterExecute(var1, var2);
            SimpleTrackingThreadPoolExecutor.this.tracker.trackError(var2);
         }
      };
   }

   public ThreadPoolExecutor create(@o(
   a = 0L,
   b = 2147483647L
) int var1, @o(
   a = 0L,
   b = 2147483647L
) int var2, @o(
   a = 0L,
   b = 2147483647L
) long var3, TimeUnit var5, BlockingQueue<Runnable> var6, ThreadFactory var7, RejectedExecutionHandler var8) {
      return new ThreadPoolExecutor(var1, var2, var3, var5, var6, var7, var8) {
         protected void afterExecute(Runnable var1, Throwable var2) {
            super.afterExecute(var1, var2);
            SimpleTrackingThreadPoolExecutor.this.tracker.trackError(var2);
         }
      };
   }
}
