package dev.xoperr.blissgems.libs.faststats.core.data;

import com.google.gson.JsonElement;
import java.util.Optional;
import java.util.concurrent.Callable;
import org.b.a.e;
import org.c.a.d;

public interface Metric<T> {
   @SourceId
   @e(
      b = true
   )
   String getId();

   @e(
      b = true
   )
   Optional<T> compute() throws Exception;

   @e(
      b = true
   )
   Optional<JsonElement> getData() throws Exception;

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<String[]> stringArray(@SourceId String var0, Callable<String @d []> var1) throws IllegalArgumentException {
      return new ArrayMetric<String[]>(var0, var1);
   }

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<Boolean[]> booleanArray(@SourceId String var0, Callable<Boolean @d []> var1) throws IllegalArgumentException {
      return new ArrayMetric<Boolean[]>(var0, var1);
   }

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<Number[]> numberArray(@SourceId String var0, Callable<Number @d []> var1) throws IllegalArgumentException {
      return new ArrayMetric<Number[]>(var0, var1);
   }

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<Boolean> bool(@SourceId String var0, Callable<@d Boolean> var1) throws IllegalArgumentException {
      return new SingleValueMetric<Boolean>(var0, var1);
   }

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<String> string(@SourceId String var0, Callable<@d String> var1) throws IllegalArgumentException {
      return new SingleValueMetric<String>(var0, var1);
   }

   @e(
      a = "_, _ -> new",
      b = true
   )
   static Metric<Number> number(@SourceId String var0, Callable<@d Number> var1) throws IllegalArgumentException {
      return new SingleValueMetric<Number>(var0, var1);
   }
}
