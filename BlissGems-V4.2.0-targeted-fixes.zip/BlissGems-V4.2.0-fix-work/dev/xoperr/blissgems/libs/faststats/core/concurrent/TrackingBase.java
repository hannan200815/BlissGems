package dev.xoperr.blissgems.libs.faststats.core.concurrent;

import java.security.PrivilegedAction;
import java.security.PrivilegedExceptionAction;
import org.b.a.e;

public interface TrackingBase {
   @e(
      a = "_ -> new",
      b = true
   )
   Runnable tracked(Runnable var1);

   @e(
      a = "_ -> new",
      b = true
   )
   <T> PrivilegedAction<T> tracked(PrivilegedAction<T> var1);

   @e(
      a = "_ -> new",
      b = true
   )
   <T> PrivilegedExceptionAction<T> tracked(PrivilegedExceptionAction<T> var1);
}
