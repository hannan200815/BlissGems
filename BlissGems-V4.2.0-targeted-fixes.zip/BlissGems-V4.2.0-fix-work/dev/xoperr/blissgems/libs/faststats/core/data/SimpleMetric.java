package dev.xoperr.blissgems.libs.faststats.core.data;

import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import org.c.a.d;

abstract class SimpleMetric<T> implements Metric<T> {
   @SourceId
   private final String id;
   private final Callable<@d T> callable;

   public SimpleMetric(@SourceId String var1, Callable<@d T> var2) throws IllegalArgumentException {
      if (!var1.matches("[a-z_]+")) {
         throw new IllegalArgumentException("Invalid source id '" + var1 + "', must match '[a-z_]+'");
      } else {
         this.id = var1;
         this.callable = var2;
      }
   }

   @SourceId
   public final String getId() {
      return this.id;
   }

   public final Optional<T> compute() throws Exception {
      return Optional.ofNullable(this.callable.call());
   }

   public boolean equals(Object var1) {
      if (var1 != null && this.getClass() == var1.getClass()) {
         SimpleMetric var2 = (SimpleMetric)var1;
         return Objects.equals(this.id, var2.id);
      } else {
         return false;
      }
   }

   public int hashCode() {
      return Objects.hashCode(this.id);
   }

   public String toString() {
      return "SimpleMetric{id='" + this.id + "'}";
   }
}
