package dev.xoperr.blissgems.libs.faststats.core;

import com.google.gson.JsonObject;
import java.nio.charset.StandardCharsets;
import org.b.a.e;

final class MurmurHash3 {
   public static String hash(JsonObject var0) {
      long[] var1 = hash(var0.toString());
      String var10000 = Long.toHexString(var1[0]);
      return var10000 + Long.toHexString(var1[1]);
   }

   @e(
      a = "_ -> new",
      b = true
   )
   private static long[] hash(String var0) {
      byte[] var1 = var0.getBytes(StandardCharsets.UTF_8);
      long var2 = 0L;
      long var4 = 0L;
      long var6 = -8663945395140668459L;
      long var8 = 5545529020109919103L;
      int var10 = var1.length;
      int var11 = var10 / 16;

      for(int var12 = 0; var12 < var11; ++var12) {
         int var13 = getInt(var1, var12 * 16);
         int var14 = getInt(var1, var12 * 16 + 4);
         getInt(var1, var12 * 16 + 8);
         getInt(var1, var12 * 16 + 12);
         var13 *= 289559509;
         var13 = Integer.rotateLeft(var13, 31);
         var13 *= 658871167;
         long var17 = var2 ^ (long)var13;
         long var18 = Long.rotateLeft(var17, 27);
         long var19 = var18 + var4;
         var2 = var19 * 5L + 1390208809L;
         var14 *= 658871167;
         var14 = Integer.rotateLeft(var14, 33);
         var14 *= 289559509;
         var4 ^= (long)var14;
         var4 = Long.rotateLeft(var4, 31);
         var4 += var2;
         var4 = var4 * 5L + 944331445L;
      }

      int var31 = 0;
      int var39 = 0;
      int var47 = 0;
      int var15 = 0;
      int var16 = var11 * 16;
      switch (var10 & 15) {
         case 15:
            var15 ^= (var1[var16 + 14] & 255) << 16;
         case 14:
            var15 ^= (var1[var16 + 13] & 255) << 8;
         case 13:
            var15 ^= var1[var16 + 12] & 255;
            var15 *= 658871167;
            var15 = Integer.rotateLeft(var15, 33);
            var15 *= 289559509;
            var4 ^= (long)var15;
         case 12:
            var47 ^= (var1[var16 + 11] & 255) << 24;
         case 11:
            var47 ^= (var1[var16 + 10] & 255) << 16;
         case 10:
            var47 ^= (var1[var16 + 9] & 255) << 8;
         case 9:
            var47 ^= var1[var16 + 8] & 255;
            var47 *= 289559509;
            var47 = Integer.rotateLeft(var47, 31);
            var47 *= 658871167;
            var2 ^= (long)var47;
         case 8:
            var39 ^= (var1[var16 + 7] & 255) << 24;
         case 7:
            var39 ^= (var1[var16 + 6] & 255) << 16;
         case 6:
            var39 ^= (var1[var16 + 5] & 255) << 8;
         case 5:
            var39 ^= var1[var16 + 4] & 255;
            var39 *= 658871167;
            var39 = Integer.rotateLeft(var39, 33);
            var39 *= 289559509;
            var4 ^= (long)var39;
         case 4:
            var31 ^= (var1[var16 + 3] & 255) << 24;
         case 3:
            var31 ^= (var1[var16 + 2] & 255) << 16;
         case 2:
            var31 ^= (var1[var16 + 1] & 255) << 8;
         case 1:
            var31 ^= var1[var16] & 255;
            var31 *= 289559509;
            var31 = Integer.rotateLeft(var31, 31);
            var31 *= 658871167;
            var2 ^= (long)var31;
         default:
            var2 ^= (long)var10;
            var4 ^= (long)var10;
            var2 += var4;
            var4 += var2;
            var2 = fmix64(var2);
            var4 = fmix64(var4);
            var2 += var4;
            var4 += var2;
            return new long[]{var2, var4};
      }
   }

   @e(
      b = true
   )
   private static long fmix64(long var0) {
      var0 ^= var0 >>> 33;
      var0 *= -49064778989728563L;
      var0 ^= var0 >>> 33;
      var0 *= -4265267296055464877L;
      var0 ^= var0 >>> 33;
      return var0;
   }

   @e(
      b = true
   )
   private static int getInt(byte[] var0, int var1) {
      return var0[var1] & 255 | (var0[var1 + 1] & 255) << 8 | (var0[var1 + 2] & 255) << 16 | (var0[var1 + 3] & 255) << 24;
   }
}
