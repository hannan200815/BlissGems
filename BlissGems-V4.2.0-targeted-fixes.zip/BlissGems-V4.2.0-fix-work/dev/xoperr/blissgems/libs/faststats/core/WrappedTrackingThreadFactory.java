package dev.xoperr.blissgems.libs.faststats.core;

import dev.xoperr.blissgems.libs.faststats.core.concurrent.TrackingThreadFactory;
import java.util.concurrent.ThreadFactory;

final class WrappedTrackingThreadFactory implements ThreadFactory {
   private final ErrorTracker tracker;
   private final ThreadFactory factory;

   public WrappedTrackingThreadFactory(ErrorTracker var1, ThreadFactory var2) {
      this.tracker = var1;
      this.factory = var2;
   }

   public Thread newThread(Runnable var1) {
      return this.factory.newThread(this.tracker.base().tracked(var1));
   }

   public static ThreadFactory wrap(ErrorTracker var0, ThreadFactory var1) {
      return (ThreadFactory)(!(var1 instanceof TrackingThreadFactory) && !(var1 instanceof WrappedTrackingThreadFactory) ? new WrappedTrackingThreadFactory(var0, var1) : var1);
   }
}
