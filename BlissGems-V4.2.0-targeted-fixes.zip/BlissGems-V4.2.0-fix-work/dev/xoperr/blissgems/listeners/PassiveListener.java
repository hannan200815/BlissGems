package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.a.c;
import dev.xoperr.blissgems.a.f;
import dev.xoperr.blissgems.a.h;
import dev.xoperr.blissgems.managers.FlowStateManager;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import dev.xoperr.blissgems.utils.ParticleUtils;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.Tag;
import org.bukkit.block.Block;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Creeper;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Fireball;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.entity.Projectile;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.block.BlockReceiveGameEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.FoodLevelChangeEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.entity.EntityDamageEvent.DamageCause;
import org.bukkit.event.inventory.CraftItemEvent;
import org.bukkit.event.inventory.FurnaceExtractEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.event.player.PlayerToggleSprintEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.Damageable;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.projectiles.ProjectileSource;
import org.bukkit.util.Vector;

public class PassiveListener implements Listener {
   private final BlissGems plugin;
   private final Map<UUID, Integer> jumpsRemaining = new HashMap();

   public PassiveListener(BlissGems var1) {
      this.plugin = var1;
   }

   private boolean isHoldingPuffGem(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      if (var2 != null) {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 != null && var3.contains("puff_gem")) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   public void onEntityDamage(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getEntity();
      if (var2 instanceof Player var3) {
         if (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.ASTRA)) {
            if (this.canUsePassives(var3)) {
               int var4 = this.plugin.getGemManager().getTierFromOffhand(var3);
               double var5 = this.plugin.getConfigManager().getPhaseChance(var4);
               if (Math.random() < var5) {
                  var1.setCancelled(true);
                  var3.sendMessage("§d§oYou phased through the attack!");
                  if (this.plugin.getAchievementManager() != null && var3.getHealth() <= var1.getDamage()) {
                     this.plugin.getAchievementManager().unlock(var3, Achievement.SAVED_BY_THE_DICE);
                  }
               }

            }
         }
      }
   }

   @EventHandler
   public void onPlayerDamageEntity(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getDamager();
      if (var2 instanceof Player var3) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof LivingEntity var5) {
            if (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.LIFE)) {
               if (this.canUsePassives(var3)) {
                  if (Tag.ENTITY_TYPES_SENSITIVE_TO_SMITE.isTagged(var5.getType())) {
                     int var6 = this.plugin.getGemManager().getTierFromOffhand(var3);
                     double var7 = this.plugin.getConfigManager().getUndeadDamageMultiplier(var6);
                     var1.setDamage(var1.getDamage() * var7);
                  }

               }
            }
         }
      }
   }

   @EventHandler
   public void onPuffGemHitPlayer(EntityDamageByEntityEvent var1) {
      Entity var2 = var1.getDamager();
      if (var2 instanceof Player var3) {
         Entity var4 = var1.getEntity();
         if (var4 instanceof Player var5) {
            ItemStack var6 = var3.getInventory().getItemInMainHand();
            if (var6 != null) {
               String var7 = CustomItemManager.getIdByItem(var6);
               if (var7 != null && var7.contains("puff_gem")) {
                  if (this.canUsePassives(var3)) {
                     int var8 = GemType.getTierFromOraxenId(var7);
                     double var9 = this.plugin.getConfigManager().getLaunchVelocity(var8);
                     Vector var11 = new Vector((double)0.0F, var9, (double)0.0F);
                     var5.setVelocity(var11);
                     var5.getWorld().playSound(var5.getLocation(), Sound.ENTITY_BREEZE_WIND_BURST, 1.0F, 0.8F);
                     var5.getWorld().spawnParticle(Particle.CLOUD, var5.getLocation(), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                     var5.sendMessage("§b§oYou've been launched into the sky!");
                     var3.sendMessage("§b§oYou launched " + var5.getName() + " into the sky!");
                     this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                        if (var5.isOnline()) {
                           Vector var1 = new Vector((double)0.0F, (double)-3.5F, (double)0.0F);
                           var5.setVelocity(var1);
                           var5.getWorld().playSound(var5.getLocation(), Sound.ENTITY_BREEZE_LAND, 1.0F, 0.5F);
                           var5.sendMessage("§c§oYou're being slammed down!");
                        }
                     }, 60L);
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onFallDamage(EntityDamageEvent var1) {
      Entity var2 = var1.getEntity();
      if (var2 instanceof Player var3) {
         if (var1.getCause() == DamageCause.FALL) {
            if (this.plugin.getPuffAbilities().a(var3)) {
               var1.setCancelled(true);
               this.plugin.getPuffAbilities().b(var3);
            } else if (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.PUFF) || this.isHoldingPuffGem(var3)) {
               if (this.canUsePassives(var3)) {
                  var1.setCancelled(true);
                  if (this.plugin.getAchievementManager() != null) {
                     int var4 = (int)var1.getDamage();
                     this.plugin.getAchievementManager().addProgress(var3, Achievement.ALMOST_FELL_FROM_GRACE, var4);
                  }

               }
            }
         }
      }
   }

   @EventHandler
   public void onPlayerMove(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      if (var2.getGameMode() != GameMode.CREATIVE && var2.getGameMode() != GameMode.SPECTATOR) {
         boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.PUFF) || this.isHoldingPuffGem(var2);
         boolean var4 = var3 && this.canUsePassives(var2);
         if (var4 && var2.isOnGround()) {
            this.jumpsRemaining.put(var2.getUniqueId(), 2);
            if (!var2.getAllowFlight()) {
               var2.setAllowFlight(true);
            }
         } else if (!var4 && var2.getAllowFlight() && var2.getGameMode() == GameMode.SURVIVAL) {
            var2.setAllowFlight(false);
            this.jumpsRemaining.remove(var2.getUniqueId());
         }

      }
   }

   @EventHandler
   public void onTripleJumpFlight(PlayerToggleFlightEvent var1) {
      Player var2 = var1.getPlayer();
      if (var2.getGameMode() != GameMode.CREATIVE && var2.getGameMode() != GameMode.SPECTATOR) {
         boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.PUFF) || this.isHoldingPuffGem(var2);
         if (var3) {
            if (this.canUsePassives(var2)) {
               UUID var4 = var2.getUniqueId();
               if (!c.a(var4) && !f.a(var4)) {
                  int var5 = (Integer)this.jumpsRemaining.getOrDefault(var4, 0);
                  if (var5 <= 0) {
                     var1.setCancelled(true);
                  } else {
                     var1.setCancelled(true);
                     var2.setAllowFlight(false);
                     this.jumpsRemaining.put(var4, var5 - 1);
                     int var6 = this.plugin.getGemManager().getTierFromOffhand(var2);
                     if (var6 == 0) {
                        ItemStack var7 = var2.getInventory().getItemInMainHand();
                        String var8 = CustomItemManager.getIdByItem(var7);
                        if (var8 != null) {
                           var6 = GemType.getTierFromOraxenId(var8);
                        }
                     }

                     if (var6 == 0) {
                        var6 = 1;
                     }

                     double var10 = this.plugin.getConfigManager().getDoubleJumpVelocity(var6);
                     Vector var9 = var2.getVelocity();
                     var9.setY(var10);
                     var2.setVelocity(var9);
                     var2.getWorld().spawnParticle(Particle.CLOUD, var2.getLocation(), 20, 0.3, 0.1, 0.3, 0.05);
                     var2.playSound(var2.getLocation(), Sound.ENTITY_BREEZE_SHOOT, 0.5F, 1.5F);
                     if (var5 - 1 > 0) {
                        this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                           if (var2.isOnline() && !var2.isOnGround() && var2.getGameMode() != GameMode.CREATIVE && var2.getGameMode() != GameMode.SPECTATOR) {
                              var2.setAllowFlight(true);
                           }

                        }, 2L);
                     }

                  }
               } else {
                  var1.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler
   public void onFarmlandTrample(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.PHYSICAL) {
         if (var1.getClickedBlock() != null && var1.getClickedBlock().getType() == Material.FARMLAND) {
            Player var2 = var1.getPlayer();
            boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.PUFF) || this.isHoldingPuffGem(var2);
            if (var3) {
               if (this.canUsePassives(var2)) {
                  var1.setCancelled(true);
               }
            }
         }
      }
   }

   @EventHandler
   public void onCrispBlockBreak(BlockBreakEvent var1) {
      if (this.plugin.getFireAbilities() != null && this.plugin.getFireAbilities().a(var1.getBlock().getLocation())) {
         var1.setCancelled(true);
         var1.getPlayer().sendMessage("§c§oThis block is scorched and cannot be broken!");
      }

   }

   @EventHandler
   public void onBlockBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FIRE);
      boolean var4 = false;
      if (this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.WEALTH)) {
         int var5 = this.plugin.getGemManager().getGemTier(var2);
         if (var5 >= 2 && this.plugin.getWealthAbilities().f(var2)) {
            var4 = true;
         }
      }

      if (var3 || var4) {
         if (this.canUsePassives(var2)) {
            ItemStack var8 = var2.getInventory().getItemInMainHand();
            if (var8 == null || !var8.hasItemMeta() || !var8.getItemMeta().hasEnchant(Enchantment.SILK_TOUCH)) {
               Material var6 = var1.getBlock().getType();
               ItemStack var7 = this.getSmeltedItem(var6);
               if (var7 != null) {
                  var1.setDropItems(false);
                  var1.getBlock().getWorld().dropItemNaturally(var1.getBlock().getLocation(), var7);
               }

            }
         }
      }
   }

   private ItemStack getSmeltedItem(Material var1) {
      ItemStack var10000;
      switch (var1) {
         case IRON_ORE:
         case DEEPSLATE_IRON_ORE:
            var10000 = new ItemStack(Material.IRON_INGOT);
            break;
         case GOLD_ORE:
         case DEEPSLATE_GOLD_ORE:
         case NETHER_GOLD_ORE:
            var10000 = new ItemStack(Material.GOLD_INGOT);
            break;
         case COPPER_ORE:
         case DEEPSLATE_COPPER_ORE:
            var10000 = new ItemStack(Material.COPPER_INGOT);
            break;
         case ANCIENT_DEBRIS:
            var10000 = new ItemStack(Material.NETHERITE_SCRAP);
            break;
         case SAND:
            var10000 = new ItemStack(Material.GLASS);
            break;
         case COBBLESTONE:
            var10000 = new ItemStack(Material.STONE);
            break;
         case RAW_IRON_BLOCK:
            var10000 = new ItemStack(Material.IRON_BLOCK);
            break;
         case RAW_GOLD_BLOCK:
            var10000 = new ItemStack(Material.GOLD_BLOCK);
            break;
         case RAW_COPPER_BLOCK:
            var10000 = new ItemStack(Material.COPPER_BLOCK);
            break;
         default:
            var10000 = null;
      }

      return var10000;
   }

   @EventHandler
   public void onFoodLevelChange(FoodLevelChangeEvent var1) {
      HumanEntity var2 = var1.getEntity();
      if (var2 instanceof Player var3) {
         if (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.LIFE)) {
            if (this.canUsePassives(var3)) {
               int var4 = var3.getFoodLevel();
               int var5 = var1.getFoodLevel();
               if (var5 > var4) {
                  int var6 = var5 - var4;
                  int var7 = this.plugin.getGemManager().getTierFromOffhand(var3);
                  float var8 = (float)var6 * (float)this.plugin.getConfigManager().getSaturationMultiplier(var7);
                  var3.setSaturation(var3.getSaturation() + var8);
               }

            }
         }
      }
   }

   @EventHandler
   public void onProjectileHit(ProjectileHitEvent var1) {
      Projectile var2 = var1.getEntity();
      if (var2 instanceof Arrow) {
         ProjectileSource var3 = var2.getShooter();
         if (var3 instanceof Player) {
            Player var4 = (Player)var3;
            if ((this.plugin.getGemManager().hasGemTypeInOffhand(var4, GemType.FLUX) || this.isHoldingFluxGem(var4))) {
               if (this.canUsePassives(var4)) {
                  Entity var5 = var1.getHitEntity();
                  if (var5 != null && var5 instanceof LivingEntity) {
                     double var6 = this.plugin.getConfig().getDouble("gems.passives.flux.shocking-chance", 0.15);
                     if (!(Math.random() > var6)) {
                        LivingEntity var8 = (LivingEntity)var5;
                        int var9 = this.getFluxTier(var4);
                        double var10 = this.plugin.getConfigManager().getShockingArrowDamage(var9);
                        var8.damage(var10, var4);
                        int var12 = this.plugin.getConfig().getInt("abilities.durations.flux-shocking-stun", 1) * 20;
                        var8.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, var12, 255, false, false));
                        var8.addPotionEffect(new PotionEffect(PotionEffectType.MINING_FATIGUE, var12, 255, false, false));
                        var8.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 60, 0.7, 0.7, 0.7);
                        var8.getWorld().spawnParticle(Particle.ENCHANTED_HIT, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F);
                        var8.getWorld().spawnParticle(Particle.CRIT, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F);
                        var8.getWorld().spawnParticle(Particle.SOUL_FIRE_FLAME, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 15, 0.3, 0.3, 0.3);
                        var8.getWorld().playSound(var8.getLocation(), Sound.ENTITY_LIGHTNING_BOLT_IMPACT, 0.5F, 1.5F);
                        var4.sendMessage("§b§oShocking Arrow hit!");
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onSculkShriekerActivate(BlockReceiveGameEvent var1) {
      Entity var2 = var1.getEntity();
      if (var2 instanceof Player var3) {
         if (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.PUFF)) {
            if (this.canUsePassives(var3)) {
               int var4 = this.plugin.getGemManager().getTierFromOffhand(var3);
               if (this.plugin.getConfigManager().isSculkImmunity(var4)) {
                  Material var5 = var1.getBlock().getType();
                  if (var5 == Material.SCULK_SHRIEKER || var5 == Material.SCULK_SENSOR || var5 == Material.CALIBRATED_SCULK_SENSOR) {
                     var1.setCancelled(true);
                  }

               }
            }
         }
      }
   }

   @EventHandler
   public void onPlayerItemConsume(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3.getType() == Material.GOLDEN_APPLE || var3.getType() == Material.ENCHANTED_GOLDEN_APPLE) {
         if (this.plugin.getGemManager().hasGemType(var2, GemType.LIFE)) {
            if (this.canUsePassives(var2)) {
               int var4 = this.plugin.getGemManager().getGemTier(var2);
               int var5 = this.plugin.getConfigManager().getGoldenAppleAbsorptionLevel(var4);
               this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                  var2.addPotionEffect(new PotionEffect(PotionEffectType.ABSORPTION, 2400, var5, true, true));
                  var2.sendMessage("§a§oLife Gem enhanced your golden apple!");
               }, 1L);
            }
         }
      }
   }

   @EventHandler
   public void onFireballExplosion(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         Entity var3 = var1.getDamager();
         if (var3 instanceof Fireball) {
            Fireball var4 = (Fireball)var3;
            if (var4.getShooter() instanceof Player) {
               Player var5 = (Player)var4.getShooter();
               if (var5.getUniqueId().equals(var2.getUniqueId())) {
                  var1.setCancelled(true);
               }
            }
         }

      }
   }

   @EventHandler
   public void onEntityDeath(EntityDeathEvent var1) {
      LivingEntity var2 = var1.getEntity();
      Player var3 = var2.getKiller();
      if (var3 != null) {
         boolean var4 = this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.ASTRA) || this.isHoldingAstraGem(var3);
         if (var4) {
            if (this.plugin.getEnergyManager().arePassivesActive(var3)) {
               this.plugin.getSoulManager().absorbSoul(var3, var2);
            }
         }
      }
   }

   @EventHandler
   public void onAstraSoulCapture(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if (var2.isSneaking()) {
            Entity var3 = var1.getEntity();
            if (var3 instanceof LivingEntity && !(var3 instanceof Player)) {
               boolean var4 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.ASTRA) || this.isHoldingAstraGem(var2);
               if (var4) {
                  if (this.canUsePassives(var2)) {
                     LivingEntity var5 = (LivingEntity)var3;
                     if (this.plugin.getSoulManager().captureMob(var2, var5)) {
                        var1.setCancelled(true);
                     }

                  }
               }
            }
         }
      }
   }

   private boolean isHoldingAstraGem(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      if (var2 != null) {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 != null && var3.contains("astra_gem")) {
            return true;
         }
      }

      return false;
   }

   private boolean isHoldingFluxGem(Player var1) {
      ItemStack main = var1.getInventory().getItemInMainHand();
      ItemStack off = var1.getInventory().getItemInOffHand();
      String mainId = CustomItemManager.getIdByItem(main);
      String offId = CustomItemManager.getIdByItem(off);
      return (mainId != null && mainId.contains("flux_gem"))
          || (offId != null && offId.contains("flux_gem"));
   }

   private int getFluxTier(Player player) {
      ItemStack main = player.getInventory().getItemInMainHand();
      String mainId = CustomItemManager.getIdByItem(main);
      if (mainId != null && mainId.contains("flux_gem")) {
         return mainId.endsWith("_gem_t2") ? 2 : 1;
      }
      ItemStack off = player.getInventory().getItemInOffHand();
      String offId = CustomItemManager.getIdByItem(off);
      if (offId != null && offId.contains("flux_gem")) {
         return offId.endsWith("_gem_t2") ? 2 : 1;
      }
      return 1;
   }

   @EventHandler
   public void onFluxConduction(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.LEFT_CLICK_AIR || var1.getAction() == Action.LEFT_CLICK_BLOCK) {
         Player var2 = var1.getPlayer();
         if (var2.isSneaking()) {
            boolean var3 = (this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FLUX) || this.isHoldingFluxGem(var2)) || this.isHoldingFluxGem(var2);
            if (var3) {
               if (this.canUsePassives(var2)) {
                  String var4 = "flux-conduction";
                  if (this.plugin.getAbilityManager().canUseAbility(var2, var4)) {
                     int var5 = this.plugin.getConfig().getInt("abilities.flux-conduction.range", 10);
                     Location var6 = var2.getLocation();
                     Block var7 = null;
                     double var8 = Double.MAX_VALUE;

                     for(int var10 = -var5; var10 <= var5; ++var10) {
                        for(int var11 = -var5; var11 <= var5; ++var11) {
                           for(int var12 = -var5; var12 <= var5; ++var12) {
                              Block var13 = var6.getBlock().getRelative(var10, var11, var12);
                              if (var13.getType().name().contains("COPPER") && !var13.getType().name().contains("COPPERHEAD")) {
                                 double var14 = var13.getLocation().distanceSquared(var6);
                                 if (var14 < var8) {
                                    var8 = var14;
                                    var7 = var13;
                                 }
                              }
                           }
                        }
                     }

                     if (var7 != null) {
                        Location var16 = var2.getLocation().clone();
                        Location var17 = var7.getLocation().add((double)0.5F, (double)1.0F, (double)0.5F);
                        var17.setYaw(var2.getLocation().getYaw());
                        var17.setPitch(var2.getLocation().getPitch());
                        if (this.plugin.getAchievementManager() != null) {
                           int var18 = (int)var16.distance(var17);
                           this.plugin.getAchievementManager().addProgress(var2, Achievement.ZIP_AWAY, var18);
                        }

                        var2.teleport(var17);
                        Particle.DustOptions var19 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.2F);
                        var16.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var16.add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                        var16.getWorld().spawnParticle(Particle.DUST, var16, 40, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var19, true);
                        var17.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var17.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                        var17.getWorld().spawnParticle(Particle.DUST, var17.clone().add((double)0.0F, (double)0.5F, (double)0.0F), 40, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var19, true);
                        var2.playSound(var16, Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.5F);
                        var2.playSound(var17, Sound.BLOCK_COPPER_BULB_TURN_ON, 1.0F, 1.2F);
                        var2.sendMessage("§b⚡ §oConducted to copper!");
                        this.plugin.getAbilityManager().useAbility(var2, var4);
                     }
                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onChargedCreeperDamage(EntityDamageByEntityEvent var1) {
      if (var1.getEntity() instanceof Player) {
         if (var1.getDamager() instanceof Creeper) {
            Creeper var2 = (Creeper)var1.getDamager();
            if (var2.isPowered()) {
               Player var3 = (Player)var1.getEntity();
               boolean var4 = (this.plugin.getGemManager().hasGemTypeInOffhand(var3, GemType.FLUX) || this.isHoldingFluxGem(var3)) || this.isHoldingFluxGem(var3);
               if (var4) {
                  if (this.canUsePassives(var3)) {
                     double var5 = this.plugin.getConfig().getDouble("gems.passives.flux.charged-creeper-reduction", (double)1.0F);
                     var1.setDamage(var1.getDamage() * ((double)1.0F - var5));
                     Particle.DustOptions var7 = new Particle.DustOptions(ParticleUtils.FLUX_CYAN, 1.2F);
                     var3.getWorld().spawnParticle(Particle.DUST, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, (double)0.5F, (double)0.5F, (double)0.5F, (double)0.0F, var7, true);
                     var3.getWorld().spawnParticle(Particle.ELECTRIC_SPARK, var3.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.1);
                     var3.sendMessage("§b⚡ §oFlux gem absorbed the charged creeper blast!");
                  }
               }
            }
         }
      }
   }

   private boolean isHoldingStrengthGem(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      if (var2 != null) {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 != null && var3.contains("strength_gem")) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   public void onStrengthBloodthorns(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if (var1.getEntity() instanceof LivingEntity) {
            boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.STRENGTH) || this.isHoldingStrengthGem(var2);
            if (var3) {
               if (this.canUsePassives(var2)) {
                  int var4 = this.plugin.getGemManager().getTierFromOffhand(var2);
                  if (var4 == 0) {
                     ItemStack var5 = var2.getInventory().getItemInMainHand();
                     String var6 = CustomItemManager.getIdByItem(var5);
                     if (var6 != null) {
                        var4 = GemType.getTierFromOraxenId(var6);
                     }
                  }

                  if (var4 == 0) {
                     var4 = 1;
                  }

                  double var18 = this.plugin.getConfigManager().getBloodthornsMaxBonusDamage(var4);
                  double var7 = var2.getHealth();
                  double var9 = var2.getMaxHealth();
                  double var11 = var7 / var9;
                  double var13 = var18 * ((double)1.0F - var11);
                  if (var13 > 0.1) {
                     var1.setDamage(var1.getDamage() + var13);
                     LivingEntity var15 = (LivingEntity)var1.getEntity();
                     Particle.DustOptions var16 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 1.0F);
                     int var17 = Math.min((int)(var13 * (double)3.0F), 30);
                     var15.getWorld().spawnParticle(Particle.DUST, var15.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), var17, 0.3, 0.3, 0.3, (double)0.0F, var16, true);
                     var15.getWorld().spawnParticle(Particle.DAMAGE_INDICATOR, var15.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), Math.min((int)(var13 * (double)2.0F), 15), 0.3, 0.3, 0.3);
                  }

               }
            }
         }
      }
   }

   private boolean isHoldingWealthGem(Player var1) {
      ItemStack var2 = var1.getInventory().getItemInMainHand();
      if (var2 != null) {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 != null && var3.contains("wealth_gem")) {
            return true;
         }
      }

      return false;
   }

   @EventHandler
   public void onWealthDurabilityChip(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if (var1.getEntity() instanceof LivingEntity) {
            LivingEntity var3 = (LivingEntity)var1.getEntity();
            boolean var4 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.WEALTH) || this.isHoldingWealthGem(var2);
            if (var4) {
               if (this.canUsePassives(var2)) {
                  int var5 = this.plugin.getGemManager().getTierFromOffhand(var2);
                  if (var5 == 0) {
                     ItemStack var6 = var2.getInventory().getItemInMainHand();
                     String var7 = CustomItemManager.getIdByItem(var6);
                     if (var7 != null) {
                        var5 = GemType.getTierFromOraxenId(var7);
                     }
                  }

                  if (var5 == 0) {
                     var5 = 1;
                  }

                  String var13 = var5 == 2 ? "tier2" : "tier1";
                  int var14 = this.plugin.getConfig().getInt("passives.wealth." + var13 + ".durability-chip-extra-damage", 1);
                  if (var3 instanceof Player) {
                     Player var8 = (Player)var3;
                     ItemStack[] var9 = var8.getInventory().getArmorContents();
                     boolean var10 = false;

                     for(int var11 = 0; var11 < var9.length; ++var11) {
                        if (var9[var11] != null && !var9[var11].getType().isAir() && var9[var11].getItemMeta() instanceof Damageable) {
                           Damageable var12 = (Damageable)var9[var11].getItemMeta();
                           var12.setDamage(var12.getDamage() + var14);
                           var9[var11].setItemMeta(var12);
                           var10 = true;
                        }
                     }

                     if (var10) {
                        var8.getInventory().setArmorContents(var9);
                        Particle.DustOptions var15 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.0F);
                        var8.getWorld().spawnParticle(Particle.DUST, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, 0.3, 0.3, 0.3, (double)0.0F, var15, true);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onWealthArmorMend(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if (var1.getEntity() instanceof LivingEntity) {
            if (var1.getEntity() != var2) {
               boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.WEALTH) || this.isHoldingWealthGem(var2);
               if (var3) {
                  if (this.canUsePassives(var2)) {
                     int var4 = this.plugin.getGemManager().getTierFromOffhand(var2);
                     if (var4 == 0) {
                        ItemStack var5 = var2.getInventory().getItemInMainHand();
                        String var6 = CustomItemManager.getIdByItem(var5);
                        if (var6 != null) {
                           var4 = GemType.getTierFromOraxenId(var6);
                        }
                     }

                     if (var4 == 0) {
                        var4 = 1;
                     }

                     String var12 = var4 == 2 ? "tier2" : "tier1";
                     int var13 = this.plugin.getConfig().getInt("passives.wealth." + var12 + ".armor-mend-amount", 2);
                     ItemStack[] var7 = var2.getInventory().getArmorContents();
                     boolean var8 = false;

                     for(int var9 = 0; var9 < var7.length; ++var9) {
                        if (var7[var9] != null && !var7[var9].getType().isAir() && var7[var9].getItemMeta() instanceof Damageable) {
                           Damageable var10 = (Damageable)var7[var9].getItemMeta();
                           int var11 = var10.getDamage();
                           if (var11 > 0) {
                              var10.setDamage(Math.max(0, var11 - var13));
                              var7[var9].setItemMeta(var10);
                              var8 = true;
                           }
                        }
                     }

                     if (var8) {
                        var2.getInventory().setArmorContents(var7);
                        Particle.DustOptions var14 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 0.8F);
                        var2.getWorld().spawnParticle(Particle.DUST, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 8, 0.3, 0.3, 0.3, (double)0.0F, var14, true);
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onWealthDoubleDebris(FurnaceExtractEvent var1) {
      Player var2 = var1.getPlayer();
      boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.WEALTH) || this.isHoldingWealthGem(var2);
      if (var3) {
         if (this.canUsePassives(var2)) {
            int var4 = this.plugin.getGemManager().getTierFromOffhand(var2);
            if (var4 == 0) {
               ItemStack var5 = var2.getInventory().getItemInMainHand();
               String var6 = CustomItemManager.getIdByItem(var5);
               if (var6 != null) {
                  var4 = GemType.getTierFromOraxenId(var6);
               }
            }

            if (var4 == 0) {
               var4 = 1;
            }

            String var8 = var4 == 2 ? "tier2" : "tier1";
            boolean var9 = this.plugin.getConfig().getBoolean("passives.wealth." + var8 + ".double-debris", true);
            if (var9) {
               if (var1.getItemType() == Material.NETHERITE_SCRAP) {
                  var2.getWorld().dropItemNaturally(var2.getLocation(), new ItemStack(Material.NETHERITE_SCRAP, 1));
                  Particle.DustOptions var7 = new Particle.DustOptions(ParticleUtils.WEALTH_GREEN, 1.2F);
                  var2.getWorld().spawnParticle(Particle.DUST, var2.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, 0.3, 0.3, 0.3, (double)0.0F, var7, true);
                  var2.playSound(var2.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.2F);
                  var2.sendMessage("§a§oDouble Debris! Extra netherite scrap!");
               }
            }
         }
      }
   }

   @EventHandler
   public void onUnfortunateAttack(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.attack-fail-chance", (double)0.75F);
         if (h.a(var2.getUniqueId(), var3)) {
            var1.setCancelled(true);
            var2.sendMessage("§c§oYou can't do that while Unfortunate!");
         }

      }
   }

   @EventHandler
   public void onUnfortunateBlockPlace(BlockPlaceEvent var1) {
      Player var2 = var1.getPlayer();
      double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.block-place-fail-chance", (double)1.0F);
      if (h.a(var2.getUniqueId(), var3)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§oYou can't do that while Unfortunate!");
      }

   }

   @EventHandler
   public void onUnfortunateEat(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.eat-fail-chance", (double)1.0F);
      if (h.a(var2.getUniqueId(), var3)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§oYou can't do that while Unfortunate!");
      }

   }

   @EventHandler
   public void onUnfortunateBlockBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.block-break-fail-chance", (double)0.5F);
      if (h.a(var2.getUniqueId(), var3)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§oYou can't do that while Unfortunate!");
      }

   }

   @EventHandler
   public void onUnfortunateSprint(PlayerToggleSprintEvent var1) {
      if (var1.isSprinting()) {
         Player var2 = var1.getPlayer();
         double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.sprint-fail-chance", (double)0.5F);
         if (h.a(var2.getUniqueId(), var3)) {
            var1.setCancelled(true);
            var2.sendMessage("§c§oYou can't do that while Unfortunate!");
         }

      }
   }

   @EventHandler
   public void onUnfortunateJump(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getFrom().getY() < var1.getTo().getY() && var2.isOnGround()) {
         double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.jump-fail-chance", 0.3);
         if (h.a(var2.getUniqueId(), var3)) {
            var1.setTo(var1.getFrom());
            var2.sendMessage("§c§oYou can't do that while Unfortunate!");
         }
      }

   }

   @EventHandler
   public void onUnfortunateDropItem(PlayerDropItemEvent var1) {
      Player var2 = var1.getPlayer();
      double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.drop-item-fail-chance", 0.8);
      if (h.a(var2.getUniqueId(), var3)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§oYou can't do that while Unfortunate!");
      }

   }

   @EventHandler
   public void onUnfortunatePickupItem(EntityPickupItemEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.pickup-item-fail-chance", 0.7);
         if (h.a(var2.getUniqueId(), var3)) {
            var1.setCancelled(true);
            var2.sendMessage("§c§oYou can't do that while Unfortunate!");
         }

      }
   }

   @EventHandler
   public void onUnfortunateInteract(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.interact-fail-chance", 0.6);
      if (h.a(var2.getUniqueId(), var3)) {
         var1.setCancelled(true);
         var2.sendMessage("§c§oYou can't do that while Unfortunate!");
      }

   }

   @EventHandler
   public void onUnfortunateCraft(CraftItemEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         double var3 = this.plugin.getConfig().getDouble("passives.unfortunate.craft-fail-chance", 0.9);
         if (h.a(var2.getUniqueId(), var3)) {
            var1.setCancelled(true);
            var2.sendMessage("§c§oYou can't do that while Unfortunate!");
         }

      }
   }

   @EventHandler
   public void onItemLockUse(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      if (h.c(var2.getUniqueId())) {
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         ItemStack var4 = h.d(var2.getUniqueId());
         if (var4 != null && var3 != null) {
            if (var3.isSimilar(var4)) {
               var1.setCancelled(true);
               var2.sendMessage("§c§oThis item is locked!");
            }

         }
      }
   }

   @EventHandler
   public void onItemLockSwitch(PlayerItemHeldEvent var1) {
      Player var2 = var1.getPlayer();
      if (h.c(var2.getUniqueId())) {
         ItemStack var3 = var2.getInventory().getItem(var1.getNewSlot());
         ItemStack var4 = h.d(var2.getUniqueId());
         if (var4 != null && var3 != null) {
            if (var3.isSimilar(var4)) {
               var2.sendMessage("§c§oWarning: This item is locked!");
            }

         }
      }
   }

   @EventHandler
   public void onStrengthChadHit(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if (var1.getEntity() instanceof LivingEntity) {
            boolean var3 = this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.STRENGTH) || this.isHoldingStrengthGem(var2);
            if (var3) {
               if (this.canUsePassives(var2)) {
                  int var4 = this.plugin.getGemManager().getTierFromOffhand(var2);
                  if (var4 == 0) {
                     ItemStack var5 = var2.getInventory().getItemInMainHand();
                     String var6 = CustomItemManager.getIdByItem(var5);
                     if (var6 != null) {
                        var4 = GemType.getTierFromOraxenId(var6);
                     }
                  }

                  if (var4 >= 2) {
                     boolean var10 = this.plugin.getCriticalHitManager().registerHit(var2);
                     if (var10) {
                        double var11 = this.plugin.getConfig().getDouble("abilities.strength-chad.bonus-damage", (double)7.0F);
                        var1.setDamage(var1.getDamage() + var11);
                        LivingEntity var8 = (LivingEntity)var1.getEntity();
                        Particle.DustOptions var9 = new Particle.DustOptions(ParticleUtils.STRENGTH_RED, 2.0F);
                        var8.getWorld().spawnParticle(Particle.DUST, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 50, 0.8, 0.8, 0.8, (double)0.0F, var9, true);
                        var8.getWorld().spawnParticle(Particle.CRIT, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F, 0.3);
                        var8.getWorld().spawnParticle(Particle.SWEEP_ATTACK, var8.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 10, (double)0.5F, (double)0.5F, (double)0.5F);
                        var8.getWorld().playSound(var8.getLocation(), Sound.ENTITY_PLAYER_ATTACK_CRIT, 1.0F, 0.7F);
                        var2.sendMessage("§c§l⚔ CHAD STRENGTH! §c+3.5 hearts bonus damage!");
                     }

                  }
               }
            }
         }
      }
   }

   @EventHandler
   public void onRichRushBlockBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      if (h.a(var2.getUniqueId())) {
         if (!var1.isCancelled()) {
            Material var3 = var1.getBlock().getType();
            if (this.isOreBlock(var3)) {
               for(ItemStack var6 : new ArrayList(var1.getBlock().getDrops(var2.getInventory().getItemInMainHand(), var2))) {
                  var1.getBlock().getWorld().dropItemNaturally(var1.getBlock().getLocation(), var6.clone());
               }

            }
         }
      }
   }

   private boolean isOreBlock(Material var1) {
      return var1 == Material.COAL_ORE || var1 == Material.DEEPSLATE_COAL_ORE || var1 == Material.IRON_ORE || var1 == Material.DEEPSLATE_IRON_ORE || var1 == Material.GOLD_ORE || var1 == Material.DEEPSLATE_GOLD_ORE || var1 == Material.NETHER_GOLD_ORE || var1 == Material.COPPER_ORE || var1 == Material.DEEPSLATE_COPPER_ORE || var1 == Material.DIAMOND_ORE || var1 == Material.DEEPSLATE_DIAMOND_ORE || var1 == Material.EMERALD_ORE || var1 == Material.DEEPSLATE_EMERALD_ORE || var1 == Material.LAPIS_ORE || var1 == Material.DEEPSLATE_LAPIS_ORE || var1 == Material.REDSTONE_ORE || var1 == Material.DEEPSLATE_REDSTONE_ORE || var1 == Material.NETHER_QUARTZ_ORE || var1 == Material.ANCIENT_DEBRIS;
   }

   @EventHandler
   public void onRichRushEntityDeath(EntityDeathEvent var1) {
      Player var2 = var1.getEntity().getKiller();
      if (var2 != null) {
         if (h.a(var2.getUniqueId())) {
            EntityType var3 = var1.getEntity().getType();
            if (var3 != EntityType.DONKEY && var3 != EntityType.MULE && var3 != EntityType.LLAMA && var3 != EntityType.TRADER_LLAMA) {
               for(ItemStack var6 : new ArrayList(var1.getDrops())) {
                  if (this.isNaturalMobDrop(var6)) {
                     var1.getDrops().add(var6.clone());
                  }
               }

            }
         }
      }
   }

   private boolean isNaturalMobDrop(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir()) {
         Material var2 = var1.getType();
         if (!var2.name().contains("HELMET") && !var2.name().contains("CHESTPLATE") && !var2.name().contains("LEGGINGS") && !var2.name().contains("BOOTS") && !var2.name().contains("SWORD") && !var2.name().contains("AXE") && !var2.name().contains("PICKAXE") && !var2.name().contains("SHOVEL") && !var2.name().contains("HOE") && !var2.name().contains("BOW") && !var2.name().contains("CROSSBOW") && !var2.name().contains("TRIDENT") && !var2.name().contains("SHIELD")) {
            if (!var2.name().contains("SHULKER") && !var2.name().contains("CHEST") && !var2.name().contains("BARREL") && !var2.name().contains("BUNDLE") && var2 != Material.SADDLE && !var2.name().contains("HORSE_ARMOR")) {
               if (var1.hasItemMeta()) {
                  ItemMeta var3 = var1.getItemMeta();
                  if (var3.hasDisplayName() || var3.hasLore()) {
                     return false;
                  }
               }

               if (var2 != Material.ROTTEN_FLESH && var2 != Material.BONE && var2 != Material.SPIDER_EYE && var2 != Material.STRING && var2 != Material.GUNPOWDER && var2 != Material.ENDER_PEARL && var2 != Material.BLAZE_ROD && var2 != Material.GHAST_TEAR && var2 != Material.MAGMA_CREAM && var2 != Material.SLIME_BALL && var2 != Material.PRISMARINE_SHARD && var2 != Material.PRISMARINE_CRYSTALS && var2 != Material.RABBIT_HIDE && var2 != Material.RABBIT_FOOT && var2 != Material.PHANTOM_MEMBRANE && var2 != Material.NAUTILUS_SHELL) {
                  if (var2 != Material.BEEF && var2 != Material.PORKCHOP && var2 != Material.MUTTON && var2 != Material.CHICKEN && var2 != Material.RABBIT && var2 != Material.COD && var2 != Material.SALMON && var2 != Material.TROPICAL_FISH && var2 != Material.PUFFERFISH) {
                     if (var2 != Material.COOKED_BEEF && var2 != Material.COOKED_PORKCHOP && var2 != Material.COOKED_MUTTON && var2 != Material.COOKED_CHICKEN && var2 != Material.COOKED_RABBIT && var2 != Material.COOKED_COD && var2 != Material.COOKED_SALMON) {
                        if (var2 != Material.LEATHER && var2 != Material.FEATHER && var2 != Material.INK_SAC && var2 != Material.GLOW_INK_SAC) {
                           if (var2 != Material.NETHER_STAR && var2 != Material.WITHER_SKELETON_SKULL && var2 != Material.SKELETON_SKULL && var2 != Material.ZOMBIE_HEAD && var2 != Material.CREEPER_HEAD && var2 != Material.DRAGON_HEAD) {
                              if (var2 != Material.TOTEM_OF_UNDYING && var2 != Material.ELYTRA && var2 != Material.DRAGON_BREATH) {
                                 if (var2 != Material.ARROW && var2 != Material.EGG && var2 != Material.SNOWBALL) {
                                    if (var2 != Material.ECHO_SHARD && var2 != Material.SCULK_CATALYST) {
                                       if (var2 == Material.SNIFFER_EGG) {
                                          return true;
                                       } else if (var2 != Material.OCHRE_FROGLIGHT && var2 != Material.PEARLESCENT_FROGLIGHT && var2 != Material.VERDANT_FROGLIGHT) {
                                          return false;
                                       } else {
                                          return true;
                                       }
                                    } else {
                                       return true;
                                    }
                                 } else {
                                    return true;
                                 }
                              } else {
                                 return true;
                              }
                           } else {
                              return true;
                           }
                        } else {
                           return true;
                        }
                     } else {
                        return true;
                     }
                  } else {
                     return true;
                  }
               } else {
                  return true;
               }
            } else {
               return false;
            }
         } else {
            return false;
         }
      } else {
         return false;
      }
   }

   @EventHandler
   public void onFluxFlowBlockBreak(BlockBreakEvent var1) {
      Player var2 = var1.getPlayer();
      if ((this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FLUX) || this.isHoldingFluxGem(var2))) {
         if (this.canUsePassives(var2)) {
            this.plugin.getFlowStateManager().registerAction(var2, FlowStateManager.ActionType.BLOCK_BREAK);
         }
      }
   }

   @EventHandler
   public void onFluxFlowAttack(EntityDamageByEntityEvent var1) {
      if (var1.getDamager() instanceof Player) {
         Player var2 = (Player)var1.getDamager();
         if ((this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FLUX) || this.isHoldingFluxGem(var2))) {
            if (this.canUsePassives(var2)) {
               this.plugin.getFlowStateManager().registerAction(var2, FlowStateManager.ActionType.ATTACK);
            }
         }
      }
   }

   @EventHandler
   public void onFluxFlowArrowShoot(ProjectileLaunchEvent var1) {
      Projectile var2 = var1.getEntity();
      if (var2 instanceof Arrow) {
         ProjectileSource var3 = var2.getShooter();
         if (var3 instanceof Player) {
            Player var4 = (Player)var3;
            if ((this.plugin.getGemManager().hasGemTypeInOffhand(var4, GemType.FLUX) || this.isHoldingFluxGem(var4))) {
               if (this.canUsePassives(var4)) {
                  this.plugin.getFlowStateManager().registerAction(var4, FlowStateManager.ActionType.ARROW_SHOOT);
               }
            }
         }
      }
   }

   @EventHandler
   public void onFluxFlowSprint(PlayerToggleSprintEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.isSprinting()) {
         if ((this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FLUX) || this.isHoldingFluxGem(var2))) {
            if (this.canUsePassives(var2)) {
               this.plugin.getFlowStateManager().registerAction(var2, FlowStateManager.ActionType.SPRINT);
            }
         }
      }
   }

   @EventHandler
   public void onFluxFlowJump(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      if (!(var1.getTo().getY() <= var1.getFrom().getY())) {
         if (var2.isOnGround()) {
            if ((this.plugin.getGemManager().hasGemTypeInOffhand(var2, GemType.FLUX) || this.isHoldingFluxGem(var2))) {
               if (this.canUsePassives(var2)) {
                  this.plugin.getFlowStateManager().registerAction(var2, FlowStateManager.ActionType.JUMP);
               }
            }
         }
      }
   }

   private boolean canUsePassives(Player var1) {
      if (!this.plugin.getEnergyManager().arePassivesActive(var1)) {
         return false;
      } else {
         return this.plugin.getRegionManager() == null || !this.plugin.getRegionManager().a(var1);
      }
   }
}
