package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.EnergyState;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Logger;
import org.bukkit.Location;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerDeathListener implements Listener {
   private final BlissGems plugin;
   private final Map<UUID, List<ItemStack>> savedGems = new HashMap();

   public PlayerDeathListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDeath(PlayerDeathEvent var1) {
      Player var2 = var1.getEntity();
      Player var3 = var2.getKiller();
      EnergyState var4 = this.plugin.getEnergyManager().getEnergyState(var2);
      boolean var5 = var4 != EnergyState.BROKEN;
      int var6 = this.plugin.getConfigManager().getEnergyLossOnDeath();
      this.plugin.getEnergyManager().removeEnergy(var2, var6);
      int var7 = this.plugin.getEnergyManager().getEnergy(var2);
      if (var7 <= 0 && this.plugin.getConfigManager().isBanOnZeroEnergyEnabled()) {
         String var8 = this.plugin.getConfigManager().getFormattedMessage("energy-zero-banned");
         if (var8 == null || var8.isEmpty()) {
            var8 = "You have been banned for reaching 0 energy!";
         }

         var2.ban(var8, (Date)null, (String)null);
      }

      if (var3 != null && var5) {
         int var10 = this.plugin.getConfigManager().getEnergyGainOnKill();
         this.plugin.getEnergyManager().addEnergy(var3, var10);
         EnergyState var9 = this.plugin.getEnergyManager().getEnergyState(var3);
         if (var9.isMaxEnergy() && this.plugin.getConfigManager().isEnergyBottleDropEnabled()) {
            this.dropEnergyBottle(var2.getLocation());
         }
      }

      if (this.plugin.getConfig().getBoolean("gems.prevent-drop", true)) {
         List var11 = var1.getDrops();
         ArrayList var12 = new ArrayList();
         var11.removeIf((var1x) -> {
            String itemId = CustomItemManager.getIdByItem(var1x);
            boolean isGem = itemId != null && this.plugin.getGemManager().isAnyGem(itemId);
            if (CustomItemManager.isUndroppable(var1x) || isGem) {
               var12.add(var1x.clone());
               return true;
            } else {
               return false;
            }
         });
         // Some command-given/custom gems may be missing from the event drop list.
         // Fall back to the player's inventory snapshot when no gem was captured.
         if (var12.isEmpty() && !var1.getKeepInventory()) {
            for (ItemStack inventoryItem : var2.getInventory().getContents()) {
               if (inventoryItem == null || inventoryItem.getType().isAir()) {
                  continue;
               }
               String inventoryId = CustomItemManager.getIdByItem(inventoryItem);
               if (inventoryId != null && this.plugin.getGemManager().isAnyGem(inventoryId)) {
                  var12.add(inventoryItem.clone());
               }
            }
         }
         if (!var12.isEmpty()) {
            this.savedGems.put(var2.getUniqueId(), var12);
            this.saveGemsToDisk(var2.getUniqueId(), var12);
         }
      }

      this.plugin.getAstraAbilities().cleanup(var2);
      this.plugin.getFireAbilities().cleanup(var2);
      this.plugin.getFluxAbilities().cleanup(var2);
      this.plugin.getLifeAbilities().cleanup(var2);
      if (this.plugin.getSoulManager() != null) {
         this.plugin.getSoulManager().cleanup(var2);
      }

      this.plugin.getGemManager().updateActiveGem(var2);
      if (var3 != null) {
         this.plugin.getGemManager().updateActiveGem(var3);
      }

   }

   @EventHandler
   public void onPlayerRespawn(PlayerRespawnEvent var1) {
      Player var2 = var1.getPlayer();
      UUID var3 = var2.getUniqueId();
      List var4 = null;
      if (this.savedGems.containsKey(var3)) {
         var4 = (List)this.savedGems.remove(var3);
         this.clearGemsFromDisk(var3);
      } else {
         var4 = this.loadGemsFromDisk(var3);
      }

      if (var4 != null && !var4.isEmpty()) {
         boolean var5 = this.plugin.getConfig().getBoolean("gems.single-gem-only", true);
         if (var5 && var4.size() > 1) {
            Logger var10000 = this.plugin.getLogger();
            String var10001 = var2.getName();
            var10000.warning("Player " + var10001 + " had " + var4.size() + " gems saved! Only returning first gem due to single-gem-only config.");
            var2.getInventory().addItem(new ItemStack[]{(ItemStack)var4.get(0)});
         } else {
            for(ItemStack var7 : var4) {
               var2.getInventory().addItem(new ItemStack[]{var7});
            }
         }
      }

      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (var2.isOnline()) {
            this.enforceOneGemOnly(var2);
            this.plugin.getGemManager().updateActiveGem(var2);
         }

      }, 1L);
   }

   private void dropEnergyBottle(Location var1) {
      ItemStack var2 = CustomItemManager.getItemById("energy_bottle");
      if (var2 != null) {
         var1.getWorld().dropItemNaturally(var1, var2);
      }

   }

   private void saveGemsToDisk(UUID var1, List<ItemStack> var2) {
      File var3 = new File(this.plugin.getDataFolder(), "playerdata");
      if (!var3.exists()) {
         var3.mkdirs();
      }

      File var4 = new File(var3, String.valueOf(var1) + ".yml");
      YamlConfiguration var5;
      if (var4.exists()) {
         var5 = YamlConfiguration.loadConfiguration(var4);
      } else {
         var5 = new YamlConfiguration();
      }

      ((FileConfiguration)var5).set("saved-gems", var2);

      try {
         ((FileConfiguration)var5).save(var4);
      } catch (IOException var7) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = String.valueOf(var1);
         var10000.severe("Failed to save gems for player " + var10001 + ": " + var7.getMessage());
      }

   }

   private List<ItemStack> loadGemsFromDisk(UUID var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1) + ".yml");
      if (!var3.exists()) {
         return null;
      } else {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         List var5 = (List)((FileConfiguration)var4).get("saved-gems");
         if (var5 != null) {
            ((FileConfiguration)var4).set("saved-gems", (Object)null);

            try {
               ((FileConfiguration)var4).save(var3);
            } catch (IOException var7) {
               this.plugin.getLogger().warning("Failed to clear saved gems from disk for " + String.valueOf(var1));
            }
         }

         return var5;
      }
   }

   private void clearGemsFromDisk(UUID var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1) + ".yml");
      if (var3.exists()) {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         if (((FileConfiguration)var4).contains("saved-gems")) {
            ((FileConfiguration)var4).set("saved-gems", (Object)null);

            try {
               ((FileConfiguration)var4).save(var3);
            } catch (IOException var6) {
               this.plugin.getLogger().warning("Failed to clear saved gems from disk for " + String.valueOf(var1));
            }
         }

      }
   }

   private void enforceOneGemOnly(Player var1) {
      boolean var2 = false;

      for(int var3 = 0; var3 < var1.getInventory().getSize(); ++var3) {
         ItemStack var4 = var1.getInventory().getItem(var3);
         if (var4 != null) {
            String var5 = CustomItemManager.getIdByItem(var4);
            if (var5 != null && this.plugin.getGemManager().isAnyGem(var5)) {
               if (!var2) {
                  var2 = true;
               } else {
                  var1.getInventory().setItem(var3, (ItemStack)null);
                  this.plugin.getLogger().info("Removed duplicate gem from " + var1.getName() + " on respawn.");
               }
            }
         }
      }

   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent var1) {
      this.plugin.getGemManager().updateActiveGem(var1.getPlayer());
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent var1) {
      Player var2 = var1.getPlayer();
      this.plugin.getAstraAbilities().cleanup(var2);
      this.plugin.getFireAbilities().cleanup(var2);
      this.plugin.getFluxAbilities().cleanup(var2);
      this.plugin.getSpeedAbilities().d(var2.getUniqueId());
      this.plugin.getWealthAbilities().cleanup(var2);
      this.plugin.getLifeAbilities().cleanup(var2);
      this.plugin.getSoulManager().cleanup(var2);
      this.plugin.getSoulManager().clearSouls(var2.getUniqueId());
      this.plugin.getEnergyManager().clearCache(var2.getUniqueId());
      this.plugin.getGemManager().clearCache(var2.getUniqueId());
      this.plugin.getAbilityManager().clearCache(var2.getUniqueId());
   }
}
