package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.managers.GemRegistryImpl;
import dev.xoperr.blissgems.utils.AbilityBinding;
import dev.xoperr.blissgems.utils.AbilitySlot;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;

public class SwapHandAbilityListener implements Listener {
   private final BlissGems plugin;

   public SwapHandAbilityListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onSwap(PlayerSwapHandItemsEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getMainHandItem();
      ItemStack var4 = var1.getOffHandItem();
      boolean var5 = this.isGem(var3);
      boolean var6 = this.isGem(var4);
      if (var5 || var6) {
         var1.setCancelled(true);
         if (this.plugin.getBlissCommand() != null) {
            if (this.plugin.getClickActivationManager().isClickActivationEnabled(var2)) {
               AbilityBinding var7 = AbilityBinding.swapHand(var2.isSneaking());
               AbilitySlot var8 = this.plugin.getAbilityBindingManager() != null ? this.plugin.getAbilityBindingManager().getSlot(var2, var7) : null;
               this.plugin.getBlissCommand().triggerSlot(var2, var8);
            }
         }
      }
   }

   private boolean isGem(ItemStack var1) {
      if (var1 == null) {
         return false;
      } else {
         String var2 = CustomItemManager.getIdByItem(var1);
         if (var2 == null) {
            return false;
         } else if (GemType.isGem(var2)) {
            return true;
         } else {
            GemRegistryImpl var3 = this.plugin.getGemRegistry();
            return var3 != null && var3.isRegisteredGem(var2);
         }
      }
   }
}
