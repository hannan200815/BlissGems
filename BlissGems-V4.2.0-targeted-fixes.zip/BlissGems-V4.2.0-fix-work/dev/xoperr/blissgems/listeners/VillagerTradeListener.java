package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.GemType;
import org.bukkit.Location;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.VillagerAcquireTradeEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.MerchantRecipe;

public class VillagerTradeListener implements Listener {
   private final BlissGems plugin;

   public VillagerTradeListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onVillagerAcquireTrade(VillagerAcquireTradeEvent var1) {
      if (var1.getEntity().getRecipeCount() > 0) {
         Player var2 = this.findNearbyPlayerWithWealth(var1.getEntity().getLocation());
         if (var2 != null) {
            if (this.plugin.getGemManager().hasGemType(var2, GemType.WEALTH)) {
               int var3 = this.plugin.getGemManager().getGemTier(var2);
               double var4 = this.plugin.getConfigManager().getVillagerDiscount(var3);
               MerchantRecipe var6 = var1.getRecipe();
               MerchantRecipe var7 = this.applyDiscount(var6, var4);
               var1.setRecipe(var7);
            }
         }
      }
   }

   private Player findNearbyPlayerWithWealth(Location var1) {
      for(Player var3 : var1.getWorld().getPlayers()) {
         if (var3.getLocation().distance(var1) <= (double)10.0F && this.plugin.getGemManager().hasGemType(var3, GemType.WEALTH)) {
            return var3;
         }
      }

      return null;
   }

   private MerchantRecipe applyDiscount(MerchantRecipe var1, double var2) {
      MerchantRecipe var4 = new MerchantRecipe(var1.getResult(), var1.getUses(), var1.getMaxUses(), var1.hasExperienceReward(), var1.getVillagerExperience(), var1.getPriceMultiplier());

      for(ItemStack var6 : var1.getIngredients()) {
         if (var6 != null) {
            ItemStack var7 = var6.clone();
            int var8 = var6.getAmount();
            int var9 = Math.max(1, (int)((double)var8 * ((double)1.0F - var2)));
            var7.setAmount(var9);
            var4.addIngredient(var7);
         }
      }

      return var4;
   }
}
