package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Logger;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.inventory.ItemStack;

public class PlayerJoinListener implements Listener {
   private final BlissGems plugin;
   private final Random random;

   public PlayerJoinListener(BlissGems var1) {
      this.plugin = var1;
      this.random = new Random();
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent var1) {
      Player var2 = var1.getPlayer();
      if (!this.hasReceivedFirstGem(var2) && this.plugin.getGemManager().findGemInInventory(var2) == null) {
         if (!this.plugin.getConfigManager().isSmpStarted()) {
            this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
               if (var2.isOnline()) {
                  this.plugin.getConfigManager().sendFormattedMessage(var2, "smp-not-started");
               }

            }, 40L);
         } else {
            GemType var3 = this.getRandomEnabledGem();
            if (var3 != null) {
               this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                  if (var2.isOnline()) {
                     var2.sendMessage("");
                     var2.sendMessage("§d§l§m                                                  ");
                     var2.sendMessage("§d§lWELCOME TO BLISSGEMS!");
                     var2.sendMessage("");
                     var2.sendMessage("§7§oThe ancient gem ritual begins...");
                     var2.sendMessage("§7§oYour destiny is being forged...");
                     var2.sendMessage("§d§l§m                                                  ");
                     var2.sendMessage("");
                     this.plugin.getGemRitualManager().performGemRitual(var2, var3, true, 1);
                     this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
                        if (this.plugin.getGemManager().giveGem(var2, (GemType)var3, 1)) {
                           this.markFirstGemReceived(var2);
                           String var3x = this.plugin.getConfigManager().getFormattedMessage("first-gem-received", "gem", var3.getDisplayName());
                           if (var3x != null && !var3x.isEmpty()) {
                              var2.sendMessage(var3x);
                           } else {
                              var2.sendMessage("");
                              String var10001 = var3.getColor();
                              var2.sendMessage("§d§l» §fYour gem has been chosen: " + var10001 + "§l" + var3.getDisplayName() + "§d§l «");
                              var2.sendMessage("");
                           }

                           Logger var10000 = this.plugin.getLogger();
                           String var4 = var2.getName();
                           var10000.info("Gave " + var4 + " their first gem: " + var3.getDisplayName());
                        }

                     }, 20L);
                  }

               }, 40L);
            }
         }
      }

      if (!this.hasBeenGemLockChecked(var2)) {
         boolean var7 = false;

         for(int var4 = 0; var4 < var2.getInventory().getSize(); ++var4) {
            ItemStack var5 = var2.getInventory().getItem(var4);
            if (var5 != null) {
               String var6 = CustomItemManager.getIdByItem(var5);
               if (var6 != null && GemType.isGem(var6) && CustomItemManager.markAsUndroppable(var5)) {
                  var7 = true;
               }
            }
         }

         ItemStack var8 = var2.getInventory().getItemInOffHand();
         if (var8 != null) {
            String var9 = CustomItemManager.getIdByItem(var8);
            if (var9 != null && GemType.isGem(var9) && CustomItemManager.markAsUndroppable(var8)) {
               var7 = true;
            }
         }

         this.markGemLockChecked(var2);
         if (var7) {
            this.plugin.getLogger().info("Fixed undroppable tags on gems for " + var2.getName());
         }
      }

      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (var2.isOnline()) {
            if (this.plugin.getLifeAbilities() != null) {
               this.plugin.getLifeAbilities().cleanup(var2);
            }

            if (this.plugin.getSoulManager() != null) {
               this.plugin.getSoulManager().cleanup(var2);
            }

         }
      }, 20L);
      this.plugin.getGemManager().updateActiveGem(var2);
      this.plugin.getAbilityManager().loadCooldowns(var2.getUniqueId());
      this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
         if (var2.isOnline()) {
            this.plugin.getPluginMessagingManager().sendGemData(var2);
         }

      }, 20L);
      if (!this.hasSeenBindingTip(var2)) {
         this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            if (var2.isOnline()) {
               var2.sendMessage("");
               var2.sendMessage("§d§l⚡ Tip: §fYou can customize how your gem abilities are triggered!");
               var2.sendMessage("§7Run §f/bliss ability §7to see your current bindings.");
               var2.sendMessage("§7Change them with §f/bliss set_ability <slot> <input> §7(e.g. §f/bliss set_ability primary left_click§7).");
               var2.sendMessage("");
               this.markBindingTipSeen(var2);
            }
         }, 100L);
      }

   }

   private boolean hasSeenBindingTip(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      if (!var3.exists()) {
         return false;
      } else {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         return ((FileConfiguration)var4).getBoolean("seen-binding-tip", false);
      }
   }

   private void markBindingTipSeen(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      YamlConfiguration var4 = var3.exists() ? YamlConfiguration.loadConfiguration(var3) : new YamlConfiguration();
      ((FileConfiguration)var4).set("seen-binding-tip", true);

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to mark binding tip seen for " + var10001 + ": " + var6.getMessage());
      }

   }

   private boolean hasReceivedFirstGem(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      if (!var3.exists()) {
         return false;
      } else {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         return ((FileConfiguration)var4).getBoolean("received-first-gem", false);
      }
   }

   private void markFirstGemReceived(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      YamlConfiguration var4;
      if (var3.exists()) {
         var4 = YamlConfiguration.loadConfiguration(var3);
      } else {
         var4 = new YamlConfiguration();
      }

      ((FileConfiguration)var4).set("received-first-gem", true);
      if (!((FileConfiguration)var4).contains("energy")) {
         ((FileConfiguration)var4).set("energy", this.plugin.getConfigManager().getStartingEnergy());
      }

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save first gem status for " + var10001 + ": " + var6.getMessage());
      }

   }

   private boolean hasBeenGemLockChecked(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      if (!var3.exists()) {
         return false;
      } else {
         YamlConfiguration var4 = YamlConfiguration.loadConfiguration(var3);
         return ((FileConfiguration)var4).getBoolean("gems-lock-checked", false);
      }
   }

   private void markGemLockChecked(Player var1) {
      File var2 = new File(this.plugin.getDataFolder(), "playerdata");
      if (!var2.exists()) {
         var2.mkdirs();
      }

      File var3 = new File(var2, String.valueOf(var1.getUniqueId()) + ".yml");
      YamlConfiguration var4;
      if (var3.exists()) {
         var4 = YamlConfiguration.loadConfiguration(var3);
      } else {
         var4 = new YamlConfiguration();
      }

      ((FileConfiguration)var4).set("gems-lock-checked", true);

      try {
         ((FileConfiguration)var4).save(var3);
      } catch (IOException var6) {
         Logger var10000 = this.plugin.getLogger();
         String var10001 = var1.getName();
         var10000.warning("Failed to save gem-lock-checked for " + var10001 + ": " + var6.getMessage());
      }

   }

   private GemType getRandomEnabledGem() {
      ArrayList var1 = new ArrayList();

      for(GemType var5 : GemType.values()) {
         if (this.plugin.getConfigManager().isGemEnabled(var5)) {
            var1.add(var5);
         }
      }

      if (var1.isEmpty()) {
         return null;
      } else {
         return (GemType)var1.get(this.random.nextInt(var1.size()));
      }
   }
}
