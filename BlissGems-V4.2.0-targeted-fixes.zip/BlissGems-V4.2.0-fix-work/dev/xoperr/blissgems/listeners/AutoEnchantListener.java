package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.a.h;
import dev.xoperr.blissgems.managers.GemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerItemHeldEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerSwapHandItemsEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.scheduler.BukkitRunnable;

public class AutoEnchantListener implements Listener {
   private final BlissGems plugin;
   private static final String PDC_PREFIX = "ae_orig_";

   public AutoEnchantListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerItemHeld(final PlayerItemHeldEvent var1) {
      final Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItem(var1.getPreviousSlot());
      if (var3 != null && !var3.getType().isAir()) {
         this.stripAutoEnchants(var3);
      }

      (new BukkitRunnable() {
         public void run() {
            if (var2.isOnline()) {
               AutoEnchantListener.this.applyAutoEnchants(var2, var1.getNewSlot());
            }
         }
      }).runTaskLater(this.plugin, 1L);
   }

   @EventHandler
   public void onPlayerJoin(PlayerJoinEvent var1) {
      final Player var2 = var1.getPlayer();
      (new BukkitRunnable() {
         public void run() {
            if (var2.isOnline()) {
               AutoEnchantListener.this.stripAllAutoEnchants(var2);
               int var1 = var2.getInventory().getHeldItemSlot();
               AutoEnchantListener.this.applyAutoEnchants(var2, var1);
            }
         }
      }).runTaskLater(this.plugin, 5L);
   }

   @EventHandler
   public void onPlayerQuit(PlayerQuitEvent var1) {
      this.stripAllAutoEnchants(var1.getPlayer());
      this.stripAllAmplifyEnchants(var1.getPlayer());
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         this.scheduleRefresh((Player)var1.getWhoClicked());
      }
   }

   @EventHandler
   public void onInventoryDrag(InventoryDragEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         this.scheduleRefresh((Player)var1.getWhoClicked());
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerDropItem(PlayerDropItemEvent var1) {
      if (!var1.isCancelled()) {
         ItemStack var2 = var1.getItemDrop().getItemStack();
         boolean var3 = this.stripAutoEnchants(var2);
         var3 |= h.a(var2);
         if (var3) {
            var1.getItemDrop().setItemStack(var2);
         }

         this.scheduleRefresh(var1.getPlayer());
      }
   }

   @EventHandler
   public void onPlayerSwapHand(PlayerSwapHandItemsEvent var1) {
      this.scheduleRefresh(var1.getPlayer());
   }

   private void scheduleRefresh(final Player var1) {
      (new BukkitRunnable() {
         public void run() {
            if (var1.isOnline()) {
               AutoEnchantListener.this.refreshAutoEnchants(var1);
            }
         }
      }).runTaskLater(this.plugin, 1L);
   }

   private void refreshAutoEnchants(Player var1) {
      int var2 = var1.getInventory().getHeldItemSlot();

      for(int var3 = 0; var3 < var1.getInventory().getSize(); ++var3) {
         if (var3 != var2) {
            ItemStack var4 = var1.getInventory().getItem(var3);
            if (var4 != null && !var4.getType().isAir()) {
               this.stripAutoEnchants(var4);
            }
         }
      }

      ItemStack var5 = var1.getInventory().getItemInOffHand();
      if (!var5.getType().isAir()) {
         this.stripAutoEnchants(var5);
      }

      this.applyAutoEnchants(var1, var2);
   }

   public void applyAutoEnchants(Player var1, int var2) {
      if (this.plugin.getConfig().getBoolean("auto-enchant.enabled", true)) {
         GemManager.ActiveGem var3 = this.plugin.getGemManager().getActiveGem(var1);
         if (var3 != null) {
            if (var3.getTier() >= 2 || var3.getType() == GemType.STRENGTH) {
               if (this.plugin.getEnergyManager().arePassivesActive(var1)) {
                  ItemStack var4 = var1.getInventory().getItem(var2);
                  if (var4 != null && var4.getType() != Material.AIR) {
                     GemType var5 = var3.getType();
                     int var6 = var3.getTier();
                     Map var7 = this.getEnchantsForGem(var5, var4, var6);
                     if (!var7.isEmpty()) {
                        ItemMeta var8 = var4.getItemMeta();
                        if (var8 != null) {
                           PersistentDataContainer var9 = var8.getPersistentDataContainer();
                           boolean var10 = false;

                           for(Map.Entry var12 : var7.entrySet()) {
                              Enchantment var13 = (Enchantment)var12.getKey();
                              int var14 = (Integer)var12.getValue();
                              int var15 = var8.getEnchantLevel(var13);
                              NamespacedKey var16 = new NamespacedKey(this.plugin, "ae_orig_" + var13.getKey().getKey());
                              if (!var9.has(var16, PersistentDataType.INTEGER) && var15 < var14) {
                                 var9.set(var16, PersistentDataType.INTEGER, var15);
                                 var8.addEnchant(var13, var14, true);
                                 var10 = true;
                              }
                           }

                           if (var10) {
                              var4.setItemMeta(var8);
                           }

                        }
                     }
                  }
               }
            }
         }
      }
   }

   public boolean stripAutoEnchants(ItemStack var1) {
      if (var1 != null && !var1.getType().isAir() && var1.hasItemMeta()) {
         ItemMeta var2 = var1.getItemMeta();
         if (var2 == null) {
            return false;
         } else {
            PersistentDataContainer var3 = var2.getPersistentDataContainer();
            boolean var4 = false;

            for(Enchantment var8 : Enchantment.values()) {
               NamespacedKey var9 = new NamespacedKey(this.plugin, "ae_orig_" + var8.getKey().getKey());
               if (var3.has(var9, PersistentDataType.INTEGER)) {
                  int var10 = (Integer)var3.get(var9, PersistentDataType.INTEGER);
                  if (var10 == 0) {
                     var2.removeEnchant(var8);
                  } else {
                     var2.addEnchant(var8, var10, true);
                  }

                  var3.remove(var9);
                  var4 = true;
               }
            }

            if (var4) {
               var1.setItemMeta(var2);
            }

            return var4;
         }
      } else {
         return false;
      }
   }

   public void stripAllAutoEnchants(Player var1) {
      for(int var2 = 0; var2 < var1.getInventory().getSize(); ++var2) {
         ItemStack var3 = var1.getInventory().getItem(var2);
         if (var3 != null && !var3.getType().isAir()) {
            this.stripAutoEnchants(var3);
         }
      }

      ItemStack var4 = var1.getInventory().getItemInOffHand();
      if (!var4.getType().isAir()) {
         this.stripAutoEnchants(var4);
      }

   }

   private void stripAllAmplifyEnchants(Player var1) {
      for(int var2 = 0; var2 < var1.getInventory().getSize(); ++var2) {
         ItemStack var3 = var1.getInventory().getItem(var2);
         if (var3 != null && !var3.getType().isAir()) {
            h.a(var3);
         }
      }

      ItemStack[] var5 = var1.getInventory().getArmorContents();
      boolean var6 = false;

      for(int var4 = 0; var4 < var5.length; ++var4) {
         if (var5[var4] != null && !var5[var4].getType().isAir() && h.a(var5[var4])) {
            var6 = true;
         }
      }

      if (var6) {
         var1.getInventory().setArmorContents(var5);
      }

      ItemStack var7 = var1.getInventory().getItemInOffHand();
      if (!var7.getType().isAir()) {
         h.a(var7);
      }

   }

   public boolean hasAutoEnchants(ItemStack var1) {
      if (var1 != null && var1.hasItemMeta()) {
         PersistentDataContainer var2 = var1.getItemMeta().getPersistentDataContainer();

         for(Enchantment var6 : Enchantment.values()) {
            NamespacedKey var7 = new NamespacedKey(this.plugin, "ae_orig_" + var6.getKey().getKey());
            if (var2.has(var7, PersistentDataType.INTEGER)) {
               return true;
            }
         }

         return false;
      } else {
         return false;
      }
   }

   private Map<Enchantment, Integer> getEnchantsForGem(GemType var1, ItemStack var2, int var3) {
      HashMap var4 = new HashMap();
      Material var5 = var2.getType();
      switch (var1) {
         case SPEED:
            if (this.plugin.getConfig().getBoolean("auto-enchant.speed.efficiency", true) && this.isTool(var5)) {
               var4.put(Enchantment.EFFICIENCY, 5);
            }
            break;
         case WEALTH:
            if (this.plugin.getConfig().getBoolean("auto-enchant.wealth.fortune", true) && (this.isPickaxe(var5) || this.isShovel(var5) || this.isAxe(var5))) {
               var4.put(Enchantment.FORTUNE, 3);
            }

            if (this.plugin.getConfig().getBoolean("auto-enchant.wealth.looting", true) && this.isSword(var5)) {
               var4.put(Enchantment.LOOTING, 3);
            }

            if (this.plugin.getConfig().getBoolean("auto-enchant.wealth.mending", true) && (this.isTool(var5) || this.isWeapon(var5) || this.isArmor(var5))) {
               var4.put(Enchantment.MENDING, 1);
            }
            break;
         case FIRE:
            if (this.plugin.getConfig().getBoolean("auto-enchant.fire.flame", true) && var5 == Material.BOW) {
               var4.put(Enchantment.FLAME, 1);
            }

            if (this.plugin.getConfig().getBoolean("auto-enchant.fire.fire-aspect", true) && this.isSword(var5)) {
               var4.put(Enchantment.FIRE_ASPECT, 2);
            }
            break;
         case PUFF:
            if (this.plugin.getConfig().getBoolean("auto-enchant.puff.feather-falling", true) && this.isBoots(var5)) {
               var4.put(Enchantment.FEATHER_FALLING, 4);
            }

            if (this.plugin.getConfig().getBoolean("auto-enchant.puff.power", true) && var5 == Material.BOW) {
               var4.put(Enchantment.POWER, 5);
            }

            if (this.plugin.getConfig().getBoolean("auto-enchant.puff.punch", true) && var5 == Material.BOW) {
               var4.put(Enchantment.PUNCH, 2);
            }
            break;
         case STRENGTH:
            if (this.plugin.getConfig().getBoolean("auto-enchant.strength.sharpness", true) && (this.isSword(var5) || this.isAxe(var5))) {
               int var6 = var3 >= 2 ? 5 : 2;
               var4.put(Enchantment.SHARPNESS, var6);
            }
            break;
         case LIFE:
            if (this.plugin.getConfig().getBoolean("auto-enchant.life.unbreaking", true) && (this.isTool(var5) || this.isWeapon(var5) || this.isArmor(var5))) {
               var4.put(Enchantment.UNBREAKING, 3);
            }
      }

      return var4;
   }

   private boolean isTool(Material var1) {
      return this.isPickaxe(var1) || this.isShovel(var1) || this.isAxe(var1) || this.isHoe(var1);
   }

   private boolean isPickaxe(Material var1) {
      return var1 == Material.WOODEN_PICKAXE || var1 == Material.STONE_PICKAXE || var1 == Material.IRON_PICKAXE || var1 == Material.GOLDEN_PICKAXE || var1 == Material.DIAMOND_PICKAXE || var1 == Material.NETHERITE_PICKAXE;
   }

   private boolean isShovel(Material var1) {
      return var1 == Material.WOODEN_SHOVEL || var1 == Material.STONE_SHOVEL || var1 == Material.IRON_SHOVEL || var1 == Material.GOLDEN_SHOVEL || var1 == Material.DIAMOND_SHOVEL || var1 == Material.NETHERITE_SHOVEL;
   }

   private boolean isAxe(Material var1) {
      return var1 == Material.WOODEN_AXE || var1 == Material.STONE_AXE || var1 == Material.IRON_AXE || var1 == Material.GOLDEN_AXE || var1 == Material.DIAMOND_AXE || var1 == Material.NETHERITE_AXE;
   }

   private boolean isHoe(Material var1) {
      return var1 == Material.WOODEN_HOE || var1 == Material.STONE_HOE || var1 == Material.IRON_HOE || var1 == Material.GOLDEN_HOE || var1 == Material.DIAMOND_HOE || var1 == Material.NETHERITE_HOE;
   }

   private boolean isSword(Material var1) {
      return var1 == Material.WOODEN_SWORD || var1 == Material.STONE_SWORD || var1 == Material.IRON_SWORD || var1 == Material.GOLDEN_SWORD || var1 == Material.DIAMOND_SWORD || var1 == Material.NETHERITE_SWORD;
   }

   private boolean isWeapon(Material var1) {
      return this.isSword(var1) || this.isAxe(var1) || var1 == Material.BOW || var1 == Material.CROSSBOW || var1 == Material.TRIDENT;
   }

   private boolean isArmor(Material var1) {
      String var2 = var1.name();
      return var2.endsWith("_HELMET") || var2.endsWith("_CHESTPLATE") || var2.endsWith("_LEGGINGS") || var2.endsWith("_BOOTS");
   }

   private boolean isBoots(Material var1) {
      return var1.name().endsWith("_BOOTS");
   }

   public void clearCache(UUID var1) {
   }
}
