package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.api.GemAbilityHandler;
import dev.xoperr.blissgems.managers.GemRegistryImpl;
import dev.xoperr.blissgems.utils.AbilityBinding;
import dev.xoperr.blissgems.utils.AbilitySlot;
import dev.xoperr.blissgems.utils.Achievement;
import dev.xoperr.blissgems.utils.CustomItemManager;
import dev.xoperr.blissgems.utils.GemType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.Particle;
import org.bukkit.Sound;
import org.bukkit.entity.Allay;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Item;
import org.bukkit.entity.ItemFrame;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.PlayerInventory;
import org.bukkit.inventory.meta.BundleMeta;

public class GemInteractListener implements Listener {
   private final BlissGems plugin;
   private final Map<UUID, Long> traderCooldowns;
   private final Map<UUID, Long> clickDisabledMessageCooldowns = new HashMap();
   private static final long CLICK_DISABLED_MSG_INTERVAL = 30000L;

   public GemInteractListener(BlissGems var1) {
      this.plugin = var1;
      this.traderCooldowns = new HashMap();
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      Action var2 = var1.getAction();
      boolean var3 = var2 == Action.RIGHT_CLICK_AIR || var2 == Action.RIGHT_CLICK_BLOCK;
      boolean var4 = var2 == Action.LEFT_CLICK_AIR || var2 == Action.LEFT_CLICK_BLOCK;
      if (var3 || var4) {
         if (var4) {
            this.handleLeftClickAbility(var1);
         } else {
            Player var5 = var1.getPlayer();
            ItemStack var6 = var1.getItem();
            if (var6 != null) {
               ItemStack var7 = var5.getInventory().getItemInMainHand();
               ItemStack var8 = var5.getInventory().getItemInOffHand();
               String var9 = CustomItemManager.getIdByItem(var7);
               String var10 = CustomItemManager.getIdByItem(var8);
               boolean var11 = var9 != null && GemType.isGem(var9);
               boolean var12 = var10 != null && GemType.isGem(var10);
               boolean var13 = var7 != null && var7.getType() == Material.BUNDLE;
               boolean var14 = var8 != null && var8.getType() == Material.BUNDLE;
               if ((!var11 || !var14) && (!var12 || !var13) && (!var11 || var6 == null || var6.getType() != Material.BUNDLE) && (!var12 || var6 == null || var6.getType() != Material.BUNDLE)) {
                  if (var6 == null || var6.getType() != Material.BUNDLE || !var11 && !var12) {
                     if (var6 != null && var6.getType() == Material.BUNDLE && this.bundleContainsGem(var6)) {
                        var1.setCancelled(true);
                        var5.sendMessage("§c§lThis bundle contains a gem! Remove the gem first before using it.");
                     } else {
                        String var19 = CustomItemManager.getIdByItem(var6);
                        if (var19 != null) {
                           switch (var19) {
                              case "energy_bottle" -> this.handleEnergyBottle(var5, var6, var1);
                              case "gem_trader" -> this.handleGemTrader(var5, var6, var1);
                           }

                           if (var19.endsWith("_gem_t1") || var19.endsWith("_gem_t2")) {
                              this.handleGemAbility(var5, var19, var1);
                           }

                        }
                     }
                  } else {
                     var1.setCancelled(true);
                     String var18 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
                     if (var18 != null && !var18.isEmpty()) {
                        var5.sendMessage(var18);
                     }

                  }
               } else {
                  var1.setCancelled(true);
                  String var15 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
                  if (var15 != null && !var15.isEmpty()) {
                     var5.sendMessage(var15);
                  }

               }
            }
         }
      }
   }

   private void handleGemAbility(Player var1, String var2, PlayerInteractEvent var3) {
      var3.setCancelled(true);
      AbilityBinding var4 = AbilityBinding.rightClick(var1.isSneaking());
      this.dispatchBoundAbility(var1, var4);
   }

   private void handleLeftClickAbility(PlayerInteractEvent var1) {
      ItemStack var2 = var1.getItem();
      if (var2 != null) {
         String var3 = CustomItemManager.getIdByItem(var2);
         if (var3 != null && (var3.endsWith("_gem_t1") || var3.endsWith("_gem_t2"))) {
            Player var4 = var1.getPlayer();
            AbilityBinding var5 = AbilityBinding.leftClick(var4.isSneaking());
            AbilitySlot var6 = this.plugin.getAbilityBindingManager() != null ? this.plugin.getAbilityBindingManager().getSlot(var4, var5) : null;
            if (var6 != null) {
               var1.setCancelled(true);
               if (this.gateAbility(var4)) {
                  this.plugin.getBlissCommand().triggerSlot(var4, var6);
               }
            }
         }
      }
   }

   private void dispatchBoundAbility(Player var1, AbilityBinding var2) {
      if (this.gateAbility(var1)) {
         AbilitySlot var3 = this.plugin.getAbilityBindingManager() != null ? this.plugin.getAbilityBindingManager().getSlot(var1, var2) : null;
         if (var3 != null) {
            this.plugin.getBlissCommand().triggerSlot(var1, var3);
         } else {
            String var4 = CustomItemManager.getIdByItem(var1.getInventory().getItemInMainHand());
            if (var4 == null || !var4.endsWith("_gem_t1") && !var4.endsWith("_gem_t2")) {
               var4 = CustomItemManager.getIdByItem(var1.getInventory().getItemInOffHand());
            }

            if (var4 != null) {
               int var5 = var4.endsWith("_gem_t2") ? 2 : 1;
               GemType var6 = GemType.fromOraxenId(var4);
               if (var6 != null) {
                  switch (var6) {
                     case ASTRA:
                        this.plugin.getAstraAbilities().a(var1, var5);
                        return;
                     case FIRE:
                        this.plugin.getFireAbilities().a(var1, var5);
                        return;
                     case FLUX:
                        this.plugin.getFluxAbilities().a(var1, var5);
                        return;
                     case LIFE:
                        this.plugin.getLifeAbilities().a(var1, var5);
                        return;
                     case PUFF:
                        this.plugin.getPuffAbilities().a(var1, var5);
                        return;
                     case SPEED:
                        this.plugin.getSpeedAbilities().a(var1, var5);
                        return;
                     case STRENGTH:
                        this.plugin.getStrengthAbilities().a(var1, var5);
                        return;
                     case WEALTH:
                        this.plugin.getWealthAbilities().a(var1, var5);
                        return;
                  }
               }

            }
         }
      }
   }

   private boolean gateAbility(Player var1) {
      if (this.plugin.getClickActivationManager().isClickActivationEnabled(var1)) {
         int var6 = this.plugin.getEnergyManager().getEnergy(var1);
         if (var6 <= 0) {
            String var3 = this.plugin.getConfigManager().getFormattedMessage("no-energy");
            if (var3 != null && !var3.isEmpty()) {
               var1.sendMessage(var3);
            }

            return false;
         } else {
            return true;
         }
      } else {
         long var2 = System.currentTimeMillis();
         Long var4 = (Long)this.clickDisabledMessageCooldowns.get(var1.getUniqueId());
         if (var4 == null || var2 - var4 >= 30000L) {
            this.clickDisabledMessageCooldowns.put(var1.getUniqueId(), var2);
            String var5 = this.plugin.getConfigManager().getFormattedMessage("click-activation-disabled");
            if (var5 != null && !var5.isEmpty()) {
               var1.sendMessage(var5);
            }
         }

         return false;
      }
   }

   private void handleEnergyBottle(Player var1, ItemStack var2, PlayerInteractEvent var3) {
      var3.setCancelled(true);
      int var4 = this.plugin.getEnergyManager().getEnergy(var1);
      int var5 = this.plugin.getConfigManager().getMaxEnergy();
      if (var4 < var5) {
         this.plugin.getEnergyManager().addEnergy(var1, 1);
         if (var2.getAmount() > 1) {
            var2.setAmount(var2.getAmount() - 1);
         } else if (var3.getHand() == EquipmentSlot.OFF_HAND) {
            var1.getInventory().setItemInOffHand((ItemStack)null);
         } else {
            var1.getInventory().setItemInMainHand((ItemStack)null);
         }

         if (this.plugin.getConfigManager().isEnergyBottleDropEnabled()) {
            var1.playSound(var1.getLocation(), Sound.ENTITY_EXPERIENCE_ORB_PICKUP, 1.0F, 1.0F);
            var1.spawnParticle(Particle.HEART, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 20, (double)0.5F, (double)0.5F, (double)0.5F);
         }

         String var7 = this.plugin.getConfigManager().getFormattedMessage("energy-bottle-consumed");
         if (var7 != null && !var7.isEmpty()) {
            var1.sendMessage(var7);
         }

      } else {
         String var6 = this.plugin.getConfigManager().getFormattedMessage("energy-already-max");
         if (var6 != null && !var6.isEmpty()) {
            var1.sendMessage(var6);
         } else {
            var1.sendMessage("§c§oYou already have maximum energy!");
         }

      }
   }

   private void handleGemTrader(Player var1, ItemStack var2, PlayerInteractEvent var3) {
      var3.setCancelled(true);
      long var6 = System.currentTimeMillis();
      Long var8 = (Long)this.traderCooldowns.get(var1.getUniqueId());
      int var9 = this.plugin.getConfigManager().getTraderCooldown();
      long var4;
      if (var8 != null && (var4 = var8 + (long)var9 * 1000L - var6) > 0L) {
         int var17 = (int)Math.ceil((double)var4 / (double)1000.0F);
         String var19 = this.plugin.getConfigManager().getFormattedMessage("trade-cooldown", "seconds", var17);
         if (var19 != null && !var19.isEmpty()) {
            var1.sendMessage(var19);
         }

      } else if (!this.plugin.getGemManager().hasActiveGem(var1)) {
         String var16 = this.plugin.getConfigManager().getFormattedMessage("no-gem");
         if (var16 != null && !var16.isEmpty()) {
            var1.sendMessage(var16);
         }

      } else {
         GemType var10 = this.plugin.getGemManager().getGemType(var1);
         if (var10 == null) {
            String var18 = this.plugin.getConfigManager().getFormattedMessage("no-gem");
            if (var18 != null && !var18.isEmpty()) {
               var1.sendMessage(var18);
            }

         } else {
            ArrayList var11 = new ArrayList();

            for(GemType var15 : GemType.values()) {
               if (var15 != var10 && this.plugin.getConfigManager().isGemEnabled(var15)) {
                  var11.add(var15);
               }
            }

            if (var11.isEmpty()) {
               var1.sendMessage(String.valueOf(ChatColor.RED) + "No other gem types available!");
            } else {
               GemType var20 = (GemType)var11.get((int)(Math.random() * (double)var11.size()));
               if (this.plugin.getGemManager().replaceGemType(var1, var20)) {
                  if (var2.getAmount() > 1) {
                     var2.setAmount(var2.getAmount() - 1);
                  } else {
                     var1.getInventory().setItemInMainHand((ItemStack)null);
                  }

                  this.traderCooldowns.put(var1.getUniqueId(), var6);
                  if (this.plugin.getAchievementManager() != null) {
                     this.plugin.getAchievementManager().unlock(var1, Achievement.TIME_FOR_A_CHANGE);
                  }

                  if (this.plugin.getConfigManager().shouldPlayTradeEffects()) {
                     var1.playSound(var1.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1.0F, 1.0F);
                     var1.spawnParticle(Particle.PORTAL, var1.getLocation().add((double)0.0F, (double)1.0F, (double)0.0F), 30, (double)0.5F, (double)0.5F, (double)0.5F);
                  }

                  String var21 = this.plugin.getConfigManager().getFormattedMessage("trade-success", "gem", var20.getDisplayName());
                  if (var21 != null && !var21.isEmpty()) {
                     var1.sendMessage(var21);
                  }
               } else {
                  var1.sendMessage(String.valueOf(ChatColor.RED) + "Failed to trade gem!");
               }

            }
         }
      }
   }

   @EventHandler
   public void onInventoryClick(InventoryClickEvent var1) {
      HumanEntity var2 = var1.getWhoClicked();
      if (var2 instanceof Player var3) {
         ItemStack var4 = var1.getCurrentItem();
         ItemStack var5 = var1.getCursor();
         ItemStack var6 = null;
         if (var1.getClick().toString().contains("NUMBER_KEY")) {
            int var7 = var1.getHotbarButton();
            if (var7 >= 0 && var7 < 9) {
               var6 = var3.getInventory().getItem(var7);
            }
         }

         PlayerInventory var16 = var3.getInventory();
         boolean var8 = var16.firstEmpty() == -1;
         if (var8 && var1.getClickedInventory() == var16) {
            String var9 = var4 != null ? CustomItemManager.getIdByItem(var4) : null;
            if (var9 != null && GemType.isGem(var9)) {
               var1.setCancelled(true);
               String var28 = this.plugin.getConfigManager().getFormattedMessage("cannot-move-gem-full-inventory");
               if (var28 != null && !var28.isEmpty()) {
                  var3.sendMessage(var28);
               }

               return;
            }

            if (var5 != null && var5.getType() != Material.AIR && var4 != null) {
               String var10 = CustomItemManager.getIdByItem(var4);
               if (var10 != null && GemType.isGem(var10)) {
                  var1.setCancelled(true);
                  var3.sendMessage("§c§lYou cannot swap items with your gem when inventory is full!");
                  return;
               }
            }
         }

         if (var1.getView().getTopInventory().getType() == InventoryType.CRAFTING) {
            if (var1.getClickedInventory() == var1.getView().getTopInventory()) {
               int var17 = var1.getRawSlot();
               if (var17 >= 1 && var17 <= 4) {
                  if (var5 != null && var5.getType() != Material.AIR) {
                     String var20 = CustomItemManager.getIdByItem(var5);
                     if (var20 != null && GemType.isGem(var20)) {
                        var1.setCancelled(true);
                        return;
                     }
                  }

                  if (var6 != null) {
                     String var21 = CustomItemManager.getIdByItem(var6);
                     if (var21 != null && GemType.isGem(var21)) {
                        var1.setCancelled(true);
                        return;
                     }
                  }
               }
            }

            if (var1.isShiftClick() && var1.getClickedInventory() == var3.getInventory() && var4 != null) {
               String var18 = CustomItemManager.getIdByItem(var4);
               if (var18 != null && GemType.isGem(var18)) {
                  var1.setCancelled(true);
                  return;
               }
            }
         }

         boolean var19 = var1.getView().getTopInventory() != null && var1.getView().getTopInventory().getHolder() != var3;
         if (var19) {
            if (var1.getClick().toString().equals("SWAP_OFFHAND")) {
               ItemStack var22 = var3.getInventory().getItemInOffHand();
               if (var22 != null) {
                  String var11 = CustomItemManager.getIdByItem(var22);
                  if (var11 != null && GemType.isGem(var11)) {
                     var1.setCancelled(true);
                     String var39 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-container");
                     if (var39 != null && !var39.isEmpty()) {
                        var3.sendMessage(var39);
                     }

                     return;
                  }
               }
            }

            if (var1.getClickedInventory() != var3.getInventory() && var5 != null) {
               String var23 = CustomItemManager.getIdByItem(var5);
               if (var23 != null && GemType.isGem(var23)) {
                  var1.setCancelled(true);
                  String var33 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-container");
                  if (var33 != null && !var33.isEmpty()) {
                     var3.sendMessage(var33);
                  }

                  return;
               }
            }

            if (var1.getClick().isShiftClick() && var1.getClickedInventory() == var3.getInventory() && var4 != null) {
               String var24 = CustomItemManager.getIdByItem(var4);
               if (var24 != null && GemType.isGem(var24)) {
                  var1.setCancelled(true);
                  String var32 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-container");
                  if (var32 != null && !var32.isEmpty()) {
                     var3.sendMessage(var32);
                  }

                  return;
               }
            }

            if (var1.getClickedInventory() != var3.getInventory() && var6 != null) {
               String var25 = CustomItemManager.getIdByItem(var6);
               if (var25 != null && GemType.isGem(var25)) {
                  var1.setCancelled(true);
                  String var31 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-container");
                  if (var31 != null && !var31.isEmpty()) {
                     var3.sendMessage(var31);
                  }

                  return;
               }
            }

            if (var1.getClick().toString().equals("DOUBLE_CLICK") && var5 != null) {
               String var26 = CustomItemManager.getIdByItem(var5);
               if (var26 != null && GemType.isGem(var26)) {
                  var1.setCancelled(true);
                  String var30 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-container");
                  if (var30 != null && !var30.isEmpty()) {
                     var3.sendMessage(var30);
                  }

                  return;
               }
            }
         }

         boolean var27 = false;
         boolean var29 = false;
         if (var4 != null) {
            if (var4.getType() == Material.BUNDLE) {
               var27 = true;
               String var12 = var5 != null ? CustomItemManager.getIdByItem(var5) : null;
               if (var12 != null && GemType.isGem(var12)) {
                  var1.setCancelled(true);
                  String var42 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
                  if (var42 != null && !var42.isEmpty()) {
                     var3.sendMessage(var42);
                  }

                  return;
               }
            }

            String var34 = CustomItemManager.getIdByItem(var4);
            if (var34 != null && GemType.isGem(var34)) {
               var29 = true;
               if (var5 != null && var5.getType() == Material.BUNDLE) {
                  var1.setCancelled(true);
                  String var41 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
                  if (var41 != null && !var41.isEmpty()) {
                     var3.sendMessage(var41);
                  }

                  return;
               }
            }
         }

         if (var5 != null) {
            if (var5.getType() == Material.BUNDLE) {
               var27 = true;
            }

            String var35 = CustomItemManager.getIdByItem(var5);
            if (var35 != null && GemType.isGem(var35)) {
               var29 = true;
            }
         }

         if (var6 != null) {
            if (var6.getType() == Material.BUNDLE && var29) {
               var1.setCancelled(true);
               String var38 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
               if (var38 != null && !var38.isEmpty()) {
                  var3.sendMessage(var38);
               }

               return;
            }

            String var36 = CustomItemManager.getIdByItem(var6);
            if (var36 != null && GemType.isGem(var36) && var27) {
               var1.setCancelled(true);
               String var40 = this.plugin.getConfigManager().getFormattedMessage("cannot-store-gem-bundle");
               if (var40 != null && !var40.isEmpty()) {
                  var3.sendMessage(var40);
               }

               return;
            }
         }

         if (var5 != null && var1.getClickedInventory() == var3.getInventory()) {
            String var37 = CustomItemManager.getIdByItem(var5);
            if (var37 != null && GemType.isGem(var37)) {
               int var13 = this.countGemsInInventory(var3);
               if (var13 > 0) {
                  boolean var14 = false;
                  if (var4 != null) {
                     String var15 = CustomItemManager.getIdByItem(var4);
                     if (var15 != null && GemType.isGem(var15)) {
                        var14 = true;
                     }
                  }

                  if (!var14) {
                     var1.setCancelled(true);
                     String var43 = this.plugin.getConfigManager().getFormattedMessage("already-have-gem");
                     if (var43 != null && !var43.isEmpty()) {
                        var3.sendMessage(var43);
                     }

                     return;
                  }
               }
            }
         }

         Bukkit.getScheduler().runTaskLater(this.plugin, () -> this.plugin.getGemManager().updateActiveGem(var3), 1L);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityPickupItem(EntityPickupItemEvent var1) {
      if (var1.getEntity() instanceof Player) {
         Player var2 = (Player)var1.getEntity();
         Item var3 = var1.getItem();
         ItemStack var4 = var3.getItemStack();
         String var5 = CustomItemManager.getIdByItem(var4);
         if (var5 != null && GemType.isGem(var5) && this.countGemsInInventory(var2) > 0) {
            PlayerInventory var6 = var2.getInventory();
            if (var6.firstEmpty() == -1) {
               var1.setCancelled(true);
               return;
            }
         }

         if (var5 != null && GemType.isGem(var5)) {
            int var8 = this.countGemsInInventory(var2);
            if (var8 > 0) {
               var1.setCancelled(true);
               String var7 = this.plugin.getConfigManager().getFormattedMessage("already-have-gem");
               if (var7 != null && !var7.isEmpty()) {
                  var2.sendMessage(var7);
               }
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryDrag(InventoryDragEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getOldCursor();
         if (var3 != null) {
            String var4 = CustomItemManager.getIdByItem(var3);
            if (var4 != null && GemType.isGem(var4) && var1.getInventory().getType() != InventoryType.PLAYER) {
               for(int var6 : var1.getRawSlots()) {
                  if (var6 < var1.getView().getTopInventory().getSize()) {
                     var1.setCancelled(true);
                     var2.sendMessage("§c§lYou cannot move gems to other containers!");
                     return;
                  }
               }
            }
         }

         if (this.countGemsInInventory(var2) > 0) {
            PlayerInventory var7 = var2.getInventory();
            if (var7.firstEmpty() == -1) {
               for(int var9 : var1.getRawSlots()) {
                  if (var9 >= var1.getView().getTopInventory().getSize()) {
                     var1.setCancelled(true);
                     var2.sendMessage("§c§lYour inventory is full! Cannot move items while carrying a gem.");
                     return;
                  }
               }
            }
         }

      }
   }

   private int countGemsInInventory(Player var1) {
      int var2 = 0;

      for(ItemStack var6 : var1.getInventory().getContents()) {
         if (var6 != null) {
            String var7 = CustomItemManager.getIdByItem(var6);
            if (var7 != null && GemType.isGem(var7)) {
               ++var2;
            } else if (var6.getType() == Material.BUNDLE && this.bundleContainsGem(var6)) {
               ++var2;
            }
         }
      }

      return var2;
   }

   private boolean bundleContainsGem(ItemStack var1) {
      if (var1 != null && var1.getType() == Material.BUNDLE) {
         if (var1.getItemMeta() instanceof BundleMeta) {
            BundleMeta var2 = (BundleMeta)var1.getItemMeta();
            if (var2.hasItems()) {
               for(ItemStack var4 : var2.getItems()) {
                  if (var4 != null) {
                     String var5 = CustomItemManager.getIdByItem(var4);
                     if (var5 != null && GemType.isGem(var5)) {
                        return true;
                     }
                  }
               }
            }
         }

         return false;
      } else {
         return false;
      }
   }

   @EventHandler
   public void onPlayerInteractEntity(PlayerInteractEntityEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var2.getInventory().getItemInMainHand();
      ItemStack var4 = var2.getInventory().getItemInOffHand();
      if (var1.getRightClicked() instanceof ItemFrame || var1.getRightClicked() instanceof Allay) {
         String var5 = CustomItemManager.getIdByItem(var3);
         String var6 = CustomItemManager.getIdByItem(var4);
         if (var5 != null && GemType.isGem(var5) || var6 != null && GemType.isGem(var6)) {
            var1.setCancelled(true);
            String var7 = this.plugin.getConfigManager().getFormattedMessage("cannot-place-gem-itemframe");
            if (var7 != null && !var7.isEmpty()) {
               var2.sendMessage(var7);
            }
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryClose(InventoryCloseEvent var1) {
      if (var1.getPlayer() instanceof Player) {
         Player var2 = (Player)var1.getPlayer();
         if (var1.getView().getTitle().equals("§6§lPockets")) {
            this.plugin.getWealthAbilities().f(var2.getUniqueId());
         }

         if (var1.getView().getTopInventory().getType() == InventoryType.CRAFTING) {
            for(int var3 = 1; var3 <= 4; ++var3) {
               ItemStack var4 = var1.getView().getTopInventory().getItem(var3);
               if (var4 != null && !var4.getType().isAir()) {
                  String var5 = CustomItemManager.getIdByItem(var4);
                  if (var5 != null && GemType.isGem(var5)) {
                     var1.getView().getTopInventory().setItem(var3, (ItemStack)null);
                     this.forceGemIntoInventory(var2, var4);
                  }
               }
            }
         }

         ItemStack var6 = var2.getItemOnCursor();
         if (var6 != null && var6.getType() != Material.AIR) {
            String var7 = CustomItemManager.getIdByItem(var6);
            if (var7 != null && GemType.isGem(var7)) {
               var2.setItemOnCursor((ItemStack)null);
               this.forceGemIntoInventory(var2, var6);
            }
         }

         this.enforceOneGemOnly(var2);
      }
   }

   private void enforceOneGemOnly(Player var1) {
      PlayerInventory var2 = var1.getInventory();
      boolean var3 = false;
      ArrayList var4 = new ArrayList();

      for(int var5 = 0; var5 < var2.getSize(); ++var5) {
         ItemStack var6 = var2.getItem(var5);
         if (var6 != null && var6.getType() != Material.AIR) {
            String var7 = CustomItemManager.getIdByItem(var6);
            if (var7 != null && GemType.isGem(var7)) {
               if (!var3) {
                  var3 = true;
               } else {
                  var4.add(var6.clone());
                  var2.setItem(var5, (ItemStack)null);
               }
            } else if (var6.getType() == Material.BUNDLE) {
               List var8 = this.extractGemsFromBundle(var6, var5, var2);
               if (!var8.isEmpty()) {
                  for(ItemStack var10 : var8) {
                     if (!var3) {
                        var3 = true;
                        this.forceGemIntoInventory(var1, var10);
                     } else {
                        var4.add(var10);
                     }
                  }
               }
            }
         }
      }

      if (!var4.isEmpty()) {
         for(ItemStack var12 : var4) {
            var1.getWorld().dropItemNaturally(var1.getLocation(), var12);
         }

         var1.sendMessage("§c§lYou can only have one gem! Extra gems have been dropped.");
      }

   }

   private List<ItemStack> extractGemsFromBundle(ItemStack var1, int var2, PlayerInventory var3) {
      ArrayList var4 = new ArrayList();
      if (var1 != null && var1.getType() == Material.BUNDLE) {
         if (var1.getItemMeta() instanceof BundleMeta) {
            BundleMeta var5 = (BundleMeta)var1.getItemMeta();
            if (var5.hasItems()) {
               ArrayList var6 = new ArrayList();

               for(ItemStack var8 : var5.getItems()) {
                  if (var8 != null) {
                     String var9 = CustomItemManager.getIdByItem(var8);
                     if (var9 != null && GemType.isGem(var9)) {
                        var4.add(var8.clone());
                     } else {
                        var6.add(var8);
                     }
                  }
               }

               if (!var4.isEmpty()) {
                  var5.setItems(var6);
                  var1.setItemMeta(var5);
                  var3.setItem(var2, var1);
               }
            }
         }

         return var4;
      } else {
         return var4;
      }
   }

   private void forceGemIntoInventory(Player var1, ItemStack var2) {
      PlayerInventory var3 = var1.getInventory();
      int var4 = var3.firstEmpty();
      if (var4 != -1) {
         var3.setItem(var4, var2);
      } else {
         for(int var5 = 9; var5 < 36; ++var5) {
            ItemStack var6 = var3.getItem(var5);
            if (var6 != null && var6.getType() != Material.AIR) {
               String var7 = CustomItemManager.getIdByItem(var6);
               if (var7 == null || !GemType.isGem(var7)) {
                  ItemStack var8 = var6.clone();
                  var3.setItem(var5, var2);
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var8);
                  String var9 = this.plugin.getConfigManager().getFormattedMessage("gem-forced-into-inventory");
                  if (var9 != null && !var9.isEmpty()) {
                     var1.sendMessage(var9);
                  }

                  return;
               }
            }
         }

         for(int var10 = 0; var10 < 9; ++var10) {
            ItemStack var12 = var3.getItem(var10);
            if (var12 != null && var12.getType() != Material.AIR) {
               String var13 = CustomItemManager.getIdByItem(var12);
               if (var13 == null || !GemType.isGem(var13)) {
                  ItemStack var14 = var12.clone();
                  var3.setItem(var10, var2);
                  var1.getWorld().dropItemNaturally(var1.getLocation(), var14);
                  String var15 = this.plugin.getConfigManager().getFormattedMessage("gem-forced-into-inventory");
                  if (var15 != null && !var15.isEmpty()) {
                     var1.sendMessage(var15);
                  }

                  return;
               }
            }
         }

         var3.setItem(0, var2);
         String var11 = this.plugin.getConfigManager().getFormattedMessage("gem-forced-into-hotbar");
         if (var11 != null && !var11.isEmpty()) {
            var1.sendMessage(var11);
         }

      }
   }

   public void triggerAbilityViaCommand(Player var1, boolean var2) {
      ItemStack var3 = var1.getInventory().getItemInMainHand();
      ItemStack var4 = var1.getInventory().getItemInOffHand();
      String var5 = CustomItemManager.getIdByItem(var3);
      boolean var6 = var5 != null && (GemType.isGem(var5) || this.plugin.getGemRegistry() != null && this.plugin.getGemRegistry().isRegisteredGem(var5));
      if (!var6) {
         var5 = CustomItemManager.getIdByItem(var4);
         var6 = var5 != null && (GemType.isGem(var5) || this.plugin.getGemRegistry() != null && this.plugin.getGemRegistry().isRegisteredGem(var5));
         if (!var6) {
            var1.sendMessage("§c§lYou must be holding a gem to use this command!");
            return;
         }
      }

      int var7 = this.plugin.getEnergyManager().getEnergy(var1);
      if (var7 <= 0) {
         String var14 = this.plugin.getConfigManager().getFormattedMessage("no-energy");
         if (var14 != null && !var14.isEmpty()) {
            var1.sendMessage(var14);
         }

      } else {
         GemRegistryImpl var8 = this.plugin.getGemRegistry();
         String var9 = var8 != null ? var8.gemIdFromItemId(var5) : null;
         int var10 = var8 != null ? var8.tierFromItemId(var5) : (var5.endsWith("_gem_t2") ? 2 : 1);
         if (var2 && var10 < 2) {
            var1.sendMessage("§c§lSecondary abilities require Tier 2 gem!");
         } else {
            GemType var11 = GemType.fromOraxenId(var5);
            if (var11 != null) {
               boolean var15 = var1.isSneaking();
               if (var2 && !var15) {
                  var1.sendMessage("§e§oShift + use ability or right-click for secondary ability!");
               } else {
                  switch (var11) {
                     case ASTRA -> this.plugin.getAstraAbilities().a(var1, var10);
                     case FIRE -> this.plugin.getFireAbilities().a(var1, var10);
                     case FLUX -> this.plugin.getFluxAbilities().a(var1, var10);
                     case LIFE -> this.plugin.getLifeAbilities().a(var1, var10);
                     case PUFF -> this.plugin.getPuffAbilities().a(var1, var10);
                     case SPEED -> this.plugin.getSpeedAbilities().a(var1, var10);
                     case STRENGTH -> this.plugin.getStrengthAbilities().a(var1, var10);
                     case WEALTH -> this.plugin.getWealthAbilities().a(var1, var10);
                  }

               }
            } else {
               if (var9 != null && var8 != null) {
                  GemAbilityHandler var12 = var8.getAbilityHandler(var9);
                  if (var12 != null) {
                     if (var2) {
                        var12.onSecondary(var1, var10);
                     } else {
                        var12.onPrimary(var1, var10);
                     }
                  }
               }

            }
         }
      }
   }
}
