package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import java.util.ArrayList;
import java.util.logging.Logger;
import org.bukkit.GameMode;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityPickupItemEvent;
import org.bukkit.event.entity.ItemDespawnEvent;
import org.bukkit.event.entity.ItemMergeEvent;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEntityEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;

public class ComprehensiveGemProtectionListener implements Listener {
   private final BlissGems plugin;

   public ComprehensiveGemProtectionListener(BlissGems var1) {
      this.plugin = var1;
   }

   private boolean isProtectionEnabled() {
      return this.plugin.getConfig().getBoolean("gems.prevent-drop", true);
   }

   private void sendProtectionMessage(Player var1) {
      String var2 = this.plugin.getConfigManager().getFormattedMessage("cannot-drop-gem");
      if (var2 != null && !var2.isEmpty()) {
         var1.sendMessage(var2);
      } else {
         var1.sendMessage("§c§lYou cannot drop your gem!");
      }

   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onItemDrop(PlayerDropItemEvent var1) {
      if (this.isProtectionEnabled()) {
         ItemStack var2 = var1.getItemDrop().getItemStack();
         if (CustomItemManager.isUndroppable(var2)) {
            var1.setCancelled(true);
            this.sendProtectionMessage(var1.getPlayer());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerQuit(PlayerQuitEvent var1) {
      if (this.isProtectionEnabled()) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var2.getItemOnCursor();
         if (var3 != null && CustomItemManager.isUndroppable(var3)) {
            var2.setItemOnCursor((ItemStack)null);
            if (var2.getInventory().firstEmpty() != -1) {
               var2.getInventory().addItem(new ItemStack[]{var3});
            } else {
               var2.getWorld().dropItemNaturally(var2.getLocation(), var3);
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInventoryClick(InventoryClickEvent var1) {
      if (this.isProtectionEnabled()) {
         if (var1.getWhoClicked() instanceof Player) {
            Player var2 = (Player)var1.getWhoClicked();
            ItemStack var3 = var1.getCursor();
            ItemStack var4 = var1.getCurrentItem();
            Inventory var5 = var1.getClickedInventory();
            Inventory var6 = var1.getView().getTopInventory();
            if (var6 == null || var6.getType() != InventoryType.ENDER_CHEST || (var3 == null || !CustomItemManager.isUndroppable(var3)) && (var4 == null || !CustomItemManager.isUndroppable(var4) || !var1.isShiftClick())) {
               if (var3 != null && CustomItemManager.isUndroppable(var3) && var5 != null && !this.isPlayerInventory(var5)) {
                  var1.setCancelled(true);
                  this.sendProtectionMessage(var2);
               } else if (var1.isShiftClick() && var4 != null && CustomItemManager.isUndroppable(var4) && var5 != null && this.isPlayerInventory(var5) && var6 != null && !this.isPlayerInventory(var6)) {
                  var1.setCancelled(true);
                  this.sendProtectionMessage(var2);
               } else {
                  if (var1.getClick() == ClickType.NUMBER_KEY) {
                     int var7 = var1.getHotbarButton();
                     if (var7 >= 0 && var7 < 9) {
                        ItemStack var8 = var2.getInventory().getItem(var7);
                        if (var8 != null && CustomItemManager.isUndroppable(var8) && var5 != null && !this.isPlayerInventory(var5)) {
                           var1.setCancelled(true);
                           this.sendProtectionMessage(var2);
                           return;
                        }
                     }
                  }

                  if ((var1.getClick() == ClickType.DROP || var1.getClick() == ClickType.CONTROL_DROP) && var4 != null && CustomItemManager.isUndroppable(var4)) {
                     var1.setCancelled(true);
                     this.sendProtectionMessage(var2);
                  } else {
                     if (var1.getClick() == ClickType.SWAP_OFFHAND) {
                        ItemStack var9 = var2.getInventory().getItemInOffHand();
                        if (var4 != null && CustomItemManager.isUndroppable(var4) || var9 != null && CustomItemManager.isUndroppable(var9)) {
                           var1.setCancelled(true);
                           return;
                        }
                     }

                     if (var1.getClick() == ClickType.DOUBLE_CLICK && var3 != null && CustomItemManager.isUndroppable(var3) && var5 != null && !this.isPlayerInventory(var5)) {
                        var1.setCancelled(true);
                        this.sendProtectionMessage(var2);
                     } else {
                        if (var2.getGameMode() == GameMode.CREATIVE && var1.getClick() == ClickType.CREATIVE && var4 != null && CustomItemManager.isUndroppable(var4)) {
                        }

                     }
                  }
               }
            } else {
               var1.setCancelled(true);
               this.sendProtectionMessage(var2);
            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInventoryDrag(InventoryDragEvent var1) {
      if (this.isProtectionEnabled()) {
         if (var1.getWhoClicked() instanceof Player) {
            ItemStack var2 = var1.getOldCursor();
            if (var2 != null && CustomItemManager.isUndroppable(var2)) {
               Inventory var3 = var1.getView().getTopInventory();
               if (var3 != null && !this.isPlayerInventory(var3)) {
                  int var4 = var3.getSize();

                  for(int var6 : var1.getRawSlots()) {
                     if (var6 < var4) {
                        var1.setCancelled(true);
                        this.sendProtectionMessage((Player)var1.getWhoClicked());
                        return;
                     }
                  }
               }

            }
         }
      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR,
      ignoreCancelled = true
   )
   public void onInventoryClose(InventoryCloseEvent var1) {
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInventoryMoveItem(InventoryMoveItemEvent var1) {
      if (this.isProtectionEnabled()) {
         ItemStack var2 = var1.getItem();
         if (CustomItemManager.isUndroppable(var2)) {
            var1.setCancelled(true);
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteractEntity(PlayerInteractEntityEvent var1) {
      if (this.isProtectionEnabled()) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var2.getInventory().getItemInMainHand();
         if (CustomItemManager.isUndroppable(var3)) {
            Entity var4 = var1.getRightClicked();
            if (var4.getType().name().contains("ITEM_FRAME") || var4.getType().name().contains("ARMOR_STAND")) {
               var1.setCancelled(true);
               this.sendProtectionMessage(var2);
            }
         }

         ItemStack var6 = var2.getInventory().getItemInOffHand();
         if (CustomItemManager.isUndroppable(var6)) {
            Entity var5 = var1.getRightClicked();
            if (var5.getType().name().contains("ITEM_FRAME") || var5.getType().name().contains("ARMOR_STAND")) {
               var1.setCancelled(true);
               this.sendProtectionMessage(var2);
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onEntityPickupItem(EntityPickupItemEvent var1) {
      if (this.isProtectionEnabled()) {
         if (!(var1.getEntity() instanceof Player)) {
            ItemStack var2 = var1.getItem().getItemStack();
            if (CustomItemManager.isUndroppable(var2)) {
               var1.setCancelled(true);
            }

         }
      }
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onPlayerInteract(PlayerInteractEvent var1) {
      if (this.isProtectionEnabled()) {
         ItemStack var2 = var1.getItem();
         if (var2 != null && CustomItemManager.isUndroppable(var2) && var1.getClickedBlock() != null && var1.getClickedBlock().getType().name().contains("COMPOSTER")) {
            var1.setCancelled(true);
            this.sendProtectionMessage(var1.getPlayer());
         }

      }
   }

   @EventHandler(
      priority = EventPriority.MONITOR
   )
   public void onWorldChange(PlayerChangedWorldEvent var1) {
      if (this.isProtectionEnabled()) {
         Player var2 = var1.getPlayer();
         this.plugin.getServer().getScheduler().runTaskLater(this.plugin, () -> {
            if (var2.isOnline()) {
               this.enforceOneGemOnly(var2);
            }
         }, 1L);
      }
   }

   private void enforceOneGemOnly(Player var1) {
      boolean var2 = false;
      ArrayList var3 = new ArrayList();

      for(int var4 = 0; var4 < var1.getInventory().getSize(); ++var4) {
         ItemStack var5 = var1.getInventory().getItem(var4);
         if (var5 != null) {
            String var6 = CustomItemManager.getIdByItem(var5);
            if (var6 != null && this.plugin.getGemManager().isAnyGem(var6)) {
               if (!var2) {
                  var2 = true;
               } else {
                  var3.add(var4);
               }
            }
         }
      }

      if (!var3.isEmpty()) {
         for(int var8 : var3) {
            var1.getInventory().setItem(var8, (ItemStack)null);
         }

         Logger var10000 = this.plugin.getLogger();
         int var10001 = var3.size();
         var10000.info("Removed " + var10001 + " duplicate gem(s) from " + var1.getName() + " after world change.");
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST
   )
   public void onItemSpawn(ItemSpawnEvent var1) {
      Item var2 = var1.getEntity();
      ItemStack var3 = var2.getItemStack();
      if (var3 != null && this.isGemLike(var3)) {
         CustomItemManager.markAsUndroppable(var3);
         var2.setItemStack(var3);

         try {
            var2.setUnlimitedLifetime(true);
         } catch (NoSuchMethodError var5) {
            var2.setTicksLived(1);
         }

         var2.setInvulnerable(true);
         var2.setPersistent(true);
      }
   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onItemDespawn(ItemDespawnEvent var1) {
      ItemStack var2 = var1.getEntity().getItemStack();
      if (this.isGemLike(var2)) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.LOWEST,
      ignoreCancelled = true
   )
   public void onItemMerge(ItemMergeEvent var1) {
      if (this.isGemLike(var1.getEntity().getItemStack()) || this.isGemLike(var1.getTarget().getItemStack())) {
         var1.setCancelled(true);
      }

   }

   private boolean isGemLike(ItemStack var1) {
      if (var1 == null) {
         return false;
      } else if (CustomItemManager.isUndroppable(var1)) {
         return true;
      } else {
         String var2 = CustomItemManager.getIdByItem(var1);
         return var2 != null && this.plugin.getGemManager().isAnyGem(var2);
      }
   }

   private boolean isPlayerInventory(Inventory var1) {
      if (var1 == null) {
         return false;
      } else {
         InventoryType var2 = var1.getType();
         if (var2 == InventoryType.ENDER_CHEST) {
            return false;
         } else {
            return var2 == InventoryType.PLAYER || var2 == InventoryType.CRAFTING;
         }
      }
   }
}
