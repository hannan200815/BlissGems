package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.entity.ItemSpawnEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitRunnable;

public class RepairKitListener implements Listener {
   private final BlissGems plugin;

   public RepairKitListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerInteract(PlayerInteractEvent var1) {
      if (var1.getAction() == Action.RIGHT_CLICK_AIR || var1.getAction() == Action.RIGHT_CLICK_BLOCK) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var1.getItem();
         if (var3 != null) {
            String var4 = CustomItemManager.getIdByItem(var3);
            if (var4 != null && var4.equals("repair_kit")) {
               var1.setCancelled(true);
               var2.sendMessage("§d§oTo use the Repair Kit, drop it on top of a Beacon to create a Pedestal!");
               var2.sendMessage("§d§oThe Pedestal will restore energy to all nearby players.");
            }
         }
      }
   }

   @EventHandler
   public void onPlayerDropItem(PlayerDropItemEvent var1) {
      final Item var2 = var1.getItemDrop();
      final ItemStack var3 = var2.getItemStack();
      final Player var4 = var1.getPlayer();
      String var5 = CustomItemManager.getIdByItem(var3);
      if (var5 != null && var5.equals("repair_kit")) {
         (new BukkitRunnable() {
            public void run() {
               if (var2.isValid() && !var2.isDead()) {
                  Location var1 = var2.getLocation();
                  Block var2x = var1.subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
                  if (var2x.getType() == Material.BEACON) {
                     var2.remove();
                     boolean var3x = RepairKitListener.this.plugin.getRepairKitManager().createPedestal(var2x.getLocation());
                     if (var3x) {
                        var4.sendMessage("§d§l✦ §d§oPedestal created! It will restore energy to nearby players.");

                        for(Entity var5 : var1.getWorld().getNearbyEntities(var1, (double)15.0F, (double)15.0F, (double)15.0F)) {
                           if (var5 instanceof Player && var5 != var4) {
                              Player var6 = (Player)var5;
                              var6.sendMessage("§d§o" + var4.getName() + " created a Repair Kit Pedestal nearby!");
                           }
                        }
                     } else {
                        var4.getInventory().addItem(new ItemStack[]{var3});
                        var4.sendMessage("§c§oCouldn't create pedestal at this location!");
                     }
                  }

               }
            }
         }).runTaskLater(this.plugin, 20L);
      }
   }

   @EventHandler
   public void onItemSpawn(ItemSpawnEvent var1) {
      final Item var2 = var1.getEntity();
      ItemStack var3 = var2.getItemStack();
      String var4 = CustomItemManager.getIdByItem(var3);
      if (var4 != null && var4.equals("repair_kit")) {
         (new BukkitRunnable() {
            public void run() {
               if (var2.isValid() && !var2.isDead()) {
                  Location var1 = var2.getLocation();
                  Block var2x = var1.clone().subtract((double)0.0F, (double)1.0F, (double)0.0F).getBlock();
                  if (var2x.getType() == Material.BEACON) {
                     var2.remove();
                     boolean var3 = RepairKitListener.this.plugin.getRepairKitManager().createPedestal(var2x.getLocation());
                     if (var3) {
                        for(Entity var5 : var1.getWorld().getNearbyEntities(var1, (double)15.0F, (double)15.0F, (double)15.0F)) {
                           if (var5 instanceof Player) {
                              Player var6 = (Player)var5;
                              var6.sendMessage("§d§l✦ §d§oRepair Kit Pedestal activated!");
                           }
                        }
                     }
                  }

               }
            }
         }).runTaskLater(this.plugin, 40L);
      }
   }
}
