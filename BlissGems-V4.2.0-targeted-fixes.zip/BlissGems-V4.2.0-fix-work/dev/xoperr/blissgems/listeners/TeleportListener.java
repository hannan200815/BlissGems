package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerTeleportEvent;
import org.bukkit.event.player.PlayerTeleportEvent.TeleportCause;

public class TeleportListener implements Listener {
   private final BlissGems plugin;

   public TeleportListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerTeleport(PlayerTeleportEvent var1) {
      Player var2 = var1.getPlayer();
      if (var1.getCause() == TeleportCause.SPECTATE && this.plugin.getAstraAbilities().c(var2)) {
         var1.setCancelled(true);
         var2.sendMessage("§d§oYou cannot teleport to players while projecting!");
      } else {
         if (this.plugin.getFireAbilities().a(var2)) {
            this.plugin.getFireAbilities().e(var2);
            var2.sendMessage("§c§oYour fireball charge was cancelled due to teleportation.");
         }

         if (this.plugin.getFluxAbilities().a(var2)) {
            this.plugin.getFluxAbilities().d(var2);
            var2.sendMessage("§b⚡ §oYour flux beam charge was cancelled due to teleportation.");
         }

      }
   }
}
