package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.utils.CustomItemManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryMoveItemEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.inventory.ItemStack;

public class GemDropListener implements Listener {
   private final BlissGems plugin;

   public GemDropListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onItemDrop(PlayerDropItemEvent var1) {
      if (this.plugin.getConfig().getBoolean("gems.prevent-drop", true)) {
         Player var2 = var1.getPlayer();
         ItemStack var3 = var1.getItemDrop().getItemStack();
         boolean var4 = CustomItemManager.isUndroppable(var3);
         if (var4) {
            var1.setCancelled(true);
            String var5 = this.plugin.getConfigManager().getFormattedMessage("cannot-drop-gem");
            if (var5 != null && !var5.isEmpty()) {
               var2.sendMessage(var5);
            } else {
               var2.sendMessage("§c§lYou cannot drop your gem!");
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGH
   )
   public void onInventoryMoveItem(InventoryMoveItemEvent var1) {
      ItemStack var2 = var1.getItem();
      if (CustomItemManager.isUndroppable(var2)) {
         var1.setCancelled(true);
      }

   }
}
