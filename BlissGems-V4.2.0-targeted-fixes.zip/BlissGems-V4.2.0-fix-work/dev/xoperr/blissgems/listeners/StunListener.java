package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import dev.xoperr.blissgems.a.c;
import dev.xoperr.blissgems.a.f;
import java.util.UUID;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Entity;
import org.bukkit.entity.HumanEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.block.BlockPlaceEvent;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.ProjectileLaunchEvent;
import org.bukkit.event.inventory.InventoryOpenEvent;
import org.bukkit.event.player.PlayerDropItemEvent;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerItemConsumeEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.projectiles.ProjectileSource;

public class StunListener implements Listener {
   private final BlissGems plugin;

   public StunListener(BlissGems var1) {
      this.plugin = var1;
   }

   private boolean isImmobilized(UUID var1) {
      return c.a(var1) || f.a(var1);
   }

   private boolean isFrozen(UUID var1) {
      return f.a(var1) || c.a(var1);
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerMove(PlayerMoveEvent var1) {
      Player var2 = var1.getPlayer();
      if (this.isFrozen(var2.getUniqueId())) {
         Location var3 = var1.getFrom();
         Location var4 = var1.getTo();
         if (var3.getX() != var4.getX() || var3.getY() != var4.getY() || var3.getZ() != var4.getZ()) {
            Location var5 = var3.clone();
            var5.setYaw(var4.getYaw());
            var5.setPitch(var4.getPitch());
            var1.setTo(var5);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onToggleFlight(PlayerToggleFlightEvent var1) {
      if (this.isImmobilized(var1.getPlayer().getUniqueId())) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerInteract(PlayerInteractEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (var3 != null) {
         UUID var4 = var2.getUniqueId();
         if (this.isImmobilized(var4)) {
            Material var5 = var3.getType();
            if (var5 == Material.ENDER_PEARL || var5 == Material.CHORUS_FRUIT) {
               var1.setCancelled(true);
               var2.sendMessage(this.plugin.getConfigManager().getFormattedMessage("cannot-use-while-stunned", "item", var5 == Material.ENDER_PEARL ? "ender pearls" : "chorus fruit"));
               return;
            }

            if (this.isFrozen(var4)) {
               if (var5 != Material.GOLDEN_APPLE && var5 != Material.ENCHANTED_GOLDEN_APPLE) {
                  var1.setCancelled(true);
                  if (var3.getType().isEdible() || var5 == Material.POTION || var5 == Material.SPLASH_POTION || var5 == Material.LINGERING_POTION) {
                     var2.sendMessage(this.plugin.getConfigManager().getMessage("can-only-eat-golden-apple-stunned"));
                  }

                  return;
               }
            } else if (var5 != Material.GOLDEN_APPLE && var5 != Material.ENCHANTED_GOLDEN_APPLE && (var3.getType().isEdible() || var5 == Material.POTION || var5 == Material.SPLASH_POTION || var5 == Material.LINGERING_POTION)) {
               var1.setCancelled(true);
               var2.sendMessage(this.plugin.getConfigManager().getMessage("can-only-eat-golden-apple-stunned"));
            }
         }

      }
   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onPlayerConsume(PlayerItemConsumeEvent var1) {
      Player var2 = var1.getPlayer();
      ItemStack var3 = var1.getItem();
      if (this.isImmobilized(var2.getUniqueId())) {
         Material var4 = var3.getType();
         if (var4 != Material.GOLDEN_APPLE && var4 != Material.ENCHANTED_GOLDEN_APPLE) {
            var1.setCancelled(true);
            var2.sendMessage(this.plugin.getConfigManager().getMessage("can-only-eat-golden-apple-stunned"));
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onProjectileLaunch(ProjectileLaunchEvent var1) {
      ProjectileSource var3 = var1.getEntity().getShooter();
      if (var3 instanceof Player var2) {
         if (this.isImmobilized(var2.getUniqueId())) {
            var1.setCancelled(true);
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onInventoryOpen(InventoryOpenEvent var1) {
      HumanEntity var3 = var1.getPlayer();
      if (var3 instanceof Player var2) {
         if (this.isFrozen(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§c§lYou cannot open inventories while frozen!");
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onItemDrop(PlayerDropItemEvent var1) {
      if (this.isFrozen(var1.getPlayer().getUniqueId())) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onEntityDamage(EntityDamageByEntityEvent var1) {
      Entity var3 = var1.getDamager();
      if (var3 instanceof Player var2) {
         if (this.isFrozen(var2.getUniqueId())) {
            var1.setCancelled(true);
            var2.sendMessage("§c§lYou cannot attack while frozen!");
         }
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onBlockBreak(BlockBreakEvent var1) {
      if (this.isFrozen(var1.getPlayer().getUniqueId())) {
         var1.setCancelled(true);
      }

   }

   @EventHandler(
      priority = EventPriority.HIGHEST
   )
   public void onBlockPlace(BlockPlaceEvent var1) {
      if (this.isFrozen(var1.getPlayer().getUniqueId())) {
         var1.setCancelled(true);
      }

   }
}
