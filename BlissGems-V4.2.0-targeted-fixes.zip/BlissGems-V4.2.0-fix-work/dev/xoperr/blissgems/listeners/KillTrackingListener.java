package dev.xoperr.blissgems.listeners;

import dev.xoperr.blissgems.BlissGems;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.metadata.FixedMetadataValue;

public class KillTrackingListener implements Listener {
   private final BlissGems plugin;
   private final Map<UUID, Long> lastDamageTime = new HashMap();
   private static final long KILL_WINDOW_MS = 3000L;

   public KillTrackingListener(BlissGems var1) {
      this.plugin = var1;
   }

   @EventHandler
   public void onPlayerDamageByPlayer(EntityDamageByEntityEvent var1) {
      if (var1.getEntity().getType() == EntityType.PLAYER && var1.getDamager().getType() == EntityType.PLAYER) {
         Player var2 = (Player)var1.getEntity();
         Player var3 = (Player)var1.getDamager();
         if (this.plugin.getGemManager().getGemType(var3) != null) {
            var2.setMetadata("gem_damage_by", new FixedMetadataValue(this.plugin, var3.getUniqueId()));
            this.lastDamageTime.put(var2.getUniqueId(), System.currentTimeMillis());
         }

      }
   }

   @EventHandler
   public void onPlayerDeath(PlayerDeathEvent var1) {
      Player var2 = var1.getEntity();
      Player var3 = var2.getKiller();
      if (var3 != null) {
         if (this.plugin.getGemManager().getGemType(var3) != null) {
            Long var4 = (Long)this.lastDamageTime.get(var2.getUniqueId());
            if (var4 != null && System.currentTimeMillis() - var4 < 3000L) {
               this.plugin.getStatsManager().recordKill(var3, var2);
            }
         }

         this.plugin.getStatsManager().recordDeath(var2);
      }

      this.lastDamageTime.remove(var2.getUniqueId());
      if (var2.hasMetadata("gem_damage_by")) {
         var2.removeMetadata("gem_damage_by", this.plugin);
      }

   }
}
