package dev.xoperr.blissgems.core.a.d;

import dev.xoperr.blissgems.core.b.d;
import org.bukkit.Location;
import org.bukkit.entity.Player;

public class a {
   private static d a;

   public static void a(d var0) {
      a = var0;
   }

   public static boolean a(Player var0) {
      c();
      return a.a(var0);
   }

   public static boolean a(Location var0) {
      c();
      return a.a(var0);
   }

   public static String a() {
      c();
      return a.a();
   }

   public static boolean b() {
      c();
      return a.b();
   }

   private static void c() {
      if (a == null) {
         throw new IllegalStateException("RegionAPI has not been initialized!");
      }
   }
}
