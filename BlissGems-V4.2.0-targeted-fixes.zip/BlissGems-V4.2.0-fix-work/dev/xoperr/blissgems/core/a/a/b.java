package dev.xoperr.blissgems.core.a.a;

import java.util.Collections;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.EquipmentSlot;

public class b {
   private final String a;
   private final Map<EquipmentSlot, Map<Enchantment, Integer>> b;
   private boolean c;
   private int d;

   public b(String var1) {
      this.a = var1;
      this.b = new EnumMap(EquipmentSlot.class);
      this.c = false;
      this.d = 0;
   }

   public b a(EquipmentSlot var1, Enchantment var2, int var3) {
      ((Map)this.b.computeIfAbsent(var1, (var0) -> new HashMap())).put(var2, var3);
      return this;
   }

   public b a(Enchantment var1, int var2) {
      this.a(EquipmentSlot.HEAD, var1, var2);
      this.a(EquipmentSlot.CHEST, var1, var2);
      this.a(EquipmentSlot.LEGS, var1, var2);
      this.a(EquipmentSlot.FEET, var1, var2);
      return this;
   }

   public b b(Enchantment var1, int var2) {
      this.a(EquipmentSlot.HAND, var1, var2);
      return this;
   }

   public b a(boolean var1) {
      this.c = var1;
      return this;
   }

   public b a(int var1) {
      this.d = var1;
      return this;
   }

   public String a() {
      return this.a;
   }

   public Map<EquipmentSlot, Map<Enchantment, Integer>> b() {
      return Collections.unmodifiableMap(this.b);
   }

   public Map<Enchantment, Integer> a(EquipmentSlot var1) {
      return (Map)this.b.getOrDefault(var1, Collections.emptyMap());
   }

   public boolean c() {
      return this.c;
   }

   public int d() {
      return this.d;
   }

   public boolean b(EquipmentSlot var1) {
      return this.b.containsKey(var1) && !((Map)this.b.get(var1)).isEmpty();
   }
}
