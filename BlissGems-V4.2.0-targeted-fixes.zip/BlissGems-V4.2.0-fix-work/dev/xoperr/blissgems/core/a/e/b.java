package dev.xoperr.blissgems.core.a.e;

import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

public interface b {
   String a(Player var1, ItemStack var2, ItemStack var3);

   default boolean b(Player var1, ItemStack var2, ItemStack var3) {
      return true;
   }

   default int a() {
      return 0;
   }
}
