package dev.xoperr.blissgems.core.a.e;

import dev.xoperr.blissgems.core.b.e;
import org.bukkit.entity.Player;

public class a {
   private static e a;

   public static void a(e var0) {
      a = var0;
   }

   public static void a(Player var0, String var1) {
      a();
      a.a(var0, var1);
   }

   public static void a(Player var0) {
      a();
      a.a(var0);
   }

   public static void a(Player var0, String var1, String var2, int var3, int var4, int var5) {
      a();
      a.a(var0, var1, var2, var3, var4, var5);
   }

   public static void b(Player var0) {
      a();
      a.b(var0);
   }

   public static void a(b var0) {
      a();
      a.a(var0);
   }

   public static void b(b var0) {
      a();
      a.b(var0);
   }

   private static void a() {
      if (a == null) {
         throw new IllegalStateException("InventoryTextAPI has not been initialized! Ensure XoperrCore is loaded.");
      }
   }
}
