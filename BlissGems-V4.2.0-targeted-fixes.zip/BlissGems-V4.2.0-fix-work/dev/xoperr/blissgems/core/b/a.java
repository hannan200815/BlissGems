package dev.xoperr.blissgems.core.b;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.scheduler.BukkitTask;

public class a {
   private static final EquipmentSlot[] a;
   private final Plugin b;
   private final Map<String, dev.xoperr.blissgems.core.a.a.b> c;
   private final NamespacedKey d;
   private BukkitTask e;
   private boolean f;

   public a(Plugin var1) {
      this.b = var1;
      this.c = new HashMap();
      this.d = new NamespacedKey(var1, "auto_enchant");
      this.f = true;
      this.c();
   }

   public void a(dev.xoperr.blissgems.core.a.a.b var1) {
      if (var1 != null && var1.a() != null) {
         this.c.put(var1.a(), var1);
      }
   }

   public void a(String var1) {
      this.c.remove(var1);
   }

   public dev.xoperr.blissgems.core.a.a.b b(String var1) {
      return (dev.xoperr.blissgems.core.a.a.b)this.c.get(var1);
   }

   public boolean c(String var1) {
      return this.c.containsKey(var1);
   }

   public void a(Player var1) {
      if (this.f && var1 != null) {
         Set var2 = this.c(var1);

         for(EquipmentSlot var6 : a) {
            this.a(var1, var6, var2);
         }

      }
   }

   private Set<String> c(Player var1) {
      HashSet var2 = new HashSet();

      for(ItemStack var6 : var1.getInventory().getContents()) {
         if (var6 != null && dev.xoperr.blissgems.core.a.c.a.c(var6)) {
            String var7 = dev.xoperr.blissgems.core.a.c.a.d(var6);
            if (var7 != null && this.c.containsKey(var7)) {
               var2.add(var7);
            }
         }
      }

      return var2;
   }

   private void a(Player var1, EquipmentSlot var2, Set<String> var3) {
      ItemStack var4 = var1.getInventory().getItem(var2);
      if (var4 != null && !var4.getType().isAir()) {
         HashMap var5 = new HashMap();

         for(String var7 : var3) {
            dev.xoperr.blissgems.core.a.a.b var8 = (dev.xoperr.blissgems.core.a.a.b)this.c.get(var7);
            if (var8 != null && var8.b(var2)) {
               Map var9 = var8.a(var2);

               for(Map.Entry var11 : var9.entrySet()) {
                  Enchantment var12 = (Enchantment)var11.getKey();
                  int var13 = (Integer)var11.getValue();
                  var5.merge(var12, var13, Math::max);
               }
            }
         }

         this.a(var4, var5);
         this.b(var4, var5);
      }
   }

   private void a(ItemStack var1, Map<Enchantment, Integer> var2) {
      ItemMeta var3 = var1.getItemMeta();
      if (var3 != null) {
         PersistentDataContainer var4 = var3.getPersistentDataContainer();
         Map var5 = var3.getEnchants();

         for(Enchantment var7 : new HashSet(var5.keySet())) {
            NamespacedKey var8 = new NamespacedKey(this.b, "auto_" + var7.getKey().getKey());
            if (var4.has(var8, PersistentDataType.BYTE) && !var2.containsKey(var7)) {
               var3.removeEnchant(var7);
               var4.remove(var8);
            }
         }

         var1.setItemMeta(var3);
      }
   }

   private void b(ItemStack var1, Map<Enchantment, Integer> var2) {
      if (!var2.isEmpty()) {
         ItemMeta var3 = var1.getItemMeta();
         if (var3 != null) {
            PersistentDataContainer var4 = var3.getPersistentDataContainer();
            boolean var5 = false;

            for(Map.Entry var7 : var2.entrySet()) {
               Enchantment var8 = (Enchantment)var7.getKey();
               int var9 = (Integer)var7.getValue();
               int var10 = var3.getEnchantLevel(var8);
               NamespacedKey var11 = new NamespacedKey(this.b, "auto_" + var8.getKey().getKey());
               boolean var12 = var4.has(var11, PersistentDataType.BYTE);
               if (var10 == 0) {
                  var3.addEnchant(var8, var9, true);
                  var4.set(var11, PersistentDataType.BYTE, (byte)1);
                  var5 = true;
               } else if (var12 && var10 != var9) {
                  var3.removeEnchant(var8);
                  var3.addEnchant(var8, var9, true);
                  var5 = true;
               }
            }

            if (var5) {
               var1.setItemMeta(var3);
            }

         }
      }
   }

   public void b(Player var1) {
      for(EquipmentSlot var5 : a) {
         ItemStack var6 = var1.getInventory().getItem(var5);
         if (var6 != null) {
            this.a(var6);
         }
      }

   }

   private void a(ItemStack var1) {
      ItemMeta var2 = var1.getItemMeta();
      if (var2 != null) {
         PersistentDataContainer var3 = var2.getPersistentDataContainer();
         Map var4 = var2.getEnchants();
         boolean var5 = false;

         for(Enchantment var7 : new HashSet(var4.keySet())) {
            NamespacedKey var8 = new NamespacedKey(this.b, "auto_" + var7.getKey().getKey());
            if (var3.has(var8, PersistentDataType.BYTE)) {
               var2.removeEnchant(var7);
               var3.remove(var8);
               var5 = true;
            }
         }

         if (var5) {
            var1.setItemMeta(var2);
         }

      }
   }

   private void c() {
      this.e = this.b.getServer().getScheduler().runTaskTimer(this.b, () -> {
         if (this.f) {
            for(Player var2 : this.b.getServer().getOnlinePlayers()) {
               this.a(var2);
            }
         }

      }, 20L, 10L);
   }

   public void a(boolean var1) {
      this.f = var1;
      if (!var1) {
         for(Player var3 : this.b.getServer().getOnlinePlayers()) {
            this.b(var3);
         }
      }

   }

   public boolean a() {
      return this.f;
   }

   public void b() {
      if (this.e != null) {
         this.e.cancel();
      }

      for(Player var2 : this.b.getServer().getOnlinePlayers()) {
         this.b(var2);
      }

      this.c.clear();
   }

   static {
      a = new EquipmentSlot[]{EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET, EquipmentSlot.HAND, EquipmentSlot.OFF_HAND};
   }
}
