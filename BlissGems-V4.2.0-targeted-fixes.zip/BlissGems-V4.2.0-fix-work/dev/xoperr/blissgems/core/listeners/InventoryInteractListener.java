package dev.xoperr.blissgems.core.listeners;

import dev.xoperr.blissgems.core.b.c;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryType;
import org.bukkit.inventory.ItemStack;

public class InventoryInteractListener implements Listener {
   private final c protectionManager;
   private final Set<InventoryType> restrictedInventories;
   private final Set<InventoryType> specialToolInventories;

   public InventoryInteractListener(c var1) {
      this.protectionManager = var1;
      this.restrictedInventories = new HashSet(Arrays.asList(InventoryType.CHEST, InventoryType.ENDER_CHEST, InventoryType.DISPENSER, InventoryType.DROPPER, InventoryType.HOPPER, InventoryType.FURNACE, InventoryType.BREWING, InventoryType.BARREL, InventoryType.SHULKER_BOX, InventoryType.BLAST_FURNACE, InventoryType.SMOKER, InventoryType.LECTERN, InventoryType.STONECUTTER, InventoryType.COMPOSTER, InventoryType.CHISELED_BOOKSHELF));
      this.specialToolInventories = new HashSet(Arrays.asList(InventoryType.GRINDSTONE, InventoryType.ENCHANTING, InventoryType.ANVIL, InventoryType.SMITHING, InventoryType.MERCHANT, InventoryType.LOOM, InventoryType.CARTOGRAPHY));
   }

   @EventHandler(
      priority = EventPriority.HIGH,
      ignoreCancelled = true
   )
   public void onInventoryClick(InventoryClickEvent var1) {
      if (var1.getWhoClicked() instanceof Player) {
         Player var2 = (Player)var1.getWhoClicked();
         ItemStack var3 = var1.getCurrentItem();
         ItemStack var4 = var1.getCursor();
         if (var1.getClickedInventory() == null || var1.getClickedInventory().getType() == InventoryType.PLAYER || var4 == null || var4.getType().isAir() || !this.protectionManager.c(var4) || !this.restrictedInventories.contains(var1.getClickedInventory().getType()) && !this.specialToolInventories.contains(var1.getClickedInventory().getType())) {
            if (var1.getClickedInventory() != null && var1.isShiftClick() && var1.getClickedInventory().getType() == InventoryType.PLAYER && var3 != null && !var3.getType().isAir() && var1.getView().getTopInventory().getType() != InventoryType.CRAFTING && this.protectionManager.c(var3) && (this.restrictedInventories.contains(var1.getView().getTopInventory().getType()) || this.specialToolInventories.contains(var1.getView().getTopInventory().getType()))) {
               var1.setCancelled(true);
            }

         } else {
            var1.setCancelled(true);
         }
      }
   }
}
