package dev.xoperr.blissgems.utils;

public enum AbilityBinding {
   RIGHT_CLICK("right_click", "Right Click", false),
   SHIFT_RIGHT_CLICK("shift_right_click", "Shift + Right Click", true),
   LEFT_CLICK("left_click", "Left Click", false),
   SHIFT_LEFT_CLICK("shift_left_click", "Shift + Left Click", true),
   SWAP_HAND("swap_hand", "F (Swap Offhand)", false),
   SHIFT_SWAP_HAND("shift_swap_hand", "Shift + F", true);

   private final String a;
   private final String b;
   private final boolean c;

   private AbilityBinding(String var3, String var4, boolean var5) {
      this.a = var3;
      this.b = var4;
      this.c = var5;
   }

   public String getId() {
      return this.a;
   }

   public String getDisplayName() {
      return this.b;
   }

   public boolean requiresSneak() {
      return this.c;
   }

   public static AbilityBinding fromId(String var0) {
      if (var0 == null) {
         return null;
      } else {
         String var1 = var0.toLowerCase().replace('-', '_');

         for(AbilityBinding var5 : values()) {
            if (var5.a.equals(var1)) {
               return var5;
            }
         }

         return null;
      }
   }

   public static AbilityBinding rightClick(boolean var0) {
      return var0 ? SHIFT_RIGHT_CLICK : RIGHT_CLICK;
   }

   public static AbilityBinding leftClick(boolean var0) {
      return var0 ? SHIFT_LEFT_CLICK : LEFT_CLICK;
   }

   public static AbilityBinding swapHand(boolean var0) {
      return var0 ? SHIFT_SWAP_HAND : SWAP_HAND;
   }

   // $FF: synthetic method
   private static AbilityBinding[] a() {
      return new AbilityBinding[]{RIGHT_CLICK, SHIFT_RIGHT_CLICK, LEFT_CLICK, SHIFT_LEFT_CLICK, SWAP_HAND, SHIFT_SWAP_HAND};
   }
}
