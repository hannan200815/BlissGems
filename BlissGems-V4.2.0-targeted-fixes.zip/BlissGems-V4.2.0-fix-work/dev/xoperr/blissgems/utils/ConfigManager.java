package dev.xoperr.blissgems.utils;

import dev.xoperr.blissgems.BlissGems;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.Set;
import java.util.logging.Level;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

public class ConfigManager {
   private final BlissGems a;
   private FileConfiguration b;
   private static final String c = "1.0.0";

   public ConfigManager(BlissGems var1) {
      this.a = var1;
      this.reload();
      this.a();
   }

   public void reload() {
      this.a.reloadConfig();
      this.b = this.a.getConfig();
   }

   private void a() {
      File var1 = new File(this.a.getDataFolder(), "config.yml");
      if (var1.exists()) {
         YamlConfiguration var2 = YamlConfiguration.loadConfiguration(new InputStreamReader(this.a.getResource("config.yml"), StandardCharsets.UTF_8));
         String var3 = this.b.getString("config-version", "unknown");
         String var4 = ((FileConfiguration)var2).getString("config-version", "1.0.0");
         boolean var5 = !var3.equals(var4);
         boolean var6 = false;
         int var7 = 0;
         Set var8 = ((FileConfiguration)var2).getKeys(true);

         for(String var10 : var8) {
            if (!((FileConfiguration)var2).isConfigurationSection(var10) && !this.b.contains(var10)) {
               var6 = true;
               ++var7;
            }
         }

         if (!var6) {
            if (var5) {
               this.b.set("config-version", var4);

               try {
                  this.b.save(var1);
                  this.a.getLogger().info("Updated config version from " + var3 + " to " + var4);
               } catch (IOException var11) {
                  this.a.getLogger().warning("Failed to update config version: " + var11.getMessage());
               }
            }

         } else {
            try {
               File var14 = new File(this.a.getDataFolder(), "config.yml.backup");
               Files.copy(var1.toPath(), var14.toPath(), StandardCopyOption.REPLACE_EXISTING);
               this.a.getLogger().info("Created config backup: config.yml.backup");
            } catch (IOException var13) {
               this.a.getLogger().warning("Failed to backup config: " + var13.getMessage());
            }

            if (var5) {
               this.a.getLogger().warning("Detected outdated config! (v" + var3 + " -> v" + var4 + ")");
            }

            this.a.getLogger().warning("Auto-repairing config: " + var7 + " missing entries detected.");

            for(String var16 : var8) {
               if (!((FileConfiguration)var2).isConfigurationSection(var16) && !this.b.contains(var16)) {
                  this.b.set(var16, ((FileConfiguration)var2).get(var16));
                  this.a.getLogger().info("  + Added: " + var16);
               }
            }

            this.b.set("config-version", var4);

            try {
               this.b.save(var1);
               this.a.getLogger().info("Config auto-repair complete! " + var7 + " keys added.");
               this.a.getLogger().info("Your old config was backed up to config.yml.backup");
               this.reload();
            } catch (IOException var12) {
               this.a.getLogger().log(Level.SEVERE, "Failed to save repaired config!", var12);
            }

         }
      }
   }

   public FileConfiguration getConfig() {
      return this.b;
   }

   public int getEnergyGainOnKill() {
      return this.b.getInt("energy.gain-on-kill", 1);
   }

   public int getEnergyLossOnDeath() {
      return this.b.getInt("energy.loss-on-death", 1);
   }

   public int getMaxEnergy() {
      return this.b.getInt("energy.max-energy", 10);
   }

   public int getStartingEnergy() {
      return this.b.getInt("energy.starting-energy", 5);
   }

   public int getRuinedThreshold() {
      return this.b.getInt("energy.ruined-threshold", 1);
   }

   public int getBrokenThreshold() {
      return this.b.getInt("energy.broken-threshold", 0);
   }

   public boolean isBanOnZeroEnergyEnabled() {
      return this.b.getBoolean("energy.ban-on-zero-energy", false);
   }

   public void setBanOnZeroEnergy(boolean var1) {
      this.b.set("energy.ban-on-zero-energy", var1);

      try {
         this.b.save(new File(this.a.getDataFolder(), "config.yml"));
      } catch (IOException var3) {
         this.a.getLogger().warning("Failed to save config: " + var3.getMessage());
      }

   }

   public boolean isSmpStarted() {
      return this.b.getBoolean("smp.started", false);
   }

   public void setSmpStarted(boolean var1) {
      this.b.set("smp.started", var1);

      try {
         this.b.save(new File(this.a.getDataFolder(), "config.yml"));
      } catch (IOException var3) {
         this.a.getLogger().warning("Failed to save config: " + var3.getMessage());
      }

   }

   public int getSmpAutoStartThreshold() {
      return this.b.getInt("smp.auto-start-threshold", 10);
   }

   public boolean isGemEnabled(GemType var1) {
      return this.b.getBoolean("gems.enabled." + var1.getId(), true);
   }

   public boolean isSingleGemOnly() {
      return this.b.getBoolean("gems.single-gem-only", true);
   }

   public int getPassiveUpdateInterval() {
      return this.b.getInt("passives.update-interval", 20);
   }

   public double getPhaseChance(int var1) {
      String var2 = "passives.astra.tier" + var1 + ".phase-chance";
      return this.b.getDouble(var2, var1 == 1 ? 0.1 : 0.15);
   }

   public double getLifeHealAmount(int var1) {
      String var2 = "passives.life.tier" + var1 + ".heal-amount";
      return this.b.getDouble(var2, var1 == 1 ? 0.3 : (double)0.5F);
   }

   public int getLifeHealInterval(int var1) {
      String var2 = "passives.life.tier" + var1 + ".heal-interval";
      return this.b.getInt(var2, 100);
   }

   public double getUndeadDamageMultiplier(int var1) {
      String var2 = "passives.life.tier" + var1 + ".undead-damage-multiplier";
      return this.b.getDouble(var2, var1 == 1 ? (double)2.0F : (double)3.0F);
   }

   public double getSaturationMultiplier(int var1) {
      String var2 = "passives.life.tier" + var1 + ".saturation-multiplier";
      return this.b.getDouble(var2, var1 == 1 ? (double)1.5F : (double)2.0F);
   }

   public int getGoldenAppleAbsorptionLevel(int var1) {
      String var2 = "passives.life.tier" + var1 + ".golden-apple-absorption-level";
      return this.b.getInt(var2, var1 == 1 ? 0 : 1);
   }

   public double getShockingArrowDamage(int var1) {
      String var2 = "passives.flux.tier" + var1 + ".shocking-arrow-damage";
      return this.b.getDouble(var2, var1 == 1 ? (double)2.0F : (double)3.0F);
   }

   public double getFlowStateSpeedBoost(int var1) {
      String var2 = "passives.flux.tier" + var1 + ".flow-state-speed-boost";
      return this.b.getDouble(var2, var1 == 1 ? 0.15 : 0.2);
   }

   public boolean isDoubleJumpEnabled(int var1) {
      String var2 = "passives.puff.tier" + var1 + ".double-jump-enabled";
      return this.b.getBoolean(var2, true);
   }

   public double getDoubleJumpVelocity(int var1) {
      String var2 = "passives.puff.tier" + var1 + ".double-jump-velocity";
      return this.b.getDouble(var2, var1 == 1 ? 0.6 : 0.8);
   }

   public double getLaunchVelocity(int var1) {
      String var2 = "passives.puff.tier" + var1 + ".launch-velocity";
      return this.b.getDouble(var2, var1 == 1 ? (double)3.5F : (double)4.5F);
   }

   public boolean isFallDamageImmunity(int var1) {
      String var2 = "passives.puff.tier" + var1 + ".fall-damage-immunity";
      return this.b.getBoolean(var2, true);
   }

   public boolean isSculkImmunity(int var1) {
      String var2 = "passives.puff.tier" + var1 + ".sculk-immunity";
      return this.b.getBoolean(var2, var1 == 2);
   }

   public boolean isAutoSmeltEnabled(int var1) {
      String var2 = "passives.fire.tier" + var1 + ".auto-smelt";
      return this.b.getBoolean(var2, true);
   }

   public boolean isFireResistanceEnabled(int var1) {
      String var2 = "passives.fire.tier" + var1 + ".fire-resistance";
      return this.b.getBoolean(var2, true);
   }

   public boolean isSoulSandImmunity(int var1) {
      String var2 = "passives.speed.tier" + var1 + ".soul-sand-immunity";
      return this.b.getBoolean(var2, true);
   }

   public int getSpeedLevel(int var1) {
      String var2 = "passives.speed.tier" + var1 + ".speed-level";
      return this.b.getInt(var2, var1 == 1 ? 0 : 1);
   }

   public int getStrengthLevel(int var1) {
      String var2 = "passives.strength.tier" + var1 + ".strength-level";
      return this.b.getInt(var2, var1 == 1 ? 0 : 1);
   }

   public double getBloodthornsMaxBonusDamage(int var1) {
      String var2 = "passives.strength.tier" + var1 + ".bloodthorns-max-bonus-damage";
      return this.b.getDouble(var2, var1 == 1 ? (double)7.0F : (double)10.0F);
   }

   public int getLuckLevel(int var1) {
      String var2 = "passives.wealth.tier" + var1 + ".luck-level";
      return this.b.getInt(var2, var1 == 1 ? 0 : 1);
   }

   public double getVillagerDiscount(int var1) {
      String var2 = "passives.wealth.tier" + var1 + ".villager-discount";
      return this.b.getDouble(var2, var1 == 1 ? 0.1 : 0.2);
   }

   /** @deprecated */
   @Deprecated
   public double getPhaseChance() {
      return this.getPhaseChance(2);
   }

   /** @deprecated */
   @Deprecated
   public double getLifeHealAmount() {
      return this.getLifeHealAmount(2);
   }

   /** @deprecated */
   @Deprecated
   public int getLifeHealInterval() {
      return this.getLifeHealInterval(2);
   }

   /** @deprecated */
   @Deprecated
   public double getUndeadDamageMultiplier() {
      return this.getUndeadDamageMultiplier(2);
   }

   /** @deprecated */
   @Deprecated
   public double getSaturationMultiplier() {
      return this.getSaturationMultiplier(2);
   }

   public int getGlobalAbilityCooldown() {
      return this.b.getInt("abilities.global-cooldown", 1);
   }

   public int getAbilityCooldown(String var1) {
      return this.b.getInt("abilities.cooldowns." + var1, 10);
   }

   public double getAbilityDamage(String var1) {
      return this.b.getDouble("abilities.damage." + var1, (double)4.0F);
   }

   public int getAbilityDuration(String var1) {
      return this.b.getInt("abilities.durations." + var1, 10);
   }

   public boolean isAutoEnchantEnabled() {
      return this.b.getBoolean("auto-enchant.enabled", true);
   }

   public boolean shouldPlayUpgradeEffects() {
      return this.b.getBoolean("upgrader.play-effects", true);
   }

   public String getUpgradeParticle() {
      return this.b.getString("upgrader.particle", "ENCHANT");
   }

   public int getUpgradeParticleCount() {
      return this.b.getInt("upgrader.particle-count", 50);
   }

   public String getUpgradeSound() {
      return this.b.getString("upgrader.sound", "ENTITY_PLAYER_LEVELUP");
   }

   public int getTraderCooldown() {
      return this.b.getInt("trader.cooldown", 5);
   }

   public boolean shouldPlayTradeEffects() {
      return this.b.getBoolean("trader.play-effects", true);
   }

   public boolean isEnergyBottleDropEnabled() {
      return this.b.getBoolean("energy-bottle.drop-enabled", true);
   }

   public int getRepairKitEnergyPerSecond() {
      return this.b.getInt("repair-kit.energy-per-second", 1);
   }

   public int getRepairKitMaxEnergy() {
      return this.b.getInt("repair-kit.max-total-energy", 10);
   }

   public int getRepairKitRadius() {
      return this.b.getInt("repair-kit.heal-radius", 10);
   }

   public int getRepairKitUpdateInterval() {
      return this.b.getInt("repair-kit.update-interval", 20);
   }

   public boolean shouldPrioritizeLowestEnergy() {
      return this.b.getBoolean("repair-kit.prioritize-lowest", true);
   }

   public String getMessage(String var1) {
      return this.b.getString("messages." + var1, "").replace("&", "§");
   }

   public String getPrefix() {
      return this.getMessage("prefix");
   }

   public String getFormattedMessage(String var1, Object... var2) {
      if (this.areOptionalMessagesDisabled() && var1.equals("ability-activated")) {
         return null;
      } else {
         String var3 = this.getMessage(var1);
         if (var3 != null && !var3.trim().isEmpty()) {
            for(int var4 = 0; var4 < var2.length; var4 += 2) {
               if (var4 + 1 < var2.length) {
                  var3 = var3.replace("{" + String.valueOf(var2[var4]) + "}", String.valueOf(var2[var4 + 1]));
               }
            }

            String var10000 = this.getPrefix();
            String var6 = var10000 + " §f" + var3;
            String var5 = var6.replaceAll("§[0-9a-fk-or]", "").trim();
            if (!var5.equals("BlissGems »") && !var5.isEmpty()) {
               return var6;
            } else {
               return null;
            }
         } else {
            return null;
         }
      }
   }

   public void sendFormattedMessage(CommandSender var1, String var2, Object... var3) {
      String var4 = this.getFormattedMessage(var2, var3);
      if (var4 != null && !var4.isEmpty()) {
         var1.sendMessage(var4);
      }

   }

   public boolean areOptionalMessagesDisabled() {
      return this.b.getBoolean("disable-optional-messages", true);
   }
}
