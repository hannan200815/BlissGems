package dev.xoperr.blissgems.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class CustomItemManager {
   private static final Map<String, a> a = new HashMap();
   private static NamespacedKey b;
   private static NamespacedKey c;

   public static void initialize(JavaPlugin var0) {
      b = new NamespacedKey(var0, "item_id");
      c = new NamespacedKey(var0, "locked_item");
   }

   private static void a(String var0, Material var1, int var2, String var3) {
      a.put(var0, new a(var1, var2, var3, (List)null));
   }

   private static void a(String var0, Material var1, int var2, String var3, List<String> var4) {
      a.put(var0, new a(var1, var2, var3, var4));
   }

   public static void registerAddonItem(String var0, Material var1, int var2, String var3, List<String> var4) {
      if (a.containsKey(var0)) {
         throw new IllegalArgumentException("Item ID '" + var0 + "' is already registered!");
      } else {
         a.put(var0, new a(var1, var2, var3, var4));
      }
   }

   public static String getIdByItem(ItemStack var0) {
      if (var0 != null && var0.hasItemMeta()) {
         ItemMeta var1 = var0.getItemMeta();
         if (var1 == null) {
            return null;
         } else {
            return var1.getPersistentDataContainer().has(b, PersistentDataType.STRING) ? (String)var1.getPersistentDataContainer().get(b, PersistentDataType.STRING) : null;
         }
      } else {
         return null;
      }
   }

   public static ItemStack getItemById(String var0) {
      return getItemById(var0, -1);
   }

   public static ItemStack getItemById(String var0, int var1) {
      a var2 = (a)a.get(var0);
      if (var2 == null) {
         return null;
      } else {
         ItemStack var3 = new ItemStack(var2.a);
         ItemMeta var4 = var3.getItemMeta();
         if (var4 == null) {
            return var3;
         } else {
            int var5 = var2.b;
            if (GemType.isGem(var0) && var1 >= 0) {
               var5 = a(var2.b, var1, var0);
            }

            var4.setCustomModelData(var5);
            var4.getPersistentDataContainer().set(b, PersistentDataType.STRING, var0);
            if (GemType.isGem(var0)) {
               var4.getPersistentDataContainer().set(c, PersistentDataType.BYTE, (byte)1);
            }

            var4.setDisplayName(var2.c);
            if (GemType.isGem(var0)) {
               a(var4, var2.d, var1);
            } else if (var2.d != null && !var2.d.isEmpty()) {
               var4.setLore(var2.d);
            }

            var3.setItemMeta(var4);
            return var3;
         }
      }
   }

   private static int a(int var0, int var1, String var2) {
      if (var2 == null || !var2.equals("strength_gem_t1") && !var2.equals("strength_gem_t2")) {
         byte var3;
         if (var1 <= 2) {
            var3 = 0;
         } else if (var1 <= 5) {
            var3 = 20;
         } else if (var1 <= 8) {
            var3 = 30;
         } else {
            var3 = 40;
         }

         return var0 + var3;
      } else {
         return var0;
      }
   }

   public static void updateGemTexture(ItemStack var0, int var1) {
      if (var0 != null && var0.hasItemMeta()) {
         String var2 = getIdByItem(var0);
         if (var2 != null && GemType.isGem(var2)) {
            a var3 = (a)a.get(var2);
            if (var3 != null) {
               ItemMeta var4 = var0.getItemMeta();
               if (var4 != null) {
                  int var5 = a(var3.b, var1, var2);
                  var4.setCustomModelData(var5);
                  a(var4, var3.d, var1);
                  var0.setItemMeta(var4);
               }
            }
         }
      }
   }

   private static void a(ItemMeta var0, List<String> var1, int var2) {
      EnergyState var3 = EnergyState.fromEnergy(var2);
      boolean var4 = var3.isEnhanced();
      ArrayList var5 = new ArrayList();
      if (var1 != null) {
         var5.addAll(var1);
      }

      if (var4) {
         if (!var5.isEmpty()) {
            var5.add("");
         }

         var5.add("§5✮ " + var3.getDisplayName());
      }

      var0.setLore(var5.isEmpty() ? null : var5);
      if (var4) {
         var0.addEnchant(Enchantment.UNBREAKING, 1, true);
         var0.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
      } else {
         var0.removeEnchant(Enchantment.UNBREAKING);
      }

   }

   public static boolean isCustomItem(ItemStack var0) {
      return getIdByItem(var0) != null;
   }

   public static boolean markAsUndroppable(ItemStack var0) {
      if (var0 != null && var0.getType() != Material.AIR && var0.hasItemMeta()) {
         ItemMeta var1 = var0.getItemMeta();
         if (var1 == null) {
            return false;
         } else {
            PersistentDataContainer var2 = var1.getPersistentDataContainer();
            if (var2.has(c, PersistentDataType.BYTE) && (Byte)var2.get(c, PersistentDataType.BYTE) == 1) {
               return false;
            } else {
               var2.set(c, PersistentDataType.BYTE, (byte)1);
               var0.setItemMeta(var1);
               return true;
            }
         }
      } else {
         return false;
      }
   }

   public static boolean isUndroppable(ItemStack var0) {
      if (var0 != null && var0.getType() != Material.AIR) {
         if (!var0.hasItemMeta()) {
            return false;
         } else {
            ItemMeta var1 = var0.getItemMeta();
            if (var1 == null) {
               return false;
            } else {
               PersistentDataContainer var2 = var1.getPersistentDataContainer();
               return var2.has(c, PersistentDataType.BYTE) && (Byte)var2.get(c, PersistentDataType.BYTE) == 1;
            }
         }
      } else {
         return false;
      }
   }

   static {
      a("astra_gem_t1", Material.ECHO_SHARD, 1001, "§d§lASTRA GEM", List.of("§f§lMANAGE THE TIDES OF THE COSMOS", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Soul Capture & Soul Healing", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udd2a ASTRAL DAGGERS", "§7Fire 3 phantom daggers that deal damage", "", "§8Upgrade to Tier 2 for Astral Projection,", "§8Dimensional Drift & Void!"));
      a("fire_gem_t1", Material.ECHO_SHARD, 1002, "§d§lFIRE GEM", List.of("§f§lMANIPULATE FIRE", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Fire Resistance", "§7- Flame & Fire Aspect on weapons", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udd25 CHARGED FIREBALL", "§7Hold to charge, release to fire", "§7Stand on obsidian to prevent charge decay", "", "§8Upgrade to Tier 2 for Campfire,", "§8Crisp & Meteor Shower!"));
      a("flux_gem_t1", Material.ECHO_SHARD, 1003, "§d§lFLUX GEM", List.of("§f§lWITH GREAT POWER COMES GREAT RESPONSIBILITY", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Immune to Weakness, Slowness & Hunger", "§7- Shocking Chance (stun on arrow hits)", "", "§b\ud83c\udf1f §b§lABILITY", "§7- Conduction (teleport to copper blocks)", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l✠ FLUX BEAM", "§7Charge and fire a powerful beam", "§7Charged beam deals massive armor damage", "", "§8Upgrade to Tier 2 for Ground & more!"));
      a("life_gem_t1", Material.ECHO_SHARD, 1004, "§d§lLIFE GEM", List.of("§f§lCONTROL THE BALANCE OF LIFE", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Wither immunity", "§7- Continuous healing", "§7- Unbreaking on tools", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udc98 HEART DRAINER", "§7Siphon health from your enemies", "", "§8Upgrade to Tier 2 for Life Circle,", "§8Vitality Vortex & Heart Lock!"));
      a("puff_gem_t1", Material.ECHO_SHARD, 1005, "§d§lPUFF GEM", List.of("§f§lBE THE BIGGEST BIRD", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- No fall damage", "§7- Power & Punch on bows", "", "§b\ud83c\udf1f §b§lABILITY", "§7- Double Jump", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l☁ DASH", "§7Dashes in the direction you're looking", "§7Deals damage if passing through enemies", "", "§8Upgrade to Tier 2 for Breezy Bash!"));
      a("speed_gem_t1", Material.ECHO_SHARD, 1006, "§d§lSPEED GEM", List.of("§f§lWATCH THE WORLD TURN INTO A BLUR", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Speed I & Dolphin's Grace", "§7- Efficiency on tools", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l⚡ BLUR", "§7Summons successive lightning strikes", "§7dealing damage and knockback", "", "§8Upgrade to Tier 2 for Speed Storm", "§8& Terminal Velocity!"));
      a("strength_gem_t1", Material.ECHO_SHARD, 1007, "§d§lSTRENGTH GEM", List.of("§f§lHAVE THE STRENGTH OF AN ARMY", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Strength I", "§7- Sharpness II on weapons", "§7- Bloodthorns (more damage at low HP)", "", "§8No active abilities at Tier 1", "§8Upgrade to Tier 2 for Nullify, Frailer", "§8& Shadow Stalker!"));
      a("wealth_gem_t1", Material.ECHO_SHARD, 1008, "§d§lWEALTH GEM", List.of("§f§lFUEL AN EMPIRE", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Luck & Hero of the Village", "§7- Mending, Fortune & Looting on tools", "§7- Durability Chip (extra armor damage)", "", "§8No active abilities at Tier 1", "§8Upgrade to Tier 2 for Pockets,", "§8Unfortunate & more!"));
      a("astra_gem_t2", Material.ECHO_SHARD, 2001, "§d§lASTRA GEM", List.of("§f§lMANAGE THE TIDES OF THE COSMOS", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Soul Capture & Soul Healing", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udd2a ASTRAL DAGGERS", "§7Fire 3 phantom daggers that deal damage", "", "§b§l\ud83d\udc7b ASTRAL PROJECTION", "§7Scout in spectator mode", "§7Sub-abilities: §dSpook §7& §dTag", "", "§b§l\ud83c\udf00 DIMENSIONAL DRIFT", "§7Ride an invisible horse while invisible", "", "§b§l\ud83d\udd73 DIMENSIONAL VOID", "§7Nullify enemy gem abilities in radius"));
      a("fire_gem_t2", Material.ECHO_SHARD, 2002, "§d§lFIRE GEM", List.of("§f§lMANIPULATE FIRE", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Fire Resistance", "§7- Flame & Fire Aspect on weapons", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udd25 CHARGED FIREBALL", "§7Hold to charge, release to fire", "§7Stand on obsidian to prevent charge decay", "", "§b§l\ud83e\udd7e COZY CAMPFIRE", "§7Spawns a campfire granting allies Regen IV", "", "§b§l\ud83e\uddca CRISP", "§7Evaporate water, replace blocks with nether", "", "§b§l\ud83e\udde8 METEOR SHOWER", "§7Rain fire on a target area"));
      a("flux_gem_t2", Material.ECHO_SHARD, 2003, "§d§lFLUX GEM", List.of("§f§lWITH GREAT POWER COMES GREAT RESPONSIBILITY", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Immune to Weakness, Slowness & Hunger", "§7- Shocking Chance (stun on arrow hits)", "", "§b\ud83c\udf1f §b§lABILITY", "§7- Conduction (teleport to copper blocks)", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l✠ FLUX BEAM", "§7Chargeable beam dealing massive armor damage", "", "§b§l\ud83c\udf00 GROUND", "§7Freeze enemies in place", "", "§b§l\ud83d\udca5 FLASHBANG", "§7Blindness and Nausea to enemies in radius", "", "§b§l⚡ KINETIC BURST", "§7Radial knockback with sonic boom"));
      a("life_gem_t2", Material.ECHO_SHARD, 2004, "§d§lLIFE GEM", List.of("§f§lCONTROL THE BALANCE OF LIFE", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Wither immunity", "§7- Continuous healing", "§7- Unbreaking on tools", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udc98 HEART DRAINER", "§7Siphon health from your enemies", "", "§b§l✨ CIRCLE OF LIFE", "§7Zone that decreases enemy max HP", "§7and increases yours and allies' HP", "", "§b§l\ud83d\udcab VITALITY VORTEX", "§7Grants effects based on your surroundings", "", "§b§l\ud83d\udd12 HEART LOCK", "§7Cap enemy max HP at their current HP"));
      a("puff_gem_t2", Material.ECHO_SHARD, 2005, "§d§lPUFF GEM", List.of("§f§lBE THE BIGGEST BIRD", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- No fall damage", "§7- Power & Punch on bows", "", "§b\ud83c\udf1f §b§lABILITY", "§7- Double Jump", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l☁ DASH", "§7Dashes in the direction you're looking", "§7Deals damage if passing through enemies", "", "§b§l⏫ BREEZY BASH", "§7Launch an enemy skyward then slam them", "", "§b§l\ud83c\udf2a GROUP BREEZY BASH", "§7Send all nearby enemies flying away"));
      a("speed_gem_t2", Material.ECHO_SHARD, 2006, "§d§lSPEED GEM", List.of("§f§lWATCH THE WORLD TURN INTO A BLUR", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Speed I & Dolphin's Grace", "§7- Efficiency on tools", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l⚡ BLUR", "§7Summons successive lightning strikes", "§7dealing damage and knockback", "", "§b§l\ud83c\udf29 SPEED STORM", "§7Freezes enemies while granting allies", "§7Speed and Haste", "", "§b§l\ud83d\udca8 TERMINAL VELOCITY", "§7Speed III + Haste II for a short duration"));
      a("strength_gem_t2", Material.ECHO_SHARD, 2007, "§d§lSTRENGTH GEM", List.of("§f§lHAVE THE STRENGTH OF AN ARMY", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Strength I", "§7- Sharpness V on weapons", "§7- Bloodthorns (more damage at low HP)", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udeab NULLIFY", "§7Strip all potion effects from a target", "", "§b§l⚔ FRAILER", "§7Clear target's potions, apply Weakness I", "§7(20s) and Wither I (40s)", "", "§b§l\ud83d\udd0d SHADOW STALKER", "§7Consume a player head or owned item", "§7to track a player's location"));
      a("wealth_gem_t2", Material.ECHO_SHARD, 2008, "§d§lWEALTH GEM", List.of("§f§lFUEL AN EMPIRE", "§a§o(Pristine)", "", "§a\ud83c\udf1f §a§lPASSIVES", "§7- Luck & Hero of the Village", "§7- Mending, Fortune & Looting on tools", "§7- Durability Chip & Armor Mend", "", "§d\ud83c\udf1f §d§lPOWERS", "§b§l\ud83d\udcb8 UNFORTUNATE", "§7Chance to disable enemy actions", "", "§b§l\ud83c\udf92 POCKETS", "§79 extra inventory slots (/bliss pockets)", "", "§b§l\ud83d\udd12 ITEM LOCK", "§7Lock an enemy's held item temporarily", "", "§b§l✨ AMPLIFICATION", "§7Boost all enchantments for 45s", "", "§b§l\ud83c\udf40 RICH RUSH", "§7Increased drop rates for ~3 min"));
      a("gem_upgrader", Material.ENCHANTED_BOOK, 3001, "§6§l§nGem Upgrader", List.of("§7Right Click to upgrade any Tier 1 gem to Tier 2", "", "§8Works for ALL gem types:", "§5Astra §8• §cFire §8• §bFlux §8• §dLife", "§fPuff §8• §aSpeed §8• §6Strength §8• §eWealth"));
      a("energy_bottle", Material.GHAST_TEAR, 4001, "§b§lEnergy Bottle");
      a("gem_trader", Material.EMERALD, 4002, "§2§lGem Trader");
      a("repair_kit", Material.BEACON, 4003, "§d§lRepair Kit");
      a("gem_fragment", Material.PRISMARINE_SHARD, 4004, "§3§lGem Fragment");
      a("revive_beacon", Material.BEACON, 4005, "§e§lRevive Beacon", Arrays.asList("§7A powerful beacon that can revive players", "§7from the brink of death.", "", "§6Right-click to activate"));
   }

   private static class a {
      final Material a;
      final int b;
      final String c;
      final List<String> d;

      a(Material var1, int var2, String var3, List<String> var4) {
         this.a = var1;
         this.b = var2;
         this.c = var3;
         this.d = var4;
      }
   }
}
